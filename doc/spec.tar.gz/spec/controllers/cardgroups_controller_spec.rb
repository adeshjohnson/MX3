require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'application'

describe CardgroupsController, ".list" do

  before(:each) do
    Confline.stub!(:get_value)
    RoleRight.stub!(:get_authorization => 1)
    @cg1 = get_mock_cardgroup({:owner_id=>"8"})
    @cg2 = get_mock_cardgroup({:owner_id=>"0"})
    ApplicationController.stub!(:paginate => [1, [get_mock_cardgroup]])
  end

  it "should open without errors for accountant when edit is disabled session[:acc_callingcard_manage] = 2" do
    login_as_accountant(4)
    session[:acc_callingcard_manage] = 2
    get :list
    assigns[:allow_manage].should eql(true)
    assigns[:allow_read].should eql(true)
  end

  it "should open without errors for accountant when edit is disabled session[:acc_callingcard_manage] = 1" do
    login_as_accountant(4)
    session[:acc_callingcard_manage] = 1
    get :list
    assigns[:allow_manage].should eql(false)
    assigns[:allow_read].should eql(true)
  end

  it "should open without errors for accountant when edit is disabled session[:acc_callingcard_manage] = 0" do
    login_as_accountant(4)
    session[:acc_callingcard_manage] = 0
    get :list
    assigns[:allow_manage].should eql(false)
    assigns[:allow_read].should eql(false)
  end

  it "should open without errors for reseller" do
    login_as_reseller(8)
    Cardgroup.should_receive(:find).with(:all, {:conditions=>["owner_id = '?'", 8]}).and_return([@cg1])
    get :list
    assigns[:cardgroups].should eql([@cg1])
    assigns[:cardgroups].should_not eql([@cg2])
  end

end

describe CardgroupsController, ".new" do

  before(:each) do
    Confline.stub!(:get_value)
    RoleRight.stub!(:get_authorization => 1)
    @cg1 = get_mock_cardgroup({:owner_id=>"8"})
    @cg1.stub!(:tax=)
    @cg1.stub!(:vat_percent=)
    @cg2 = get_mock_cardgroup({:owner_id=>"0"})
    @cg2.stub!(:tax=)
    @cgs = [@cg1, @cg2]
    @tarif1 = get_mock_tariff({:owner_id=>"8"})
    @tarif2 = get_mock_tariff({:owner_id=>"0"})

    @lcr1 = get_mock_lcr({:id=>"7"})
    @lcr2 = get_mock_lcr({:id=>"0"})

    @location = get_mock_location()
    @user = get_mock_user({:id=>"8", :lcr_id=>"7"})
    User.should_receive(:find_by_id).and_return(@user)
  end

  it "should open without errors for admin" do
    login_as_admin
    Cardgroup.should_receive(:new).and_return(@cg1)
    Location.should_receive(:find).with(:all).and_return([@location])
    Lcr.should_receive(:find).with(:all).and_return([@lcr1, @lcr2])
    Tariff.should_receive(:find).with(:all, :conditions => ["purpose like 'user%' AND owner_id = ?", 0]).and_return([@tarif2])
    get :new
  end

  it "should open without errors for reseller" do
    login_as_reseller(8)
    Cardgroup.should_receive(:new).and_return(@cg1)
    Location.should_receive(:find).with(:all, :conditions=>"name= 'Global'").and_return([@location])
    Lcr.should_receive(:find).with(:all, {:conditions=>["id = ?", "7"]}).and_return([@lcr1])
    Tariff.should_receive(:find).with(:all, :conditions => ["purpose like 'user%' AND owner_id = ?", 8]).and_return([@tarif1])
    get :new
  end

end


describe CardgroupsController, ".loss_calls" do

  before(:each) do
    Confline.stub!(:get_value)
    RoleRight.stub!(:get_authorization => 1)
    @cg1 = get_mock_cardgroup({:owner_id=>"8", :user_price =>"4", :balance=>"-4"})
    @cg2 = get_mock_cardgroup({:owner_id=>"0", :user_price =>"4", :balance=>"-5"})
    @cgs = [@cg1, @cg2]
    @tarif1 = get_mock_tariff({:owner_id=>"8"})
    @tarif2 = get_mock_tariff({:owner_id=>"0"})

    @lcr1 = get_mock_lcr({:id=>"7"})
    @lcr2 = get_mock_lcr({:id=>"0"})

    @location = get_mock_location()
    @user = get_mock_user({:id=>"8", :lcr_id=>"7"})
  end

  it "should open without errors for admin" do
    login_as_admin
    data = {}
    data["year"] = "2008"
    data["month"] = "01"
    data["day"] = "04"
    data["hour"] = "01"
    data["minute"] = "01"

    data2 = {}
    data2["year"] = "2008"
    data2["month"] = "01"
    data2["day"] = "04"
    data2["hour"] = "23"
    data2["minute"] = "59"

    Cardgroup.should_receive(:find).with(:all, :conditions=>"owner_id = '#{0}'", :order=>"name Asc").and_return([@cg2])
    Card.should_receive(:find_by_sql).and_return([@cg2])
    get :loss_calls, :date_from => data, :date_till => data2
    assigns[:cards_callsv].should eql([])
  end


  it "should open without errors for reseller" do
    login_as_reseller(8)
    data = {}
    data["year"] = "2008"
    data["month"] = "01"
    data["day"] = "04"
    data["hour"] = "01"
    data["minute"] = "01"

    data2 = {}
    data2["year"] = "2008"
    data2["month"] = "01"
    data2["day"] = "04"
    data2["hour"] = "23"
    data2["minute"] = "59"

    Cardgroup.should_receive(:find).with(:all, :conditions=>"owner_id = '#{8}'", :order=>"name Asc").and_return([@cg1])
    Card.should_receive(:find_by_sql).and_return([@cg1])
    get :loss_calls, :date_from => data, :date_till => data2
    assigns[:cards_callsv].should eql([])
  end
end

describe CardgroupsController, ".show" do

  before (:each) do
    Cardgroup.should_receive(:find_by_id).with("4").and_return(get_mock_cardgroup)
  end

  it "should allow manage for accountant when session[:acc_callingcard_manage] = 2" do
    login_as_accountant(3)
    session[:acc_callingcard_manage] = 2
    get :show, :id => 4
    assigns[:allow_manage].should eql(true)
  end

  it "should allow manage for accountant when session[:acc_callingcard_manage] = 1" do
    login_as_accountant(3)
    session[:acc_callingcard_manage] = 1
    get :show, :id => 4
    assigns[:allow_manage].should eql(false)
  end

  it "should allow manage for accountant when session[:acc_callingcard_manage] = 0" do
    login_as_accountant(3)
    session[:acc_callingcard_manage] = 0
    get :show, :id => 4
    assigns[:allow_manage].should eql(false)
    response.should redirect_to("http://test.host/cardgroups/list")
    flash[:notice].should eql(_('Dont_be_so_smart'))
  end
end
