require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'ccshop_controller'

describe CcshopController, ".add_to_cart" do
  def do_get
    get :call_list, :id => 1
  end

  before(:each) do
    @ccshop_controller = CcshopController.new
    session[:lang] = "en"
  end

  it "should add card if there are unsold cards" do
    @ccshop_controller = CcshopController.new
    @card_group = Cardgroup.new()
    @card_group.name = "test"
    @card_group.valid_from = "2007-01-01 00:00:00 +02:00".to_time
    @card_group.description = ""
    @card_group.tariff = get_mock_tariff
    @card_group.save.should eql(true)
    @card = Card.new()
    @card.cardgroup_id = @card_group.id
    @card.daily_charge_paid_till = ""
    @card.first_use= ""
    @card.pin = ""
    @card.save.should eql(true)
    cd = {}
    cd["amount"] = "1"
    post :add_to_cart, :id => @card_group.id, :cards => cd
    flash[:notice].should eql("Card added: test")
    post :add_to_cart, :id => @card_group.id, :cards => cd
    flash[:notice].should eql("One or more cards were not added: test")
  end
end


describe CcshopController, ".paypal_ipn" do
  before(:each) do
    @ccshop_controller = CcshopController.new
    session[:lang] = "en"
    @notf =  mock_model(Confline, {:gross => 12,:transaction_id=> "1234", :amount=> 12, :fee => 11, :currency=> "GEL", :complete? => true, :acknowledge => true, :item_id => 18, :paypal_ipn => "" , :payment_status=>"Completed", :payment_date=>"2009-02-10 14:50:50" ,:txn_id=>3, :txn_type=>"aaa", :mc_gross=>"99", :mc_fee=>"44", :mc_currency=>"LTL" ,:item_number=>"9", :invoice=>"99", :first_name=>"bla", :last_name=>"alb", :payer_email=>"tankiaitaskuota@gmail.com", :residence_country=>"zzz", :payer_status=>"9", :tax=>"98", :custom=>"55", :pending_reason=>"nzz"})
    @order = mock_model(Ccorder , :amount=>"66", :id=>"18", :currency=>"rr", :ordertype=>"rr", :email=>"tankiaitaskuota@gamil.com", :date_added=>"2001-01-01 01:01:01", :completed=>"eee", :transaction_id=>"eee", :shipped_at=>"4", :fee=>"4", :gross=>"4", :first_name=>"4", :last_name=>"4", :payer_email=>"tankiaitaskuota@gmail.com", :residence_country=>"", :payer_status=>"", :tax=>"")
    @order.stub!(:shipped_at=)
    @order.stub!(:ordertype=)
    @order.should_receive(:currency=).with("GEL")
    @order.stub!(:fee=)
    @order.stub!(:amount=)
    @order.stub!(:transaction_id=)
    @order.stub!(:first_name=)
    @order.stub!(:last_name=)
    @order.stub!(:payer_email=)
    @order.stub!(:email=)
    @order.stub!(:residence_country=)
    @order.stub!(:payer_status=)
    @order.stub!(:tax=)
    @order.should_receive(:save).and_return(:true)
    EmailsController.should_receive(:send_to_users_paypal_email)
    Action.should_receive(:create_cards_action)
    CcInvoice.should_receive(:invoice_from_order)
  end

  it "should pay" do
    Paypal::Notification.should_receive(:new).and_return(@notf)
    Ccorder.should_receive(:find).and_return(@order)
    get :paypal_ipn#, :payment_status=>"Completed", :payment_date=>"2009-02-10 14:50:50" ,:txn_id=>3, :txn_type=>"aaa", :mc_gross=>"99", :mc_fee=>"44", :mc_currency=>"LTL" ,:item_number=>"9", :invoice=>"99", :first_name=>"bla", :last_name=>"alb", :payer_email=>"tankiaitaskuota@gmail.com", :residence_country=>"zzz", :payer_status=>"9", :tax=>"98", :custom=>"55", :pending_reason=>"nzz", :cmd=>"_notify-validate"

  end
end

#  it "should format correct numbers" do
#    do_get
#    MorLog.my_debug(response.body)
#    response.should eql("")
#  end

#  it "should redirect when trying to open it without login" do
#
#
#    do_get
#
#    response.should eql("")
#  end
