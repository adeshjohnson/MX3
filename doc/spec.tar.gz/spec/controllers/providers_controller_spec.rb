require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'providers_controller'

describe ProvidersController, "provider_rule_update" do
  before(:each) do
    @providers_controller = ProvidersController.new
    @rule = mock_model(Providerrule)
  end

  it "should update" do
    login_as_admin
    @mock_rule = mock_model(Providerrule, :provider_id => 1)
    @mock_rule.should_receive(:name=)
    @mock_rule.should_receive(:cut=)
    @mock_rule.should_receive(:add=)
    @mock_rule.should_receive(:minlen=)
    @mock_rule.should_receive(:maxlen=)
    @mock_rule.should_receive(:save).and_return(true)
    Providerrule.should_receive(:find).with("12").and_return(@mock_rule)
    post :provider_rule_update, :name => "Test", :cut => "1", :add=> "13",  :minlen => "1", :maxlen => "2", :id => 12
    response.flash[:notice].should eql("Rule updated")
  end

  it "should deny equal add and cut on create" do
    login_as_admin
    @rule.should_receive(:provider_id=).twice
    @rule.should_receive(:name=).twice
    @rule.should_receive(:cut=).twice
    @rule.should_receive(:add=).twice
    @rule.should_receive(:minlen=).twice
    @rule.should_receive(:maxlen=).twice
    @rule.should_receive(:pr_type=).twice
    @rule.should_receive(:enabled=).twice.with(1)
    @rule.should_receive(:save).and_return(false)
    @rule.should_receive(:cut).and_return(1)
    @rule.should_receive(:add).and_return(1)
    Providerrule.should_receive(:new).twice.and_return(@rule)
    post :provider_rule_add, :name => "Test", :cut => "1", :add=> "1", :minlen => "1", :maxlen => "2", :id => 15, :pr_type => "dst"
    response.flash[:notice].should eql("Add failed : Cut can not be equal to Add")

    @rule.stub!(:save => true)
    @rule.stub!(:add => 13)
    #Providerrule.should_receive(:new).and_return(@rule)
    post :provider_rule_add, :name => "Test", :cut => "1", :add=> "13",  :minlen => "1", :maxlen => "2", :id => 15, :pr_type => "dst"
    response.flash[:notice].should eql("Rule added")
  end
end

describe ProvidersController, "terminators" do

  it "should find terminators" do
    login_as_admin
    Terminator.should_receive(:find).with(:all, :include => :providers).and_return([])
    get :terminators
    assigns[:terminators].should eql([])
  end

end

describe ProvidersController, "terminator_create" do

  before(:each) do
    login_as_admin
    @term = get_mock_terminator
  end

  it "should create terminator" do
    @term.should_receive(:save).and_return(true)
    Terminator.should_receive(:new).with(:name => "new").and_return(@term)
    get :terminator_create, :name => "new"
    flash[:notice].should eql(_('Terminator_was_created'))
    response.should redirect_to("http://test.host/providers/terminators")
  end

  it "should anounce when terminator was not created" do
    @term.should_receive(:save).and_return(false)
    Terminator.should_receive(:new).with(:name => "new").and_return(@term)
    get :terminator_create, :name => "new"
    flash[:notice].should eql(_('Terminator_was_not_created'))
    response.should redirect_to("http://test.host/providers/terminators")
  end

end

describe ProvidersController, "terminator_destory" do

  before(:each) do
    login_as_admin
    @term = get_mock_terminator
  end

  it "should destroy terminator" do
    @term.should_receive(:destroy).and_return(true)
    Terminator.should_receive(:find).with(:first, :conditions => "id = 1").and_return(@term)
    Provider.should_receive(:update_all).with("terminator_id = NULL", "terminator_id = 1")
    get :terminator_destory, :id => 1
    flash[:notice].should eql(_('Terminator_was_destroyed'))
    response.should redirect_to("http://test.host/providers/terminators")
  end

  it "should anounce when terminator was not destroyed" do
    @term.should_receive(:destroy).and_return(false)
    Terminator.should_receive(:find).with(:first, :conditions => "id = 1").and_return(@term)
    get :terminator_destory, :id => 1
    flash[:notice].should eql(_('Terminator_was_not_destroyed'))
    response.should redirect_to("http://test.host/providers/terminators")
  end

end

describe  ProvidersController, "terminator_edit" do

  it "should find terminator" do
    login_as_admin
    @term = get_mock_terminator
    Terminator.should_receive(:find).with(:first, :conditions => "id = 1").and_return(@term)
    get :terminator_edit, :id => 1
  end

end

describe ProvidersController, "terminator_update" do

  before(:each) do
    login_as_admin
    @term = get_mock_terminator
  end

  it "should get updated" do
    @term.should_receive(:save).and_return(true)
    @term.should_receive(:name=).with("new_name")
    Terminator.should_receive(:find).with(:first, :conditions => "id = 1").and_return(@term)
    get :terminator_update, :id => 1, :terminator => {:name => "new_name"}
    flash[:notice].should eql(_('Terminator_was_updated'))
    response.should redirect_to("http://test.host/providers/terminators")
  end

  it "should notice if was not updated" do
    @term.should_receive(:save).and_return(false)
    @term.should_receive(:name=).with("new_name")
    Terminator.should_receive(:find).with(:first, :conditions => "id = 1").and_return(@term)
    get :terminator_update, :id => 1, :terminator => {:name => "new_name"}
    flash[:notice].should eql(_('Terminator_was_not_updated'))
    response.should redirect_to("http://test.host/providers/terminators")
  end

end

describe ProvidersController, "terminator_providers" do

  before(:each) do
    login_as_admin
    @term = get_mock_terminator
  end

  it "should find providers" do
    Terminator.should_receive(:find).with(:first, :conditions => "id = 1").and_return(@term)
    Provider.stub!(:stub)
    Provider.should_receive(:find).with(:all, :conditions => "terminator_id = 0").and_return([])
    Provider.should_receive(:find).with(:all, :conditions => "terminator_id = 1").and_return([])
    get :terminator_providers, :id => 1
  end

end

describe ProvidersController, "terminator_provider_add" do

  before(:each) do
    login_as_admin
    @provider = get_mock_provider
  end

  it "should provider to terminator" do
    @provider.should_receive(:terminator_id=).with(1)
    @provider.should_receive(:save).and_return(true)
    Provider.should_receive(:find).with(:first, :conditions => "id = 3").and_return(@provider)
    get :terminator_provider_add, :id => 1, :provider_id => 3
    flash[:notice].should eql(_('Provider_was_assigned'))
    response.should redirect_to("http://test.host/providers/terminator_providers/1")
  end

  it "should provider to terminator" do
    @provider.should_receive(:terminator_id=).with(1)
    @provider.should_receive(:save).and_return(false)
    Provider.should_receive(:find).with(:first, :conditions => "id = 3").and_return(@provider)
    get :terminator_provider_add, :id => 1, :provider_id => 3
    flash[:notice].should eql(_('Provider_was_not_assigned'))
    response.should redirect_to("http://test.host/providers/terminator_providers/1")
  end

end
