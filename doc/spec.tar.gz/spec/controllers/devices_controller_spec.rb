require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'devices_controller'

describe DevicesController, ".clis" do


  before(:each) do
    @devices_controller = DevicesController.new
  end

  it "should find all " do
    login_as_admin
    @user = get_mock_user()
    @device = get_mock_device(:user_id=>@user.id)
    @ivr1 = get_mock_ivr()
    @ivr2 = get_mock_ivr({:name=>"bla"})
    @cli = get_mock_cli({:cli => "200", :device_id => @device.id, :ivr_id => @ivr1.id})
    @cli2 = get_mock_cli()
    @clis = [@cli1, @cli2]
    @users = [@user]
    @ivrs1=[@ivr1]
    @ivrs2=[@ivr1, @ivr2]

    Callerid.should_receive(:find_by_sql).and_return(@clis)
    User.should_receive(:find).with(:all).and_return(@users)
    Ivr.should_receive(:find_by_sql).and_return(@ivrs1)
    Ivr.should_receive(:find).with(:all).and_return(@ivrs2)
    get "clis"
  end


  it "should find by cli " do
    login_as_admin
    @user = get_mock_user()
    @device = get_mock_device(:user_id=>@user.id)
    @ivr1 = get_mock_ivr()
    @ivr2 = get_mock_ivr({:name=>"bla"})
    @cli = get_mock_cli({:cli => "200", :device_id => @device.id, :ivr_id => @ivr1.id})
    @cli2 = get_mock_cli()
    @clis = [@cli, @cli2]
    @clis1 = [@cli]
    @users = [@user]
    @ivrs1=[@ivr1]
    @ivrs2=[@ivr1, @ivr2]

    Callerid.should_receive(:find_by_sql).and_return(@clis1)
    User.should_receive(:find).with(:all).and_return(@users)
    Ivr.should_receive(:find_by_sql).and_return(@ivrs1)
    Ivr.should_receive(:find).with(:all).and_return(@ivrs2)
    get "clis", :s_cli=>"200"
  end

  it "should find by description " do
    login_as_admin
    @user = get_mock_user()
    @device = get_mock_device(:user_id=>@user.id)
    @ivr1 = get_mock_ivr()
    @ivr2 = get_mock_ivr({:name=>"bla"})
    @cli = get_mock_cli({:cli => "200", :device_id => @device.id, :ivr_id => @ivr1.id, :description=> "testtt"})
    @cli2 = get_mock_cli()
    @clis = [@cli, @cli2]
    @clis1 = [@cli]
    @users = [@user]
    @ivrs1=[@ivr1]
    @ivrs2=[@ivr1, @ivr2]

    Callerid.should_receive(:find_by_sql).and_return(@clis1)
    User.should_receive(:find).with(:all).and_return(@users)
    Ivr.should_receive(:find_by_sql).and_return(@ivrs1)
    Ivr.should_receive(:find).with(:all).and_return(@ivrs2)
    get "clis", :s_description=>"testtt"
  end

  it "should find by comment " do
    login_as_admin
    @user = get_mock_user()
    @device = get_mock_device(:user_id=>@user.id)
    @ivr1 = get_mock_ivr()
    @ivr2 = get_mock_ivr({:name=>"bla"})
    @cli = get_mock_cli({:cli => "200", :device_id => @device.id, :ivr_id => @ivr1.id, :comment=> "testtt"})
    @cli2 = get_mock_cli()
    @clis = [@cli, @cli2]
    @clis1 = [@cli]
    @users = [@user]
    @ivrs1=[@ivr1]
    @ivrs2=[@ivr1, @ivr2]

    Callerid.should_receive(:find_by_sql).and_return(@clis1)
    User.should_receive(:find).with(:all).and_return(@users)
    Ivr.should_receive(:find_by_sql).and_return(@ivrs1)
    Ivr.should_receive(:find).with(:all).and_return(@ivrs2)
    get "clis", :s_comment=>"testtt"
  end

  it "should find by banned " do
    login_as_admin
    @user = get_mock_user()
    @device = get_mock_device(:user_id=>@user.id)
    @ivr1 = get_mock_ivr()
    @ivr2 = get_mock_ivr({:name=>"bla"})
    @cli = get_mock_cli({:cli => "200", :device_id => @device.id, :ivr_id => @ivr1.id, :banned=> "1"})
    @cli2 = get_mock_cli()
    @clis = [@cli, @cli2]
    @clis1 = [@cli]
    @users = [@user]
    @ivrs1=[@ivr1]
    @ivrs2=[@ivr1, @ivr2]

    Callerid.should_receive(:find_by_sql).and_return(@clis1)
    User.should_receive(:find).with(:all).and_return(@users)
    Ivr.should_receive(:find_by_sql).and_return(@ivrs1)
    Ivr.should_receive(:find).with(:all).and_return(@ivrs2)
    get "clis", :s_banned=>"1"
  end

  it "should find by ivr " do
    login_as_admin
    @user = get_mock_user()
    @device = get_mock_device(:user_id=>@user.id)
    @ivr1 = get_mock_ivr()
    @ivr2 = get_mock_ivr({:name=>"bla"})
    @cli = get_mock_cli({:cli => "200", :device_id => @device.id, :ivr_id => @ivr1.id, :banned=> "1"})
    @cli2 = get_mock_cli()
    @clis = [@cli, @cli2]
    @clis1 = [@cli]
    @users = [@user]
    @ivrs1=[@ivr1]
    @ivrs2=[@ivr1, @ivr2]


    Callerid.should_receive(:find_by_sql).and_return(@clis1)
    User.should_receive(:find).with(:all).and_return(@users)
    Ivr.should_receive(:find_by_sql).and_return(@ivrs1)
    Ivr.should_receive(:find).with(:all).and_return(@ivrs2)
    get "clis", :s_ivr=>@ivr1.id
  end

  it "should find by user all devices" do
    login_as_admin
    @user = get_mock_user()
    @device = get_mock_device(:user_id=>@user.id)
    @ivr1 = get_mock_ivr()
    @ivr2 = get_mock_ivr({:name=>"bla"})
    @cli = get_mock_cli({:cli => "200", :device_id => @device.id, :ivr_id => @ivr1.id, :banned=> "1"})
    @cli2 = get_mock_cli()
    @clis = [@cli, @cli2]
    @clis1 = [@cli]
    @users = [@user]
    @ivrs1=[@ivr1]
    @ivrs2=[@ivr1, @ivr2]
    Callerid.should_receive(:find_by_sql).and_return(@clis1)
    User.should_receive(:find).with(:all).and_return(@users)
    Ivr.should_receive(:find_by_sql).and_return(@ivrs1)
    Ivr.should_receive(:find).with(:all).and_return(@ivrs2)
    get "clis", :s_user=>@user.id, :device_id=>"-1"
  end

  it "should find by user one devices" do
    login_as_admin
    @user = get_mock_user()
    @device = get_mock_device(:user_id=>@user.id)
    @ivr1 = get_mock_ivr()
    @ivr2 = get_mock_ivr({:name=>"bla"})
    @cli = get_mock_cli({:cli => "200", :device_id => @device.id, :ivr_id => @ivr1.id, :banned=> "1"})
    @cli2 = get_mock_cli()
    @clis = [@cli, @cli2]
    @clis1 = [@cli]
    @users = [@user]
    @ivrs1=[@ivr1]
    @ivrs2=[@ivr1, @ivr2]

    Callerid.should_receive(:find_by_sql).and_return(@clis1)
    User.should_receive(:find).with(:all).and_return(@users)
    Ivr.should_receive(:find_by_sql).and_return(@ivrs1)
    Ivr.should_receive(:find).with(:all).and_return(@ivrs2)
    get "clis", :s_user=>@user.id, :device_id=>@device.id
  end

  it "should find by callback status" do
    login_as_admin
    @user = get_mock_user()
    @device = get_mock_device(:user_id=>@user.id)
    @ivr1 = get_mock_ivr()
    @ivr2 = get_mock_ivr({:name=>"bla"})
    @cli = get_mock_cli({:cli => "200", :device_id => @device.id, :ivr_id => @ivr1.id, :email_callback=> "1"})
    @cli2 = get_mock_cli()
    @clis = [@cli, @cli2]
    @clis1 = [@cli]
    @users = [@user]
    @ivrs1=[@ivr1]
    @ivrs2=[@ivr1, @ivr2]

    Callerid.should_receive(:find_by_sql).and_return(@clis1)
    User.should_receive(:find).with(:all).and_return(@users)
    Ivr.should_receive(:find_by_sql).and_return(@ivrs1)
    Ivr.should_receive(:find).with(:all).and_return(@ivrs2)
    get "clis", :s_email_callback=>"1"
  end
end

describe DevicesController, ".clis_banned_status" do

  before(:each) do
    @devices_controller = DevicesController.new
  end

  it "should change to banned " do
    login_as_admin
    @cli = get_mock_cli()
    Callerid.should_receive(:find).with("#{@cli.id}").and_return(@cli)
    @cli.should_receive(:banned=).with(1)
    @cli.should_receive(:save)
    get "clis_banned_status", :id=>@cli.id
  end

  it "should change to no_banned " do
    login_as_admin
    @cli = get_mock_cli({:banned=>1})
    Callerid.should_receive(:find).with("#{@cli.id}").and_return(@cli)
    @cli.should_receive(:banned=).with(0)
    @cli.should_receive(:save)
    get "clis_banned_status", :id=>@cli.id
  end


  it "should redirect to edit " do
    login_as_admin
    @cli = get_mock_cli({:banned=>1})
    Callerid.should_receive(:find).with("#{@cli.id}").and_return(@cli)
    @cli.should_receive(:banned=).with(0)
    @cli.should_receive(:save)
    get "clis_banned_status", :id=>@cli.id, :return_action=>'cli_edit'
  end
end


describe DevicesController, ".cli_user_devices" do

  before(:each) do
    @devices_controller = DevicesController.new
  end

  it "should find all users devices " do
    login_as_admin
    @dev = get_mock_device({:user_id=>"102"})
    Device.should_receive(:find).with(:all , :conditions => "user_id = 'add1&id102'").and_return(@dev)
    get "cli_user_devices", :id=>"102", :add=>1
  end
end



describe DevicesController, ".cli_update" do

  before(:each) do
    @devices_controller = DevicesController.new
  end

  it "should update from admin whit return 'clis'" do
    login_as_admin
    @cli = get_mock_cli()
    Callerid.should_receive(:find).with("#{@cli.id}").and_return(@cli)
    @cli.should_receive(:cli=).with("aaa")
    @cli.should_receive(:description=).with("www")
    @cli.should_receive(:comment=).with("aaar")
    @cli.should_receive(:banned=).with(1)
    @cli.should_receive(:ivr_id=).with("23")
    @cli.should_receive(:save)
    Callerid.should_receive(:use_for_callback).with(@cli, "1")
    get "cli_update", :id=>@cli.id, :cli=>"aaa", :description=>"www", :comment=>"aaar", :banned=>1, :ivr=>"23", :return_action=>'clis', :email_callback=>1
  end

  it "should update from admin " do
    login_as_admin
    @cli = get_mock_cli()
    Callerid.should_receive(:find).with("#{@cli.id}").and_return(@cli)
    @cli.should_receive(:cli=).with("aaa")
    @cli.should_receive(:description=).with("www")
    @cli.should_receive(:comment=).with("aaar")
    @cli.should_receive(:banned=).with(1)
    @cli.should_receive(:ivr_id=).with("23")
    @cli.should_receive(:save)
    Callerid.should_receive(:use_for_callback).with(@cli, "1")
    get "cli_update", :id=>@cli.id, :cli=>"aaa", :description=>"www", :comment=>"aaar", :banned=>1, :ivr=>"23", :email_callback=>1
  end
end


describe DevicesController, ".cli_edit" do

  before(:each) do
    @devices_controller = DevicesController.new
  end

  it "should update  whit return 'clis'" do
    login_as_admin

    @user = get_mock_user()
    @dev = get_mock_device({:user_id=>@user.id})
    @cli = get_mock_cli({:device_id=>@dev.id})
    @ivr1 = get_mock_ivr()
    @ivrs = [@ivr1]
    Callerid.should_receive(:find).with("#{@cli.id}").and_return(@cli)
    Ivr.should_receive(:find).with(:all).and_return(@ivrs)
    @cli.should_receive(:device).and_return(@dev)
    @dev.should_receive(:user).and_return(@user)
    get "cli_edit", :id=>@cli.id, :return_action=>'clis'
  end

  it "should update  " do
    login_as_admin

    @user = get_mock_user()
    @dev = get_mock_device({:user_id=>@user.id})
    @cli = get_mock_cli({:device_id=>@dev.id})
    @ivr1 = get_mock_ivr()
    @ivrs = [@ivr1]
    Callerid.should_receive(:find).with("#{@cli.id}").and_return(@cli)
    Ivr.should_receive(:find).with(:all).and_return(@ivrs)
    @cli.should_receive(:device).and_return(@dev)
    @dev.should_receive(:user).and_return(@user)
    get "cli_edit", :id=>@cli.id
  end

end


describe DevicesController, ".cli_delete" do

  before(:each) do
    @devices_controller = DevicesController.new
  end

  it "should delete  whit return 'clis' " do
    login_as_admin
    @cli = get_mock_cli()
    Callerid.should_receive(:find).with("#{@cli.id}").and_return(@cli)
    @cli.should_receive(:destroy)
    get "cli_delete", :id=>@cli.id, :return_action=>'clis'
  end

  it "should delete  whit return 'clis'" do
    login_as_admin
    @cli = get_mock_cli()
    Callerid.should_receive(:find).with("#{@cli.id}").and_return(@cli)
    @cli.should_receive(:destroy)
    get "cli_delete", :id=>@cli.id
  end

end


describe DevicesController, ".cli_add" do

  before(:each) do
    @devices_controller = DevicesController.new
  end

  it "should Not create from admin whit return 'clis'" do
    login_as_admin
    @cli = get_mock_cli({:cli=>"aaa"})
    Callerid.should_receive(:find).with(:first, :conditions => "cli = 'aaa'").and_return(@cli)

    get "cli_add", :id=>@cli.id, :cli=>"aaa", :description=>"www", :comment=>"aaar", :banned=>1, :ivr=>"23", :return_action=>'clis', :device_id=>"3"
  end

  it "should create from admin whit return 'clis'" do
    login_as_admin
    @cli = get_mock_cli()
    Callerid.should_receive(:find).with(:first, :conditions => "cli = 'aaa'").and_return(nil)
    Callerid.should_receive(:new).and_return(@cli)
    @cli.should_receive(:cli=).with("aaa")
    @cli.should_receive(:device_id=).with("3")
    @cli.should_receive(:description=).with("www")
    @cli.should_receive(:comment=).with("aaar")
    @cli.should_receive(:banned=).with(1)
    @cli.should_receive(:ivr_id=).with("23")
    @cli.should_receive(:added_at=)
    @cli.should_receive(:save)
    Callerid.should_receive(:use_for_callback).with(@cli, "1")
    get "cli_add", :id=>@cli.id, :cli=>"aaa", :description=>"www", :comment=>"aaar", :banned=>1, :ivr=>"23", :return_action=>'clis', :device_id=>"3", :email_callback=>1
  end

  it "should create from admin " do
    login_as_admin
    @cli = get_mock_cli()
    Callerid.should_receive(:find).with(:first, :conditions => "cli = 'aaa'").and_return(nil)
    Callerid.should_receive(:new).and_return(@cli)
    @cli.should_receive(:cli=).with("aaa")
    @cli.should_receive(:device_id=).with("3")
    @cli.should_receive(:description=).with("www")
    @cli.should_receive(:comment=).with("aaar")
    @cli.should_receive(:banned=).with(1)
    @cli.should_receive(:ivr_id=).with("23")
    @cli.should_receive(:added_at=)
    @cli.should_receive(:save)
    Callerid.should_receive(:use_for_callback).with(@cli, "1")
    get "cli_add", :id=>@cli.id, :cli=>"aaa", :description=>"www", :comment=>"aaar", :banned=>1, :ivr=>"23", :device_id=>"3", :email_callback=>1
  end

  it "should not create from admin " do
    login_as_admin
    @cli = get_mock_cli()

    get "cli_add", :id=>@cli.id, :cli=>"aaa", :description=>"www", :comment=>"aaar", :banned=>1, :ivr=>"23", :email_callback=>1
    flash[:notice].should eql("#{_("Please_select_user")}")
  end
end


describe DevicesController, ".device_clis" do

  before(:each) do
    @devices_controller = DevicesController.new
  end

  it "should find all devices clis" do
    login_as_admin
    @user = get_mock_user()
    @ivr = get_mock_ivr()
    @dev = get_mock_device({:user_id=>@user.id})
    @cli = get_mock_cli({:device_id=>@dev.id})
    @clis=[@cli]
    @ivrs=[@ivr]
    Device.should_receive(:find).with("#{@dev.id}").and_return(@dev)
    sql="SELECT callerids.* , ivrs.name as 'ivr_name' FROM callerids \n                      LEFT JOIN ivrs on (ivrs.id = callerids.ivr_id)\n                    WHERE device_id = '#{@dev.id}'"
    Callerid.should_receive(:find_by_sql).with(sql).and_return(@clis)
    @dev.should_receive(:user).and_return(@user)
    Ivr.should_receive(:find).with(:all).and_return(@ivrs)
    get "device_clis", :id=>@dev.id
  end
end


describe DevicesController, ".user_device_clis" do

  before(:each) do
    @devices_controller = DevicesController.new
  end

  it "should find all user clis from admin " do
    login_as_admin
    @user = get_mock_user()
    @ivr = get_mock_ivr()
    @dev = get_mock_device({:user_id=>@user.id})
    @cli = get_mock_cli({:device_id=>@dev.id})
    @clis=[@cli]
    @ivrs=[@ivr]
    @devices=[@device]
    User.should_receive(:find).with(0).and_return(@user)
    @user.should_receive(:devices).and_return(@devices)
    sql="SELECT callerids.* , devices.user_id , devices.name, devices.device_type, devices.istrunk, ivrs.name as 'ivr_name' FROM callerids \n                       JOIN devices on (devices.id = callerids.device_id)\n                       LEFT JOIN ivrs on (ivrs.id = callerids.ivr_id)\n               WHERE devices.user_id = '#{@user.id}'"
    Callerid.should_receive(:find_by_sql).with(sql).and_return(@clis)
    Ivr.should_receive(:find).with(:all).and_return(@ivrs)
    get "user_device_clis"
  end

end

describe DevicesController, ".change_email_callback_status" do

  before(:each) do
    @devices_controller = DevicesController.new
  end

  it "should change email callback status to 1 " do
    login_as_admin
    @cli = get_mock_cli({:id=> 1, :email_callback=>0})
    @clis=[@cli]
    Callerid.should_receive(:find).with("3").and_return(@cli)
    Callerid.should_receive(:use_for_callback).with(@cli, "1")
    get "change_email_callback_status", :id =>3, :email_callback=>"1"
  end

end

describe DevicesController, ".user_device_edit" do

  before(:each) do
    login_as_user(321)
  end

  it "should run without exceptions" do
    Device.should_receive(:find).with(:first, :conditions => "id = 123").and_return(get_mock_device(:user_id => 321, :dids => []))
    User.should_receive(:find).with(321).and_return(get_mock_user(:id => 321))
    get "user_device_edit", :id => 123
    assigns[:dids].should eql([])
  end

  it "should deny if user tries to open device that does not belong to him " do
    Device.should_receive(:find).with(:first, :conditions => "id = 123").and_return(get_mock_device(:user_id => 322, :dids => []))
    User.should_receive(:find).with(321).and_return(get_mock_user(:id => 321))
    get "user_device_edit", :id => 123
    response.should redirect_to("http://test.host/callc/main")
  end

end

describe DevicesController, ".user_device_update" do

  before(:each) do
    login_as_user(321)
  end

  it "should redirect if user tries to open device that does not belong to him" do
    Device.should_receive(:find).with(:first, :conditions => "id = 123").and_return(get_mock_device(:user_id => 322, :dids => []))
    User.should_receive(:find).with(321).and_return(get_mock_user(:id => 321))
    get "user_device_update", :id => 123
    response.should redirect_to("http://test.host/callc/main")
  end

  it "should update settings for device" do
    @dev = get_mock_device(:user_id => 321, :dids => [])
    @dev.stub!(:cid_from_dids=)
    @dev.stub!(:description=)
    @dev.stub!(:update_cid)
    @dev.should_receive(:record=).with(1)
    @dev.should_receive(:recording_to_email=).with(1)
    @dev.should_receive(:recording_email=).with("test@email.lt")
    @dev.should_receive(:recording_keep=).with(1)
    @dev.should_receive(:save).and_return(:false)
    Device.should_receive(:find).with(:first, :conditions => "id = 123").and_return(@dev)
    User.should_receive(:find).with(321).and_return(get_mock_user(:id => 321))
    device = {:record => 1, :recording_to_email=>"1",:recording_email=>"test@email.lt",:recording_keep=>"1"}
    get "user_device_update", :id => 123, :cid_number => "", :cid_name => "", :device => device
    response.should redirect_to("http://test.host/devices/user_devices")
  end

end

describe DevicesController, ".show_devices" do

  before(:each) do
    @user = get_mock_user
  end

  it "should return devices if user was found" do
    login_as_admin
    User.should_receive(:find_by_id).with("0").and_return(@user)
    get :show_devices, :id => 0
  end

  it "should return nil devices if user was not found" do
    login_as_admin
    User.should_receive(:find_by_id).with("3").and_return(nil)
    get :show_devices, :id => 3
    assigns[:devices].should eql(nil)
  end
end

describe DevicesController, ".create" do

  before(:each) do
    User.should_receive(:find_by_id).and_return(get_mock_user)
  end

  it "should denny accountant with session[:acc_device_create] == 0" do
    login_as_accountant(4)
    session[:acc_device_create] = 0
    post :create
    dont_be_so_smart
  end

  it "should denny accountant with session[:acc_device_create] == 1" do
    login_as_accountant(4)
    session[:acc_device_create] = 1
    post :create
    dont_be_so_smart
  end

end

describe DevicesController, ".new" do

  before(:each) do
    User.should_receive(:find_by_id).and_return(get_mock_user)
  end

  it "should denny accountant with session[:acc_device_create] == 0" do
    login_as_accountant(4)
    session[:acc_device_create] = 0
    get :new
    dont_be_so_smart
  end

  it "should denny accountant with session[:acc_device_create] == 1" do
    login_as_accountant(4)
    session[:acc_device_create] = 0
    get :new
    dont_be_so_smart
  end

end

describe DevicesController, ".device_update" do

  before(:each) do
    session[:acc_device_pin] = 0
    session[:acc_device_edit_opt_1] = 0
    session[:acc_device_edit_opt_2] = 0
    session[:acc_device_edit_opt_3] = 0
    session[:acc_device_edit_opt_4] = 0
  end

  it "should redirect if no device params were provided" do
    login_as_admin
    post :device_update
    response.should redirect_to("http://test.host/callc/main")
  end

  it "should work without exceptions" do
    login_as_accountant(8)
    @device = get_mock_device({:id => 32, :pin => 123, :secret => "456"}, {:password => "new_passw", :email= =>true, :password= => true, :clone => get_mock_voicemail_box({:password => "old_pass"})})
    @device.should_receive(:process_sipchaninfo=)
    @device.should_receive(:update_attributes).and_return(true)
    @device.should_receive(:username=).with("101")
    @device.should_receive(:update_cid)
    @device.should_receive(:cid_from_dids=)
    @device.should_receive(:qualify=)
    @device.should_receive(:host=)
    @device.should_receive(:port=).twice
    @device.should_receive(:canreinvite=)
    @device.should_receive(:transfer=)
    @device.should_receive(:callgroup=)
    @device.should_receive(:pickupgroup=)
    @device.should_receive(:fromuser=).twice
    @device.should_receive(:fromdomain=).twice
    @device.should_receive(:insecure=)
    @device.should_receive(:permit=)
    @device.should_receive(:istrunk=)
    @device.should_receive(:ani=)
    @device.should_receive(:context=)
    @device.should_receive(:save).twice.and_return(true)
    @device.should_receive(:clone).and_return(get_mock_device({:pin => 321, :secret => "654"}))
    controller.should_receive(:configure_extensions).with(32)
    Callflow.should_receive(:find).and_return([])
    User.should_receive(:find_by_id).with("2").and_return(get_mock_user)
    Device.should_receive(:find_by_id).with("32").and_return(@device)
    Action.stub!(:add_action_hash)
    Action.should_receive(:add_action_hash).with(8, {:action=>"device_pin_changed", :target_id=>32, :target_type=>"device", :data2=>123, :data=>321})
    Action.should_receive(:add_action_hash).with(8, {:action=>"device_secret_changed", :target_id=>32, :target_type=>"device", :data2=>"456", :data=>"654"})
    Action.should_receive(:add_action_hash).with(8, {:action=>"device_voice_mail_password_changed", :target_id=>32, :target_type=>"device", :data2=>"new_passw", :data=>"old_pass"})
    put :device_update, :id => 32, :device => {:pin => "123"}, :vm_psw=> "new_passw"
    flash[:notice].should eql(_('phones_settings_updated'))
    response.should redirect_to("http://test.host/devices/show_devices/2")
  end
end


