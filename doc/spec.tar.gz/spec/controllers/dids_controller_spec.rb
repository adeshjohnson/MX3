require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'dids_controller'

describe DidsController, ".update" do
  before(:each) do
    @did = get_mock_did()
  end

  it "should update 1 did" do
    login_as_admin
    controller.should_receive(:configure_extensions)
    @dev = get_mock_device
    @dev.stub!(:prune_device_in_all_servers)
    #Device.should_receive(:find).and_return(@dev)
    Did.should_receive(:find).with("2").and_return(@did)
    @did.should_receive(:close)
    post :update, :id=>2, :status=>"closed"
  end

  it "should update inteval dids" do
    login_as_admin
    controller.should_receive(:configure_extensions)
    @dev = get_mock_device
    @dev.stub!(:prune_device_in_all_servers)
    #Device.should_receive(:find).and_return(@dev)
    Did.should_receive(:find).with(:all, :conditions=>["did >= ? AND did <= ?","2","5"]).and_return([@did])
    @did.should_receive(:close)
    post :update, :from=>2, :till=>5, :status=>"closed"
  end
end


describe DidsController, ".confirm_did_action" do
  before(:each) do
  end
  it "should get 4 actoin" do
    login_as_admin
    post :confirm_did_action, :did_action=>4, :from=>2, :till=>5
    response.should redirect_to("http://test.host/dids/dids_interval_trunk")
  end
end


describe DidsController, ".dids_interval_add_to_trunk" do
  before(:each) do
    @dev = get_mock_device()
  end
  it "should find trunks" do
    login_as_admin
    Device.should_receive(:find_by_sql).and_return([@dev])
    #  @Device.should_receive(:find).with(:all, :conditions => "istrunk = 1").and_return([@dev])
    Did.should_receive(:count).with(:all, :conditions=>["did >= ? AND did <= ?","2", "5"]).and_return(5)
    post :dids_interval_add_to_trunk, :did_action=>4, :from=>2, :till=>5
  end
end


describe DidsController, ".dids_interval_trunk" do
  before(:each) do
    @usr = get_mock_user()
  end
  it "should find free users" do
    login_as_admin
    sql = "SELECT count(devices.id)  FROM devices \n              left join users on (devices.user_id = users.id)\n              where devices.istrunk = 1 and users.owner_id = '#{session[:user_id]}'"

    Device.should_receive(:count_by_sql).with(sql).and_return("88")
    User.should_receive(:find).with(:all, :conditions => "hidden = 0").and_return([@usr])
    Did.should_receive(:count).with(:all, :conditions=>["did >= ? AND did <= ?","2", "5"]).and_return(5)
    post :dids_interval_trunk, :did_action=>4, :from=>2, :till=>5
  end
end
