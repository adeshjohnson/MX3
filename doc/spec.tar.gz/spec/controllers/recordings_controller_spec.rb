require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'recordings_controller'

describe RecordingsController, ".play_recording" do

  before(:each) do
    login_as_admin
    Confline.stub!(:get_value)
  end

  it "should run without exceptions when recording is not found" do
    Confline.should_not_receive(:get_value).with("Recordings_addon_IP")
    Confline.should_not_receive(:get_value).with("Recordings_addon_Port")
    Recording.should_receive(:find).with(:first, :conditions =>"id = 2").and_return(nil)
    get :play_recording, :id => 2
  end

  it "should run without exceptions" do
    Confline.should_receive(:get_value).with("Recordings_addon_IP").and_return("192.168.0.0")
    Confline.should_receive(:get_value).with("Recordings_addon_Port").and_return("3000")
    Confline.should_receive(:get_value).with("Admin_Browser_Title").and_return("ABT")
    req = get_mock_recording
    Recording.should_receive(:find).with(:first, :conditions =>"id = 2").and_return(req)
    get :play_recording, :id => 2
    assigns[:server_path].should eql("http://192.168.0.0:3000")
    assigns[:title].should eql("ABT")
    assigns[:rec].should eql(req)
  end

end

describe RecordingsController, ".list" do

  before(:each) do
    login_as_admin
    Confline.stub!(:get_value)
    Confline.should_receive(:get_value).with("Recordings_addon_IP").and_return("192.168.0.0")
    Confline.should_receive(:get_value).with("Items_Per_Page").and_return("50")
  end

  it "should run without exceptions" do
    User.should_receive(:find).with(:first, :conditions => "id = 15")
    Recording.should_receive(:count).and_return(1)
    Recording.should_receive(:find).and_return([get_mock_recording])
    Confline.should_receive(:get_value).with("Recordings_addon_Port").and_return("3000")
    get :list, :id => 15
    assigns[:server_path].should eql("http://192.168.0.0:3000")
    assigns[:total_pages].should eql(1)
    assigns[:items_per_page].should eql(50)
    assigns[:search].should eql(0)
    assigns[:size].should eql(1)
  end

  it "should run with search parameters" do
    User.should_receive(:find).with(:first, :conditions => "id = 15")
    Recording.should_receive(:count).and_return(1)
    Recording.should_receive(:find).and_return([get_mock_recording])
    Confline.should_receive(:get_value).with("Recordings_addon_Port").and_return("")
    get :list, :id => 15, :page => 5, :search_on => 1, :s_source => "5555", :s_destination => "333"
    assigns[:server_path].should eql("http://192.168.0.0")
    assigns[:total_pages].should eql(1)
    assigns[:items_per_page].should eql(50)
    assigns[:size].should eql(1)
    assigns[:search].should eql(1)
    assigns[:page_select_params].should eql({:s_source => "5555", :s_destination => "333"})
  end

end

describe RecordingsController, ".list_recordings" do

  before(:each) do
    login_as_admin
    Confline.stub!(:get_value)
    Confline.should_receive(:get_value).with("Recordings_addon_IP").and_return("192.168.0.0")
    Confline.should_receive(:get_value).with("Items_Per_Page").and_return("50")
  end

  it "should run without exceptions" do
    User.should_receive(:find).with(:first, :conditions => "id = 0").and_return(get_mock_user)
    Recording.should_receive(:count).and_return(1)
    Recording.should_receive(:find).and_return([get_mock_recording])
    Confline.should_receive(:get_value).with("Recordings_addon_Port").and_return("3000")
    get :list_recordings
    assigns[:server_path].should eql("http://192.168.0.0:3000")
    assigns[:total_pages].should eql(1)
    assigns[:items_per_page].should eql(50)
    assigns[:search].should eql(0)
    assigns[:size].should eql(1)
  end

  it "should run with search parameters" do
    User.should_receive(:find).with(:first, :conditions => "id = 0").and_return(get_mock_user)
    Recording.should_receive(:count).and_return(1)
    Recording.should_receive(:find).and_return([get_mock_recording])
    Confline.should_receive(:get_value).with("Recordings_addon_Port").and_return("")
    get :list_recordings, :page => 5, :search_on => 1, :s_source => "5555", :s_destination => "333"
    assigns[:server_path].should eql("http://192.168.0.0")
    assigns[:total_pages].should eql(1)
    assigns[:items_per_page].should eql(50)
    assigns[:size].should eql(1)
    assigns[:search].should eql(1)
    assigns[:page_select_params].should eql({:s_source => "5555", :s_destination => "333"})
  end

end

describe RecordingsController, ".edit" do

  before(:each) do
    login_as_admin
    @rec = get_mock_recording
    Recording.should_receive(:find).with(:first, :conditions => "id = 15").and_return(@rec)
  end

  it "should run without exceptions" do

    get :edit, :id => 15
    assigns[:recording].should eql(@rec)
  end

end

describe RecordingsController, ".edit_recording" do

  before (:each) do
    login_as_user(10)
  end

  it "should run without exceptions" do
    @rec = get_mock_recording(:user_id => 10)
    Recording.should_receive(:find).with(:first, :conditions => "id = 15").and_return(@rec)
    get :edit_recording, :id => 15
    assigns[:recording].should eql(@rec)
  end

  it "should get redirected if user is not valid" do
    @rec = get_mock_recording(:user_id => 11)
    Recording.should_receive(:find).with(:first, :conditions => "id = 15").and_return(@rec)
    get :edit_recording, :id => 15
    flash[:notice].should eql(_('Dont_be_so_smart'))
    response.should redirect_to("http://test.host/callc/main")
  end
end

describe RecordingsController, ".update" do

  before(:each) do
    login_as_admin
  end

  it "should update without exceptions when save is sucessful" do
    @rec = get_mock_recording
    @rec.should_receive(:comment=).with("text")
    @rec.should_receive(:save).and_return(true)
    Recording.should_receive(:find).and_return(@rec)
    record = {:comment => "text"}
    get :update, :id => 14, :recording => record
    flash[:notice].should eql(_('Recording_was_updated'))
    response.should redirect_to("http://test.host/recordings/list/0")
  end

  it "should update without exceptions when save is sucessful" do
    @rec = get_mock_recording
    @rec.should_receive(:comment=).with("text")
    @rec.should_receive(:save).and_return(false)
    Recording.should_receive(:find).and_return(@rec)
    record = {:comment => "text"}
    get :update, :id => 14, :recording => record
    flash[:notice].should eql(_('Recording_was_not_updated'))
    response.should redirect_to("http://test.host/recordings/list/0")
  end
end

describe RecordingsController, ".update_recording" do

  before (:each) do
    login_as_user(10)
  end

  it "when save was sucessful" do
    @rec = get_mock_recording(:user_id => 10)
    @rec.should_receive(:comment=).with("text")
    @rec.should_receive(:save).and_return(true)
    Recording.should_receive(:find).with(:first, :conditions => "id = 12").and_return(@rec)
    record = {:comment => "text"}
    get :update_recording, :id => 12, :recording => record
    flash[:notice].should eql(_('Recording_was_updated'))
    response.should redirect_to("http://test.host/recordings/list_recordings")
  end

  it "when save was sucessful" do
    @rec = get_mock_recording(:user_id => 10)
    @rec.should_receive(:comment=).with("text")
    @rec.should_receive(:save).and_return(false)
    Recording.should_receive(:find).with(:first, :conditions => "id = 12").and_return(@rec)
    record = {:comment => "text"}
    get :update_recording, :id => 12, :recording => record
    flash[:notice].should eql(_('Recording_was_not_updated'))
    response.should redirect_to("http://test.host/recordings/list_recordings")
  end

  it "when recording doesn't belong to user" do
    login_as_admin
    @rec = get_mock_recording(:user_id => 15)
    @rec.should_receive(:comment=).with("text")
    @rec.should_receive(:save).and_return(true)
    Recording.should_receive(:find).with(:first, :conditions => "id = 12").and_return(@rec)
    record = {:comment => "text"}
    get :update_recording, :id => 12, :recording => record
    response.should redirect_to("http://test.host/recordings/list_recordings")
  end

end

describe RecordingsController, ".list_users" do

  before (:each) do
    Confline.stub!(:get_value)
    Confline.should_receive(:get_value).with("Items_Per_Page").and_return(50)
    login_as_admin
  end

  it "should work without additional params" do
    Role.should_receive(:find).with(:all, :conditions=>["name !='guest'"]).and_return(get_mock_roles)
    User.should_receive(:count).with({:conditions=>" hidden = 0 AND owner_id = '0' "}).and_return(1)
    User.should_receive(:find).and_return([get_mock_user])
    get :list_users
  end

end

describe RecordingsController, ".list_users_update" do

  before(:each) do
    login_as_admin
  end

  it "should run without exceptions" do
    user = get_mock_user(:id=>1)
    user.should_receive(:recording_enabled=).with(1)
    user.should_receive(:recording_forced_enabled=).with(1)
    user.should_receive(:recording_hdd_quota=).with("101")
    user.should_receive(:recordings_email=).with("test@email.com")
    user.should_receive(:save).and_return(true)
    User.should_receive(:find).with(:first, :conditions => ["id = ?", "1"]).once.and_return(user)
    get :list_users_update, :recording_enabled_1 => 1, :recording_forced_enabled_1 => 1, :recording_hdd_quota_1 => "101", :recordings_email_1 => "test@email.com"
    flash[:notice].should eql(_("Users_have_been_updated"))
  end

end

describe RecordingsController, ".destroy_recording" do

  before (:each) do
    login_as_admin
  end

  it "should show if recording was destoryed" do
    req = get_mock_recording
    req.should_receive(:destroy).and_return(true)
    Recording.should_receive(:find).with(:first, :conditions =>"id = 2").and_return(req)

    get :destroy_recording, :id => 2
    flash[:notice].should eql(_("Recording_was_destroyed"))
    response.should redirect_to("http://test.host/recordings/list_recordings")
  end

  it "should show if recording was destoryed" do
    req = get_mock_recording
    req.should_receive(:destroy).and_return(false)
    Recording.should_receive(:find).with(:first, :conditions =>"id = 2").and_return(req)

    get :destroy_recording, :id => 2
    flash[:notice].should eql(_("Recording_was_not_destroyed"))
    response.should redirect_to("http://test.host/recordings/list_recordings")
  end

end

describe RecordingsController, ".destroy_recording" do

  before (:each) do
    login_as_admin
  end

  it "should show if recording was destoryed" do
    req = get_mock_recording(:user_id => 3)
    req.should_receive(:destroy).and_return(true)
    Recording.should_receive(:find).with(:first, :conditions =>"id = 2").and_return(req)

    get :destroy, :id => 2
    flash[:notice].should eql(_("Recording_was_destroyed"))
    response.should redirect_to("http://test.host/recordings/list/3")
  end

  it "should show if recording was destoryed" do
    req = get_mock_recording(:user_id => 3)
    req.should_receive(:destroy).and_return(false)
    Recording.should_receive(:find).with(:first, :conditions =>"id = 2").and_return(req)

    get :destroy, :id => 2
    flash[:notice].should eql(_("Recording_was_not_destroyed"))
    response.should redirect_to("http://test.host/recordings/list/3")
  end

end



