#
# To change this template, choose Tools | Templates
# and open the template in the editor.

require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'functions_controller'

describe FunctionsController, ".settings_change" do
  before(:each) do
    @functions_controller = FunctionsController.new
  end
  #
  #
  #  it "change settings" do
  #   Confline.stub!(:get_value, :get_value2)
  #   @conf1 = get_mock_conflines({:id=>1 })
  #   @conf2 = get_mock_conflines({:id=>2})
  #   @conf3 = get_mock_conflines({:id=>3})
  #   get "settings_change", :company=>"aaa", :
  #  end
  #
  #
end


describe FunctionsController, ".tax_active" do
  before(:each) do
    Confline.stub!(:get_value)
    RoleRight.stub!(:get_authorization => 1)
    @conf1 = get_mock_conflines({:name=>"Tax_2", :value=>"pdf", :value2=>1})
    @conf2 = get_mock_conflines({:name=>"Tax_2_Value", :value=>"20"})
    @conf3 = get_mock_conflines({:name=>"Total_Tax_Value", :value=>"50"})
  end

  it "shuld deactive tax_" do
    login_as_admin
    Confline.should_receive(:get_value2).with("Tax_#{2}", 0).and_return(1)
    Confline.should_receive(:set_value2).with("Tax_#{2}", 0)
    Confline.should_receive(:get_value).with("Total_Tax_Value", 0).and_return(@conf3.value)
    Confline.should_receive(:get_value).with("Tax_#{2}_Value",0).and_return(@conf2.value)
    Confline.should_receive(:set_value).with("Total_Tax_Value", 30.0).and_return(@conf3.value)
    get :tax_active, :tax=>2
  end

  it "shuld active tax_" do
    login_as_admin
    Confline.should_receive(:get_value2).with("Tax_#{2}", 0).and_return(0)
    Confline.should_receive(:set_value2).with("Tax_#{2}", 1)
    Confline.should_receive(:get_value).with("Total_Tax_Value", 0).and_return(@conf3.value)
    Confline.should_receive(:get_value).with("Tax_#{2}_Value",0).and_return(@conf2.value)
    Confline.should_receive(:set_value).with("Total_Tax_Value", 70.0).and_return(@conf3.value)
    get :tax_active, :tax=>2
  end
end

describe FunctionsController, ".settings_addons" do

  before (:each) do
    login_as_admin
  end

  it "should when REC_Active = 1" do
    REC_Active = 1
    CALLC_Active = 0
    Server.should_not_receive(:find).with(:all, :order => "server_id ASC").and_return([])
    Recording.should_receive(:find).and_return([{"total_size"=>12.1}])
    get "settings_addons"
    assigns[:page_title].should eql(_('Addons_Settings'))
    assigns[:total_recordings_size].should eql(12.1)
    assigns[:servers].should eql(nil)
  end
  
  it "should run when CALLC_Active = 1" do
    REC_Active = 0
    CALLC_Active = 1
    Server.should_receive(:find).with(:all, :order => "server_id ASC").and_return([])
    Recording.should_not_receive(:find).and_return([{"total_size"=>12.1}])
    get "settings_addons"
    assigns[:page_title].should eql(_('Addons_Settings'))
    assigns[:total_recordings_size].should eql(nil)
    assigns[:servers].should eql([])
  end

end

describe FunctionsController, ".settings_addons_change" do

  before (:each) do
    login_as_admin
    options = {
      :ra_use_external_server => "1",
      :ra_ip=>"123.123.123.123",
      :ra_port=>"123",
      :ra_login => "test_login",
      :ra_password => "test_pass",
    :ra_max_space=>"50"}
  end

  it "should save settings when REC_active is set to 1" do
    REC_Active = 1
    CC_Active = 1
    CALLC_Active = 1
    Confline.stub!(:set_value)
    Confline.should_receive(:set_value).with("Recordings_addon_Use_External_Server", "1", 0)
    Confline.should_receive(:set_value).with("Recordings_addon_IP", "123.123.123.123", 0)
    Confline.should_receive(:set_value).with("Recordings_addon_Port", "123", 0)
    Confline.should_receive(:set_value).with("Recordings_addon_Login", "test_login", 0)
    Confline.should_receive(:set_value).with("Recordings_addon_Password", "test_pass", 0)
    Confline.should_receive(:set_value).with("Recordings_addon_Max_Space", "50", 0)
    Confline.should_receive(:set_value).with("CCShop_show_values_without_VAT_for_user", 1, 0)
    Confline.should_receive(:set_value).with("Server_to_use_for_call_center", 1, 0)
    
    get(:settings_addons_change,
    :ra_use_external_server => "1",
    :ra_ip=>"123.123.123.123",
    :ra_port=>"123",
    :ra_login => "test_login",
    :ra_password => "test_pass",
    :ra_max_space=>"50",
    :CCShop_show_values_without_VAT_for_user => 1,
    :Server_to_use_for_call_center => 1)
    flash[:notice].should eql(_('Settings_saved'))
    response.should redirect_to("http://test.host/functions/settings_addons")
  end

  it "should save settings when REC_active is set to 0" do
    REC_Active = 0
    CC_Active = 0
    CALLC_Active = 0
    Confline.stub!(:set_value)
    Confline.should_not_receive(:set_value).with("Recordings_addon_Use_External_Server", "1", 0)
    Confline.should_not_receive(:set_value).with("Recordings_addon_IP", "123.123.123.123", 0)
    Confline.should_not_receive(:set_value).with("Recordings_addon_Port", "123", 0)
    Confline.should_not_receive(:set_value).with("Recordings_addon_Login", "test_login", 0)
    Confline.should_not_receive(:set_value).with("Recordings_addon_Password", "test_pass", 0)
    Confline.should_not_receive(:set_value).with("Recordings_addon_Max_Space", "50", 0)
    Confline.should_not_receive(:set_value).with("CCShop_show_values_without_VAT_for_user", 1, 0)
    Confline.should_not_receive(:set_value).with("Server_to_use_for_call_center", 1, 0)
    get(:settings_addons_change,
    :ra_use_external_server => "1",
    :ra_ip=>"123.123.123.123",
    :ra_port=>"123",
    :ra_login => "test_login",
    :ra_password => "test_pass",
    :ra_max_space=>"50",
    :CCShop_show_values_without_VAT_for_user => 1,
    :Server_to_use_for_call_center => 1)
    flash[:notice].should eql(_('Settings_saved'))
    response.should redirect_to("http://test.host/functions/settings_addons")
  end

  it "should return error if only :ra_use_external_server => 1 is set" do
    REC_Active = 1
    get(:settings_addons_change, :ra_use_external_server => "1")
    response.should redirect_to("http://test.host/functions/settings_addons")
    flash[:notice].should eql(_('Set_external_Server_options'))
  end
end



describe FunctionsController, ".pbx_function_destroy" do

  before (:each) do
    @dialplan = get_mock_dialplan({:id=>"5"})
  end

  it "should delete pbx function" do
    login_as_admin

    Dialplan.should_receive(:find).with("5").and_return(@dialplan)
    Did.should_receive(:count).with(:all, :conditions=>"dialplan_id = '5'").and_return(0)
    controller.stub!(:pbx_function_delete_extline).with(@dialplan)
    @dialplan.should_receive(:destroy)
    get :pbx_function_destroy, :id =>"5"

  end

  it "should not delete pbx function" do
    login_as_admin

    Dialplan.should_receive(:find).with("5").and_return(@dialplan)
    Did.should_receive(:count).with(:all, :conditions=>"dialplan_id = '5'").and_return(6)
    get :pbx_function_destroy, :id =>"5"

  end

end
