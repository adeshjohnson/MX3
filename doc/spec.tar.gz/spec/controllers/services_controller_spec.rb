require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'services_controller'

describe ServicesController, ".subscriptions" do
  before(:each) do
    @sub1 = get_mock_subscription({:id => 4, :memo=>"AAA"})
    @sub2 = get_mock_subscription({:id => 2, :memo=>"bAAA", :activation_start=>"2000-01-10 20:20:20", :activation_end=>"2001-01-11 20:20:20", :user_id=>"4", :service_id=>"5"})
    @subs = [@sub1, @sub2]
    @subs2 = [@sub2]
    @user = get_mock_user()
    @service = get_mock_service()

  end

  it "shuld find all subscriptions " do
    login_as_admin
    data = {}
    data["year"] = "2008"
    data["month"] = "01"
    data["day"] = "04"
    data["hour"] = "01"
    data["minute"] = "01"

    data2 = {}
    data2["year"] = "2008"
    data2["month"] = "01"
    data2["day"] = "04"
    data2["hour"] = "23"
    data2["minute"] = "59"
    Subscription.stub!(:find_by_sql)
    Service.should_receive(:find).with(:all).and_return([@service])
    User.should_receive(:find).with(:all).and_return([@user])

    Subscription.should_receive(:find_by_sql).with("SELECT services.name as serv_name , users.first_name, users.last_name, users.username, subscriptions.*, devices.device_type,  devices.name, devices.extension, devices.istrunk FROM subscriptions\n          LEFT JOIN users ON(users.id = subscriptions.user_id) \n          LEFT JOIN devices ON(devices.id = subscriptions.device_id)\n          LEFT JOIN services ON(services.id = subscriptions.service_id)\n          WHERE subscriptions.id > '0'  AND subscriptions.activation_start BETWEEN '2008-01-04 00:00:00' AND '2008-01-04 23:59:59'   ").and_return(@subs)
    post "subscriptions",  :date_from => data, :date_till => data2
  end


  it "shuld find by search subscriptions " do
    login_as_admin
    data = {}
    data["year"] = "2008"
    data["month"] = "01"
    data["day"] = "04"
    data["hour"] = "01"
    data["minute"] = "01"

    data2 = {}
    data2["year"] = "2008"
    data2["month"] = "01"
    data2["day"] = "04"
    data2["hour"] = "23"
    data2["minute"] = "59"
    #Subscription.stub!(:find_by_sql)
    Service.should_receive(:find).with(:all).and_return([@service])
    User.should_receive(:find).with(:all).and_return([@user])

    Subscription.should_receive(:find_by_sql).with("SELECT services.name as serv_name , users.first_name, users.last_name, users.username, subscriptions.*, devices.device_type,  devices.name, devices.extension, devices.istrunk FROM subscriptions\n          LEFT JOIN users ON(users.id = subscriptions.user_id) \n          LEFT JOIN devices ON(devices.id = subscriptions.device_id)\n          LEFT JOIN services ON(services.id = subscriptions.service_id)\n          WHERE subscriptions.id > '0'   AND subscriptions.user_id = '4'  AND subscriptions.service_id = '5'  AND subscriptions.activation_start BETWEEN '2008-01-04 00:00:00' AND '2008-01-04 23:59:59'   ").and_return(@subs2)
    post "subscriptions", :s_user => "4", :s_service =>"5",  :date_from => data, :date_till => data2
  end

end


describe ServicesController, ".subscriptions_list" do
  before(:each) do

    @user = get_mock_user(:id=>"6")
    @sub = get_mock_subscription({:id => 4, :user_id=>"6"})
    @subs = [@sub]
  end

  it "subscriptions " do
    login_as_admin

    User.should_receive(:find).with("6").and_return(@user)
    @user.should_receive(:subscriptions).and_return(@subs)
    post "subscriptions_list", :id=>6, :back=>"subscriptions", :s_memo => "@search_memo", :s_service => "@search_service", :s_user => "@search_user", :s_device=>"@search_device", :s_date_from=> "@search_date_from", :s_date_till=>"@search_date_till", :page=>"@page"
    assigns[:page].should eql("@page")
    assigns[:back].should eql("subscriptions")
  end

end


describe ServicesController, ".subscription_edit" do
  before(:each) do

    @user = get_mock_user(:id=>"6")
    @sub = get_mock_subscription({:id => 4, :user_id=>"6"})
    @subs = [@sub]
    @service = get_mock_service()
  end

  it "subscriptions redirect to users" do
    login_as_admin

    Subscription.should_receive(:find).with("4").and_return(@sub)
    @sub.should_receive(:user).and_return(@user)
    Service.should_receive(:find).with(:all, {:order=>"name ASC"}).and_return([@service])
    post "subscription_edit", :id=>4
    assigns[:page].should_not eql("@page")
    assigns[:back].should_not eql("subscriptions")
  end

  it "subscriptions redirect to services" do
    login_as_admin

    Subscription.should_receive(:find).with("4").and_return(@sub)
    @sub.should_receive(:user).and_return(@user)
    Service.should_receive(:find).with(:all, {:order=>"name ASC"}).and_return([@service])
    post "subscription_edit", :id=>4, :back=>"subscriptions", :s_memo => "@search_memo", :s_service => "@search_service", :s_user => "@search_user", :s_device=>"@search_device", :s_date_from=> "@search_date_from", :s_date_till=>"@search_date_till", :page=>"@page"
    assigns[:page].should eql("@page")
    assigns[:back].should eql("subscriptions")
  end
end

describe ServicesController, ".subscription_update" do
  before(:each) do

    @user = get_mock_user(:id=>"6")
    @sub = get_mock_subscription({:id => 4, :user_id=>"6"})
    @subs = [@sub]
    @service = get_mock_service()
  end

  it "subscriptions redirect to users" do
    login_as_admin
    data = {}
    data["year"] = "2008"
    data["month"] = "01"
    data["day"] = "04"
    data["hour"] = "01"
    data["minute"] = "01"

    data2 = {}
    data2["year"] = "2008"
    data2["month"] = "01"
    data2["day"] = "04"
    data2["hour"] = "23"
    data2["minute"] = "59"
    Subscription.should_receive(:find).with("4").and_return(@sub)
    @sub.should_receive(:user).and_return(@user)
    @sub.should_receive(:memo=).with("4")
    @sub.should_receive(:activation_start=)
    @sub.should_receive(:activation_end=)
    @sub.should_receive(:save)
    #Service.should_receive(:find).with(:all, {:order=>"name ASC"}).and_return([@service])
    post "subscription_update", :id=>4, :memo => "4", :activation_start => data, :activation_end => data2
    assigns[:page].should_not eql("@page")
    assigns[:back].should_not eql("subscriptions")
  end

  it "subscriptions redirect to services" do
    login_as_admin
    data = {}
    data["year"] = "2008"
    data["month"] = "01"
    data["day"] = "04"
    data["hour"] = "01"
    data["minute"] = "01"

    data2 = {}
    data2["year"] = "2008"
    data2["month"] = "01"
    data2["day"] = "04"
    data2["hour"] = "23"
    data2["minute"] = "59"
    Subscription.should_receive(:find).with("4").and_return(@sub)
    #@sub.should_receive(:user).and_return(@user)
    @sub.should_receive(:memo=).with("4")
    @sub.should_receive(:activation_start=)
    @sub.should_receive(:activation_end=)
    @sub.should_receive(:save)
    #Service.should_receive(:find).with(:all, {:order=>"name ASC"}).and_return([@service])
    post "subscription_update", :id=>4, :memo=>"4",  :activation_start => data, :activation_end => data2, :back=>"subscriptions", :s_memo => "@search_memo", :s_service => "@search_service", :s_user => "@search_user", :s_device=>"@search_device", :s_date_from=> "@search_date_from", :s_date_till=>"@search_date_till", :page=>"@page"
    assigns[:page].should eql("@page")
    assigns[:back].should eql("subscriptions")
  end
end


describe ServicesController, ".subscription_destroy" do
  before(:each) do

    @user = get_mock_user(:id=>"6")
    @sub = get_mock_subscription({:id => 4, :user_id=>"6"})
    @subs = [@sub]
    @service = get_mock_service()
  end

  it "subscriptions redirect to users" do
    login_as_admin
    Subscription.should_receive(:find).with("4").and_return(@sub)
    @sub.should_receive(:destroy)
    post "subscription_destroy", :id=>4, :memo => "4"
    assigns[:page].should_not eql("@page")
    assigns[:back].should_not eql("subscriptions")
  end

  it "subscriptions redirect to services" do
    login_as_admin

    Subscription.should_receive(:find).with("4").and_return(@sub)
    @sub.should_receive(:destroy)
    post "subscription_destroy", :id=>4, :memo=>"4",  :back=>"subscriptions", :s_memo => "@search_memo", :s_service => "@search_service", :s_user => "@search_user", :s_device=>"@search_device", :s_date_from=> "@search_date_from", :s_date_till=>"@search_date_till", :page=>"@page"
    assigns[:page].should eql("@page")
    assigns[:back].should eql("subscriptions")
  end
end
