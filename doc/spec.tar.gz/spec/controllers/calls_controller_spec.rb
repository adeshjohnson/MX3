require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'calls_controller'


describe CallsController, "aggregate" do

  before(:each) do
    login_as_admin
  end

  it "should run without any params" do
    User.should_receive(:find).and_return([])
    Terminator.should_receive(:find).and_return([])
    Call.should_receive(:find_by_sql).and_return([])
    get :aggregate
    assigns[:total_pages].should eql(0)
  end

end


describe CallsController, "summary" do

  before(:each) do
    login_as_admin
  end

  it "should run without any params" do
    User.should_receive(:find).and_return([])
    Terminator.should_receive(:find).and_return([])
    Call.should_receive(:summary_by_terminator).and_return([])
    Call.should_receive(:summary_by_originator).and_return([])
    get :summary
  end

end
