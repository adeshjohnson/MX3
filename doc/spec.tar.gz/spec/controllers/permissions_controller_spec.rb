require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'permissions_controller'

describe PermissionsController, ".groups_list" do

  before (:each) do
  end

  it "should run without exceptions" do
    login_as_admin
    AccGroup.should_receive(:find).with(:all).and_return([])
    get :groups_list
    assigns(:groups).should eql([])
  end

end

describe PermissionsController, ".group_create" do

  before (:each) do
    login_as_admin
    @group = get_mock_acc_group
  end

  it "should confirm when group was created" do
    @group.should_receive(:save).and_return(true)
    AccGroup.should_receive(:new).with(:name => "new_group").and_return(@group)
    post :group_create, :name => "new_group"
    flash[:notice].should eql(_('Group_was_created'))
  end

  it "should confirm if group was not created" do
    @group.should_receive(:save).and_return(false)
    AccGroup.should_receive(:new).with(:name => "new_group").and_return(@group)
    post :group_create, :name => "new_group"
    flash[:notice].should eql(_('group_was_not_created'))
  end

end

describe PermissionsController, ".group_destory" do

  before (:each) do
    login_as_admin
    @group = get_mock_acc_group
  end

  it "should confirm if group was destroyed" do
    @group.should_receive(:destroy).and_return(true)
    AccGroup.should_receive(:find_by_id).and_return(@group)
    User.should_receive(:update_all)
    AccGroupRight.should_receive(:delete_all)
    get :group_destory, :id => 12
    flash[:notice].should eql(_('Group_was_destroyed'))
    response.should redirect_to("http://test.host/permissions/groups_list")
  end

  it "should confirm if group was not destroyed" do
    @group.should_receive(:destroy).and_return(false)
    AccGroup.should_receive(:find_by_id).and_return(@group)
    User.should_not_receive(:update_all)
    AccGroupRight.should_not_receive(:delete_all)
    get :group_destory, :id => 12
    flash[:notice].should eql(_('Group_was_not_destroyed'))
    response.should redirect_to("http://test.host/permissions/groups_list")
  end

end

describe PermissionsController, ".group_edit" do

  before (:each) do
    login_as_admin
    @group = get_mock_acc_group
  end

  it "should work without exceptions" do
    AccGroup.should_receive(:find).with(:first, :include => [:acc_group_rights], :conditions => ["acc_groups.id = ?", "12"]).and_return(@group)
    AccRight.should_receive(:find).with(:all).and_return([])
    get :group_edit, :id => 12
    assigns[:page_title].should eql(_("group_edit")+": Bandomasis_triusis")
  end

end

describe PermissionsController, ".group_update" do

  before (:each) do
    login_as_admin
    @group = get_mock_acc_group(:id => 12 )
    @right =  get_mock_acc_right(:id => 45)
    @right2 = get_mock_acc_right(:id=> 12)

    @group_right = get_mock_acc_group_right(:id => 1, :acc_right_id => 45)
    @group_right2 = get_mock_acc_group_right(:id => 2)
  end

  it "should work without errors" do
    @group.should_receive(:name=).with("new_name")
    @group.should_receive(:save)
    AccRight.should_receive(:find).with(:all).and_return([])
    AccGroup.should_receive(:find).with(:first, :include => [:acc_group_rights], :conditions => ["acc_groups.id = ?", "12"]).and_return(@group)
    post :group_update, :id => 12, :name => "new_name"
    flash[:notice].should eql(_('Group_was_updated'))
    response.should redirect_to("http://test.host/permissions/group_edit/12")
  end

  it "should create group right if it does not exists" do
    @group_right.should_receive(:save).and_return(true)
    @group_right.should_receive(:value=).with(1)
    @group_right2.should_receive(:value=).with(1)
    @group_right2.should_receive(:acc_group=).with(@group)
    @group_right2.should_receive(:acc_right=).with(@right2)
    @group_right2.should_receive(:save).and_return(true)

    @group.should_receive(:acc_group_rights).twice.and_return([@group_right])
    @group.should_receive(:name=).with("new_name")
    @group.should_receive(:save)
    AccGroupRight.should_receive(:new).and_return(@group_right2)
    AccRight.should_receive(:find).with(:all).and_return([@right, @right2 ])
    AccGroup.should_receive(:find).with(:first, :include => [:acc_group_rights], :conditions => ["acc_groups.id = ?", "12"]).and_return(@group)
    post :group_update, :id => 12, :name => "new_name", :right_12 => 1 , :right_45 => 1
  end


end




