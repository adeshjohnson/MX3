require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'stats_controller'

describe StatsController, ".calls_by_scr" do
  before(:each) do
    #@direction = mock_model(Direction, :id =>3, :name=>"AAA", :code=>"AAA")
    @direction = get_mock_direction({:id => 4, :code=>"AAA"})
    @mock_cal = get_mock_call({:prefix => 488})
    @mock_cal2 = get_mock_call({:prefix => 488, :provider_id => "5"})
    @provider = get_mock_provider({:id => "5"})
    @mock_destination = get_mock_destination({:prefix => 488, :direction_code=>"AAA"})
    @directions =[@direction]
    @mock_calls = [@mock_cal,@mock_cal2]
    @providers=[@provider]
  end

  it "should find calls all" do
    login_as_admin
    data = {}
    data["year"] = "2008"
    data["month"] = "01"
    data["day"] = "04"
    data["hour"] = "01"
    data["minute"] = "01"

    data2 = {}
    data2["year"] = "2008"
    data2["month"] = "01"
    data2["day"] = "04"
    data2["hour"] = "23"
    data2["minute"] = "59"
    Provider.should_receive(:find).with(:all, :order => "name ASC").and_return(@providers)
    Direction.should_receive(:find).with(:all, :order => "name ASC").and_return(@directions)
    post "calls_by_scr", :date_from => data, :date_till => data2, :provider_id => -1 , :country_id => -1
  end

  it "should find calls by country" do
    login_as_admin
    data = {}
    data["year"] = "2008"
    data["month"] = "01"
    data["day"] = "04"
    data["hour"] = "01"
    data["minute"] = "01"

    data2 = {}
    data2["year"] = "2008"
    data2["month"] = "01"
    data2["day"] = "04"
    data2["hour"] = "23"
    data2["minute"] = "59"
    Provider.should_receive(:find).with(:all, :order => "name ASC").and_return(@providers)
    Direction.should_receive(:find).with("#{@direction.id}").and_return(@direction)
    Direction.should_receive(:find).with(:all, :order => "name ASC").and_return(@directions)
    post "calls_by_scr", :date_from => data, :date_till => data2, :provider_id => -1 , :country_id => @direction.id
  end


  it "should find calls by provider" do
    login_as_admin
    data = {}
    data["year"] = "2008"
    data["month"] = "01"
    data["day"] = "04"
    data["hour"] = "01"
    data["minute"] = "01"

    data2 = {}
    data2["year"] = "2008"
    data2["month"] = "01"
    data2["day"] = "04"
    data2["hour"] = "23"
    data2["minute"] = "59"
    Provider.should_receive(:find).with("#{@provider.id}").and_return(@provider)
    Provider.should_receive(:find).with(:all, :order => "name ASC").and_return(@providers)
    Direction.should_receive(:find).with(:all, :order => "name ASC").and_return(@directions)
    post "calls_by_scr", :date_from => data, :date_till => data2, :provider_id => @provider.id , :country_id => -1
  end


  it "should find calls by provider and country" do
    login_as_admin
    data = {}
    data["year"] = "2008"
    data["month"] = "01"
    data["day"] = "04"
    data["hour"] = "01"
    data["minute"] = "01"

    data2 = {}
    data2["year"] = "2008"
    data2["month"] = "01"
    data2["day"] = "04"
    data2["hour"] = "23"
    data2["minute"] = "59"
    Provider.should_receive(:find).with("#{@provider.id}").and_return(@provider)
    Provider.should_receive(:find).with(:all, :order => "name ASC").and_return(@providers)
    Direction.should_receive(:find).with("#{@direction.id}").and_return(@direction)
    Direction.should_receive(:find).with(:all, :order => "name ASC").and_return(@directions)
    post "calls_by_scr", :date_from => data, :date_till => data2, :provider_id => @provider.id , :country_id => @direction.id
  end


end



describe StatsController, ".load_stats" do
  before(:each) do

    @moc_data1 = mock_model(Time, :Y=>"2001", :m=>"01", :d=>"01", :H=>"02", :M=>"02", :S=>"02")

    @mock_cal_ansv =  mock_model(Call , :id =>4, :calldate=>@moc_data1 , :disposition=>"ANSWERED", :duration => "100", :c => 1, :provider_id => 9, :did_id => 8, :user_id =>7, :src_device_id=>6)
    @mock_cal_noansv =  mock_model(Call , :id =>5, :calldate=>@moc_data1, :disposition=>"NO ANSWERED", :duration => "100", :c=>1, :provider_id => 4, :did_id =>4, :user_id =>4, :src_device_id=>4)
    @mock_calls = [@mock_cal_ansv,@mock_cal_noansv]
    @mock_a_calls =[@mock_cal_ansv]
    @mock_provider = get_mock_provider({:id => 5})
    @mock_user = get_mock_user({:id => 5})
    @mock_servers = get_mock_server({:id=>3})
    @mock_did = get_mock_did({:id => 5})
    @mock_device = get_mock_device({:id => 5})
    @mock_providers = [@mock_privider]
    @mock_users = [@mock_user]
    @mock_dids = [@mock_did]
    @mock_devices = [@mock_device]
    @mock_servers =[@mock_server]
    #@moc_data1.stub!(:to_time)
    Time.stub!(:to_time)
  end

  it "should find all calls " do
    login_as_admin
    data = {}
    data["year"] = "2001"
    data["month"] = "01"
    data["day"] = "01"
    data["hour"] = "01"
    data["minute"] = "01"

    a1 = "2001-01-01 01:01:00"
    Provider.should_receive(:find).with(:all).and_return(@mock_providers)
    Did.should_receive(:find).with(:all).and_return(@mock_dids)
    User.should_receive(:find).with(:all).and_return(@mock_users)
    Server.should_receive(:find).with(:all).and_return(@mock_servers)
    sql ="SELECT calldate, duration FROM calls\n                 WHERE calldate BETWEEN '2001-01-01 00:00:00' AND '2001-01-01 23:59:59' AND disposition = 'ANSWERED' \n                 GROUP BY calldate "
    sql2 ="SELECT calldate FROM calls \n                   WHERE calldate BETWEEN '2001-01-01 00:00:00' AND '2001-01-01 23:59:59' \n                   GROUP BY calldate "
    Call.should_receive(:find_by_sql).with(sql).and_return(@mock_a_calls)
    Call.should_receive(:find_by_sql).with(sql2).and_return(@mock_calls)
    @moc_data1.should_receive(:strftime).exactly(3).times.with("%H")
    @moc_data1.should_receive(:strftime).exactly(3).times.with("%M")

    post "load_stats", :date_from => data, :s_user =>-1, :s_device => -1, :s_did => -1, :s_provider => -1
  end

  it "should find all calls by provider " do
    login_as_admin
    data = {}
    data["year"] = "2001"
    data["month"] = "01"
    data["day"] = "01"
    data["hour"] = "01"
    data["minute"] = "01"


    a1 = "2001-01-01 01:01:00"
    Provider.should_receive(:find).with(:all).and_return(@mock_providers)
    Did.should_receive(:find).with(:all).and_return(@mock_dids)
    User.should_receive(:find).with(:all).and_return(@mock_users)
    Server.should_receive(:find).with(:all).and_return(@mock_servers)
    sql = "SELECT calldate, duration FROM calls\n                 WHERE calldate BETWEEN '2001-01-01 00:00:00' AND '2001-01-01 23:59:59' AND disposition = 'ANSWERED'  AND provider_id =  '9' \n                 GROUP BY calldate "
    sql2 ="SELECT calldate FROM calls \n                   WHERE calldate BETWEEN '2001-01-01 00:00:00' AND '2001-01-01 23:59:59'  AND provider_id =  '9' \n                   GROUP BY calldate "
    Call.should_receive(:find_by_sql).with(sql).and_return(@mock_a_calls)
    Call.should_receive(:find_by_sql).with(sql2).and_return(@mock_calls)
    @moc_data1.should_receive(:strftime).exactly(3).times.with("%H")
    @moc_data1.should_receive(:strftime).exactly(3).times.with("%M")

    post "load_stats", :date_from => data, :s_user =>-1, :s_device => -1, :s_did => -1, :s_provider => 9
  end

  it "should find all calls by provider, user, did, device, direction, server " do
    login_as_admin
    data = {}
    data["year"] = "2001"
    data["month"] = "01"
    data["day"] = "01"
    data["hour"] = "01"
    data["minute"] = "01"


    a1 = "2001-01-01 01:01:00"
    Provider.should_receive(:find).with(:all).and_return(@mock_providers)
    Did.should_receive(:find).with(:all).and_return(@mock_dids)
    User.should_receive(:find).with(:all).and_return(@mock_users)
    Server.should_receive(:find).with(:all).and_return(@mock_servers)
    sql = "SELECT calldate, duration FROM calls\n                 WHERE calldate BETWEEN '2007-01-01 00:00:00' AND '2007-01-01 23:59:59' AND disposition = 'ANSWERED'   AND server_id = '3'   AND user_id = '7' AND did_id > '0' AND callertype = 'Outside'  AND provider_id =  '9'  AND did_id=  '8' \n                 GROUP BY calldate "
    sql2 ="SELECT calldate FROM calls \n                   WHERE calldate BETWEEN '2007-01-01 00:00:00' AND '2007-01-01 23:59:59'   AND server_id = '3'   AND user_id = '7' AND did_id > '0' AND callertype = 'Outside'  AND provider_id =  '9'  AND did_id=  '8' \n                   GROUP BY calldate "
    Call.should_receive(:find_by_sql).with(sql).and_return(@mock_a_calls)
    Call.should_receive(:find_by_sql).with(sql2).and_return(@mock_calls)
    @moc_data1.should_receive(:strftime).exactly(3).times.with("%H")
    @moc_data1.should_receive(:strftime).exactly(3).times.with("%M")

    post "load_stats", :date => data, :s_user =>7, :s_device => 6, :s_did => 8, :s_provider => 9, :s_direction=>"mixed", :s_server=>3
  end

end

describe StatsController, ".call_list_to_pdf" do

  before(:each) do

  end

  it "should work without errors" do
    login_as_admin
    user = get_mock_user
    user.should_receive(:calls).and_return([get_mock_call, get_mock_call])
    User.should_receive(:find).with(0).and_return(user)
    get :call_list_to_pdf, :date_from=>"2005-02-22 00:00:00" , :date_till=>"2009-01-22 23:59:59",  :call_type=>"all"
  end

end

describe StatsController, ".generate_profit_pdf" do

  before (:each) do
  end

  it "should " do
  end

end


describe StatsController, ".hangup_calls" do

  before(:each) do
    @prov = get_mock_provider()
    @usr = get_mock_user()
    @hang = get_mock_hangupcausecode()
    @dir = get_mock_direction()
  end

  it "should find calls by hangup" do
    login_as_admin
    Provider.should_receive(:find).with("2").and_return(@prov)
    Provider.should_receive(:find).with(:all, :order => 'name ASC').and_return([@prov])
    Direction.should_receive(:find).with("44").and_return(@dir)
    Direction.should_receive(:find).with(:all, :order => "name ASC").and_return([@dir])
    Hangupcausecode.should_receive(:find).with(3).and_return(@hang)
    cond =" ((calls.provider_id = '#{2}' and calls.callertype = 'Local') OR (calls.did_provider_id = '#{2}' and calls.callertype = 'Outside')) AND "
    des= 'destinations, '
    descond =" AND calls.prefix = destinations.prefix AND destinations.direction_code ='#{@dir.code}' "

    Call.should_receive(:find_by_sql).and_return([get_mock_call()])
    get :hangup_calls, :direction=>"44" , :provider_id=>"2",  :hid=>"3"
  end

end

describe StatsController, ".providers" do

  before(:each) do
    @prov = get_mock_provider()
    @des = get_mock_destination()
    @dir = get_mock_direction()
  end

  it "should find calls by provider and prefix" do
    login_as_admin
    @des.should_receive(:direction).and_return(@dir)
    @des.should_receive(:name).and_return("bla")
    Destination.should_receive(:find).with(:first, :conditions => "prefix = SUBSTRING('#{370}', 1, LENGTH(destinations.prefix))", :order => "LENGTH(destinations.prefix) DESC").and_return(@des)
    cond = " AND calls.prefix = '#{370}' "
    Provider.should_receive(:find_by_sql).and_return([@prov])
    get :providers, :search=>"370"
  end

end


describe StatsController, ".providers_stats" do

  before(:each) do
    @prov = get_mock_provider()
    @des = get_mock_destination()
    @dir = get_mock_direction()
    @time = "2007-01-01".to_date
  end

  it "should find calls by provider and prefix in providers_stats" do
    login_as_admin
    Destination.should_receive(:find).with(:first, :conditions => "prefix = SUBSTRING('#{370}', 1, LENGTH(destinations.prefix))", :order => "LENGTH(destinations.prefix) DESC").and_return(@des)
    @des.should_receive(:direction).and_return(@dir)
    @des.should_receive(:name).and_return("bla")
    cond = " AND calls.prefix = '#{370}' "
    Provider.should_receive(:find_by_sql).and_return([@prov])
    @prov.should_receive(:answered).exactly(2).times.and_return(44)
    @prov.should_receive(:pcalls).exactly(5).times.and_return(44)
    @prov.should_receive(:busy).exactly(2).times.and_return(44)
    @prov.should_receive(:failed).exactly(2).times.and_return(44)
    @prov.should_receive(:no_answer).exactly(2).times.and_return(44)
    t = Time.now
    Time.stub!(:mktime).with("2007", "01", "01").and_return(@time)
    Time.stub!(:mktime).with(t.year, t.month, t.hour).and_return(@time)
    Time.should_receive(:mktime).with("2010", 13, "01")
    get :providers_stats, :search=>"370", :id=>4
  end

end


describe StatsController, ".show_user_stats" do

  before(:each) do
    @call = get_mock_call()
    @user = get_mock_user()
    @dir = get_mock_direction()
    @time = "2007-01-01".to_date
    @calls = [@call]
    @users = [@user]

  end

end

describe StatsController, ".action_log" do

  it "should work without exceptions" do
    login_as_admin
    Action.stub!(:find)
    Action.should_receive(:find).with(:all, :select => "DISTINCT(actions.action)").and_return([])
    Action.should_receive(:find).with(:all, :select => "DISTINCT(target_type)", :conditions => "target_type != '' AND target_type IS NOT NULL ").and_return([])
    get :action_log
  end

end

describe StatsController, ".providers_calls" do
  fixtures :calls
  before(:each) do
    login_as_admin
    Provider.should_receive(:find_by_id).with(6).and_return(get_mock_provider(:id => 6))
    User.should_receive(:find_by_id).with(0).and_return(get_mock_user)
    Currency.should_receive(:find).with(:first, :conditions => ["name = ?", "LTL"]).twice.and_return(get_mock_currency)
  end

  it "should assign default values to @options" do
    session[:stats_providers_calls] = nil
    session[:year_from] = 2005
    Confline.should_receive(:get_value).with("Items_Per_Page", 0).and_return("50")
    get :providers_calls, :id => 6
    assigns[:options][:total_pages].should eql(1)
    assigns[:options][:page].should eql(1)
    assigns[:exchange_rate].should eql(1.0)
    assigns[:calls].size.should eql(1)
    assigns[:total_calls].should eql(1)
  end

  it "should assign default values from session when session is set" do
    session[:stats_providers_calls] = {
      :page => 3,
      :direction => "outgoing",
      :items_per_page => 45
    }
    Confline.should_not_receive(:get_value)

    get :providers_calls, :id => 6
    assigns[:options][:total_pages].should eql(0)
    assigns[:options][:page].should eql(3)
    assigns[:exchange_rate].should eql(1.0)
    MorLog.my_debug(Call.count())
  end
  
  it "should accept params" do
    Confline.should_receive(:get_value).with("Items_Per_Page", 0).and_return("50") 
    get :providers_calls, :id => 6, :direction => "outgoing", :call_type => "ANSWERED"
    assigns[:calls].size.should eql(1)
    assigns[:total_calls].should eql(1)
  end
end
