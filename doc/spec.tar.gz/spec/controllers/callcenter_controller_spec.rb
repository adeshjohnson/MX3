require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'callcenter_controller'

def mock_client
  mock_model(CcClient)
end

describe CallcenterController, ".group_list" do

  before(:each) do
    @api_controller = CallcenterController.new
  end

  it "should display correct menu on empty list" do
    login_as_admin
    @groups = []
    get :group_list
  end
end

describe CallcenterController, ".next_client" do
  before(:each) do
    @mock_client = mock_model(CcClient, :id => 12)
  end

  it "should return correct user for task" do
    @mock_task_client = mock_model(CcTask, :get_next_client =>@mock_client, :id => 13)
    CcTask.should_receive(:find).and_return(@mock_task_client)

    login_as_admin
    get "next_client", :id => 13
    response.should redirect_to("http://test.host/callcenter/agent_workplace?client=12&task=13")
  end

  it "should anounce if there is no one to call to" do
    @mock_task = mock_model(CcTask, :get_next_client => nil, :id => 13)
    CcTask.should_receive(:find).twice.and_return(@mock_task)
    login_as_admin
    get "next_client", :id =>13
    flash[:notice].should eql("No more Clients to call to")
    response.should redirect_to("http://test.host/callcenter/task_list")
    get "next_client", :id =>13, :from_action => "next_client", :from_client => "3", :from_task => "22"
    flash[:notice].should eql("No more Clients to call to")
    response.should redirect_to("http://test.host/callcenter/next_client/13?client=3&task=22")
  end
end

describe CallcenterController, "group_list" do
  before(:each) do

  end
  it "should open all groups" do
  end
end

describe CallcenterController, "group_create" do

  before(:each) do

  end

  it "should create group with correct name" do
    login_as_admin
    data = {}
    data["name"] = "Test_spec_group"
    get "group_create", :group => data
    flash[:notice].should eql("Group was created")
    response.should redirect_to("http://test.host/callcenter/group_list")
  end

  it "should not create group with no name" do
    login_as_admin
    data = {}
    data["name"] = ""
    get "group_create", :group => data
    flash[:notice].should eql("Group was not created")
    response.should redirect_to("http://test.host/callcenter/group_list")
  end
end

describe CallcenterController, ".group_update," do

  before(:each) do
    @group = CcGroup.new
    @group.name = "test"
    @group.save.should eql(true)
  end

  it "should update group with correct name" do
    login_as_admin
    data = {}
    data["name"] = "Test_spec_group"
    get "group_update", :group => data, :id => @group.id
    flash[:notice].should eql("Group was updated")
    response.should redirect_to("http://test.host/callcenter/group_list")
  end

  it "should not update group with no name" do
    login_as_admin
    data = {}
    data["name"] = ""
    get "group_update", :group => data, :id => @group.id
    flash[:notice].should eql("Group was not updated")
    response.should redirect_to("http://test.host/callcenter/group_list")
  end

end

describe CallcenterController, ".group_list" do

  it "should set correct params" do
    login_as_admin
    CcGroup.should_receive(:find).with(:all).and_return([])
    get "group_list"
    assigns(:page_icon).should == "group.png"
  end
end

describe CallcenterController, ".group_destroy," do

  before(:each) do
    @group = CcGroup.new
    @group.name = "test"
    @group.save.should eql(true)
  end

  it "should get destroyed" do
    login_as_admin
    data = {}
    get "group_destroy", :id => @group.id
    flash[:notice].should eql("Group was destroyed")
    response.should redirect_to("http://test.host/callcenter/group_list")
  end

  it "should not get destroyed" do
    @mock_task = mock_model(CcTask, :destroy => false, :id => @group.id)
    CcGroup.should_receive(:find).and_return(@mock_task)
    login_as_admin
    data = {}
    get "group_destroy", :id => @group.id
    flash[:notice].should eql("Group was not destroyed")
    response.should redirect_to("http://test.host/callcenter/group_list")
  end
end

describe CallcenterController, ".group_edit" do
  before(:each) do
    @group = CcGroup.new
    @group.name = "test"
    @group.save.should eql(true)
  end

  it "should set correct params" do
    login_as_admin
    CcGroup.should_receive(:find).and_return([])
    get "group_edit", :id => @group.id
    assigns(:page_icon).should == "group.png"
    assigns(:group).should == []
  end
end

describe CallcenterController, ".client_update" do
  before(:each) do
    @address =  Address.new
    @address.direction_id =" params[:direction].to_s"
    @address.state = "params[:state].to_s"
    @address.county = "params[:county].to_s"
    @address.city = "params[:city].to_s"
    @address.postcode = "params[:postcode].to_s"
    @address.address = "params[:address].to_s"
    @address.phone = "params[:phone].to_s"
    @address.mob_phone = "params[:mob_phone].to_s"
    @address.fax = "params[:fax].to_s"
    @address.email =" params[:email].to_s"
    @address.save.should eql(true)
    @client = CcClient.new
    @client.name = "params[:name].to_s"
    @client.client_id = "params[:clientid].to_s"
    @client.agreement_number = "params[:agreement_number].to_s"
    @client.agreement_date = "params[:agreement_date].to_s"
    @client.vat_code = "params[:vat_code].to_s"
    @client.vat_percent = "params[:vat_percent].to_s"
    @client.main_contact_id = 1
    @client.user_id = "-1"
    @client.address_id = @address.id
    @client.delivery_address_id = @address.id
    @client.save.should eql(true)


    @mock_field_data = mock_model(CcClientFieldData, :id =>3, :cc_client_field_id=>6, :cc_client_id=>@client.id, :value=>"tetst")
    @mock_field_data.stub!(:destroy)
    @mock_field_data2 = mock_model(CcClientFieldData, :id =>4, :cc_client_field_id=>8, :cc_client_id=>@client.id, :value=>"tetst")
    @mock_field_data2.stub!(:destroy)
    @mock_field_datas = [@mock_field_data,@mock_field_data2]
    @mock_task = mock_model(CcTask, :id => 23)
    CcTask.should_receive(:find).with(:first, :conditions => "id = 23").and_return(@mock_task)
    CcClientFieldData.should_receive(:find).with(:all, :conditions => "cc_client_id = '#{@client.id}'").and_return(@mock_field_datas)
  end

  it "should set correct params" do
    login_as_admin
    #CcTask.should_receive(:find).with(:first, :conditions => "id = 23").and_return([])
    post "client_update", :id => @client.id,:first_name => "test" , :last_name=>"testl", :clientid=>"20", :agreement_number=>"34", :vat_number=>"3334", :vat_procent=>"23", :agent_id=>"3", :task => 23
    assigns(:client).should == @client
  end

  it "should set correct params" do
    login_as_admin
    CcClientFieldData.should_receive(:find).with(:first, :conditions => "cc_client_field_id = '#{5}' and cc_client_id = '#{@client.id}' ").and_return(@mock_field_data)
    @mock_field_data.should_receive(:value=)
    @mock_field_data.should_receive(:save)
    post "client_update", :id => @client.id,:first_name => "test" , :last_name=>"testl", :clientid=>"20", :agreement_number=>"34", :vat_number=>"3334", :vat_procent=>"23", :agent_id=>"3", :task => 23, :field5 =>"erw"
    assigns(:client).should == @client
  end

  it "should create" do
    login_as_admin
    CcClientFieldData.should_receive(:find).with(:first, :conditions => "cc_client_field_id = '#{6}' and cc_client_id = '#{@client.id}' ").and_return(@mock_field_data)
    @mock_field_data.should_receive(:value=)
    @mock_field_data.should_receive(:save)
    post "client_update", :id => @client.id,:first_name => "test" , :last_name=>"testl", :clientid=>"20", :agreement_number=>"34", :vat_number=>"3334", :vat_procent=>"23", :agent_id=>"3", :task => 23, :field6 =>"erw"
    assigns(:client).should == @client
  end

  it "should delete" do
    login_as_admin
    CcClientFieldData.should_receive(:find).with(:first, :conditions => "cc_client_field_id = '#{6}' and cc_client_id = '#{@client.id}' ").and_return(@mock_field_data)
    @mock_field_data.should_receive(:value=)
    @mock_field_data.should_receive(:save)
    @mock_field_data2.should_receive(:destroy)
    post "client_update", :id => @client.id,:first_name => "test" , :last_name=>"testl", :clientid=>"20", :agreement_number=>"34", :vat_number=>"3334", :vat_procent=>"23", :agent_id=>"3", :task => 23, :field6 =>"erw"
    assigns(:client).should == @client
  end
end

describe CallcenterController, ".agent_workplace" do

  before(:each) do
    @mock_address = mock_model(Address)
    @mock_delivery_address = mock_model(Address)
    @mock_client = mock_model(CcClient, :name => "Testas",:delivery_address => @mock_delivery_address, :address => @mock_address, :id => 12)
    @mock_task = mock_model(CcTask, :id =>13)
  end

  it "should run without errors" do
    login_as_admin
    #CcClient.should_receive(:find)
    CcClient.should_receive(:find).with(:first, :conditions => "id = 12").and_return(@mock_client)
    CcTask.should_receive(:find).with(:first, :conditions => "id = 13").and_return(@mock_task)
    CcForm.should_receive(:get_all_fields).with(@mock_task, "12").and_return([])
    @mock_client.should_receive(:get_all_fields).with().and_return([])
    CcPlan.should_receive(:get_plans_with_user).with("12").and_return([])
    CcAction.should_receive(:find).with(:all, :conditions=>"cc_task_id='13' AND cc_client_id='12'").and_return([])
    CcContact.should_receive(:find).with(:all, :conditions => "cc_client_id = 12").and_return([])
    session[:user_cc_agent] = 1
    get "agent_workplace", :client => 12, :task => 13
    assigns(:page_icon).should == 'call.png'
  end

end

describe CallcenterController, ".clients" do
  before(:each) do
    session[:layout_t] = 'callc'
    @mock_client = mock_model(CcClient, :name => "1", :client_id => "1",:agreement_number => "1", :agreement_date => "2000-02-02",:vat_code=>"1", :vat_percent=>"1", :user_id => "1", :address_id => 1, :main_contact_id => 12, :id => 12)
    @client = CcClient.new
    @client.name = "1"
    @client.client_id = "1"
    @client.agreement_number = "1"
    @client.agreement_date = "2000-02-02"
    @client.vat_code = "1"
    @client.vat_percent = "1"
    @client.user_id = "1"
    @client.address_id = 1
    @client.main_contact_id = 12
    @client.save.should eql(true)

    @client2 = CcClient.new
    @client2.name = "2"
    @client2.client_id = "2"
    @client2.agreement_number = "2"
    @client2.agreement_date = "2001-01-01"
    @client2.vat_code = "2"
    @client2.vat_percent = "2"
    @client2.user_id = "-1"
    @client2.address_id = 2
    @client2.main_contact_id = 12
    @client2.save.should eql(true)
    @clients = CcClient.find(:all)
    @clients1 = CcClient.find(:all, :conditions=>"id = #{@client.id}")
    @clients2 = CcClient.find(:all, :conditions=>"id = #{@client2.id}")
    @mock_field = mock_model(CcClientField, :name => "Testas",:fieldtype => "Textfield", :inner_field_id => 0, :id => "1", :default_value=>"")
    @mock_field2 = mock_model(CcClientField, :name => "Testas",:fieldtype => "Textfield", :inner_field_id => 0, :id => 2, :default_value=>"ttt")
    @mock_fields = [@mock_field]
    @mock_field_data = mock_model(CcClientFieldData, :id => 6 ,:cc_client_field_id => "1", :value => "a", :cc_client_id =>  @client.id)
    @mock_field_data1 = mock_model(CcClientFieldData, :id => 7 ,:cc_client_field_id => "2", :value => "b", :cc_client_id =>  @client.id)
    @mock_field_datas = [@mock_field_data]
    @mock_clients = [@mock_client]
  end

  it "should find all" do
    login_as_admin
    post "clients"
    assigns(:clients).should == @clients
  end

  it "should find by first name" do
    login_as_admin
    post "clients", :s_name=>@client.name
    assigns(:clients).should == @clients1
  end

  it "should find by agreement_number" do
    login_as_admin
    post "clients", :s_agr_number=>@client.agreement_number
    assigns(:clients).should == @clients1
  end

  it "should find by vat_number" do
    login_as_admin
    post "clients", :s_vat=>@client.vat_code
    assigns(:clients).should == @clients1
  end

  it "should find by vat_percent" do
    login_as_admin
    post "clients", :s_vat_percent=>@client.vat_percent
    assigns(:clients).should == @clients1
  end

  it "should find by clientid" do
    login_as_admin
    post "clients", :s_client_id=>@client.client_id
    assigns(:clients).should == @clients1
  end

  it "should find by agreement_date" do
    login_as_admin
    post "clients", :s_date=> @client.agreement_date.to_s
    assigns(:clients).should == @clients1
  end

  it "should find by agent" do
    login_as_admin
    post "clients", :s_agent_id=>@client.user_id
    assigns(:clients).should == @clients1
  end

  it "should find by not_asignet_to_agent" do
    login_as_admin
    post "clients", :s_agent_id=>-1
    assigns(:clients).should == @clients2
  end

  it "should find by all by agents" do
    login_as_admin
    post "clients", :s_agent_id=>-2
    assigns(:clients).should == @clients
  end

  it "should find by all by other fields" do
    login_as_admin
    post "clients", :field1 => "a", :field2=>"b"

    assigns(:clients).should ==  []

  end
end

describe CallcenterController, ".plan_show_detailed" do
  before(:each) do
    login_as_admin
    @mock_client = mock_model(CcClient, :first_name => "Jonas", :id => 15)
    @mock_plan = mock_model(CcPlan, :name => "test_plan", :id => 25)
    @mock_plans = [@mock_plan]
  end

  it "should work without errors" do
    CcClient.should_receive(:find).with(:first, :conditions=>"id = 25").and_return(@mock_client)
    CcPlan.should_receive(:get_plans_with_user).with(25.to_s, 15.to_s).and_return(@mock_plans)
    CcAction.should_receive(:get_actions).with("15", "25").and_return([])
    get "plan_show_detailed", :id => 15, :cid=> 25
  end
end

describe CallcenterController, ".plan_hide_detailed" do
  before(:each) do
    login_as_admin
    @mock_client = mock_model(CcClient, :first_name => "Jonas", :id => 15)
    @mock_plan = mock_model(CcPlan, :name => "test_plan", :id => 25)
    @mock_plans = [@mock_plan]
  end

  it "should work without errors" do
    CcClient.should_receive(:find).with(:first, :conditions=>"id = 25").and_return(@mock_client)
    CcPlan.should_receive(:get_plans_with_user).with(25.to_s, 15.to_s).and_return(@mock_plans)
    get "plan_hide_detailed", :id => 15, :cid=> 25
  end
end

describe CallcenterController, ".action_edit" do

  before(:each) do
    @mock_action = mock_model(CcAction, :id => 15, :start_time => "2008-11-12 14:32:56", :cc_task_id => 12, :comment=> "test_plan_comment", :action_type => "reminder")
  end

  it "should run without errors" do
    login_as_admin
    CcAction.should_receive(:find).with(:first, :conditions => "id = 15").and_return(@mock_action)
    get "action_edit", :id => 15
  end

end

describe CallcenterController, ".action_update" do

  before(:each) do
    @mock_action = mock_model(CcAction, :id => 15, :start_time => "2008-11-12 14:32:56", :cc_task_id => 12, :comment=> "test_plan_comment", :action_type => "reminder", :cc_client_id => "25" , :cc_task_id => "15")
    @mock_plan = mock_model(CcPlan, :name => "test_plan", :id => 25)
    @mock_plans = [@mock_plan]
  end

  it "should update without errors" do
    @mock_action.should_receive(:start_time=)
    @mock_action.should_receive(:comment=)
    @mock_action.should_receive(:save).and_return(true)
    CcClient.should_receive(:find).with(:first, :conditions=>"id = 25").and_return(@mock_client)
    CcPlan.should_receive(:get_plans_with_user).with(25.to_s, 15.to_s).and_return(@mock_plans)
    CcAction.should_receive(:get_actions).with("15", "25").and_return([])
    login_as_admin
    CcAction.should_receive(:find).with(:first, :conditions => "id = 15").and_return(@mock_action)
    date = {:year => "2010",:month=> "12", :day=>"14", :hour=>"12", :minute=>"51"}
    post "action_update",:id => 15, :comment => "Test_comment_2", :date_from => date
    flash[:notice2].should eql("Action updated")
  end

  it "should notify if update failed" do
    @mock_action.should_receive(:start_time=)
    @mock_action.should_receive(:comment=)
    @mock_action.should_receive(:save).and_return(false)
    CcClient.should_receive(:find).with(:first, :conditions=>"id = 25").and_return(@mock_client)
    CcPlan.should_receive(:get_plans_with_user).with(25.to_s, 15.to_s).and_return(@mock_plans)
    CcAction.should_receive(:get_actions).with("15", "25").and_return([])
    login_as_admin
    CcAction.should_receive(:find).with(:first, :conditions => "id = 15").and_return(@mock_action)
    date = {:year => "2010",:month=> "12", :day=>"14", :hour=>"12", :minute=>"51"}
    post "action_update",:id => 15, :comment => "Test_comment_2", :date_from => date
    flash[:notice2].should eql("Action not updated")
  end


end

describe CallcenterController, ".action_destroy" do

  before(:each) do
    @mock_action = mock_model(CcAction, :id => 15, :start_time => "2008-11-12 14:32:56", :cc_task_id => 12, :comment=> "test_plan_comment", :action_type => "reminder", :cc_client_id => "25" , :cc_task_id => "15")
    @mock_plan = mock_model(CcPlan, :name => "test_plan", :id => 25)
    @mock_plans = [@mock_plan]
  end

  it "should destroy without errors" do
    login_as_admin
    CcClient.should_receive(:find).with(:first, :conditions=>"id = 25").and_return(@mock_client)
    CcPlan.should_receive(:get_plans_with_user).with(25.to_s, 15.to_s).and_return(@mock_plans)
    CcAction.should_receive(:find).with(:first, :conditions => "id = 15").and_return(@mock_action)
    CcAction.should_receive(:get_actions).with("15", "25").and_return([])
    @mock_action.should_receive(:destroy).and_return(true)
    get "action_destroy", :id => 15
    flash[:notice2].should eql("Action destroyed")
  end

  it "should notify if destroy failed" do
    login_as_admin
    CcClient.should_receive(:find).with(:first, :conditions=>"id = 25").and_return(@mock_client)
    CcPlan.should_receive(:get_plans_with_user).with(25.to_s, 15.to_s).and_return(@mock_plans)
    CcAction.should_receive(:find).with(:first, :conditions => "id = 15").and_return(@mock_action)
    CcAction.should_receive(:get_actions).with("15", "25").and_return([])
    @mock_action.should_receive(:destroy).and_return(false)
    get "action_destroy", :id => 15
    flash[:notice2].should eql("Action not destroyed")
  end

end

describe CallcenterController, ".questionary" do
  before(:each) do
    @mock_datfld = mock_model(CcFormFieldData, :id=>1, :user_id=>1, :cc_form_id => 2, :value => "pirmas", :time=>"2008-01-01 01:01:01", :cc_client_id=>1, :cc_task_id =>1)
    @mock_form = mock_model(CcForm, :name => "test_form", :id => 2)
    @mock_plan = mock_model(CcPlan, :name => "test_plan", :id => 25, :cc_form_id=>2)
    @mock_forms = [@mock_form]
  end

  it "should find form" do
    login_as_admin
    CcForm.should_receive(:find).with(:all).and_return(@mock_forms)
    CcPlan.should_receive(:find).with(:first, :conditions=>"cc_form_id = '2'").and_return(@mock_plan)
    CcFormFieldData.should_receive(:find).with(:first, :conditions => "cc_form_id = '2'").and_return(@mock_datfld)
    get "questionary"
  end

end


#describe CallcenterController, ".edit_client" do
#
#  before(:each) do
#    @mock_dir = mock_model(Direction, :id=>5, :name=>"fff", :code =>"ffe")
#    @mock_client = mock_model(CcClient, :id=>45, :first_name => "DD", :last_name=> "DDD", :clientid=> "444", :agreement_number=>"006", :agreement_date=> "2001-02-02 03:03:03", :vat_number=>"333", :vat_percent=> "098", :address_id=>9 , :user_id=>0 )
#    @mock_adres = mock_model(Address, :id =>9, :direction_id => 5)
#    @mock_user = mock_model(User, :id =>0)
#    @mock_dirs = [@mock_dir]
#  end
#
#  it "should find client" do
#    login_as_admin
#    #CcClient.should_receive(:find).with(:first, :conditions => "id = #{@mock_client.id}").and_return(@mock_client)
#    #CcClient.should_receive(:address).and_return([])
#    Direction.should_receive(:find).with(:all, :order => "name").and_return(@mock_dirs)
#    User.should_receive(:find).with(:all, :conditions => "call_center_agent = 1").and_return(@mock_user)
#    post "edit_client", :id=> 45
#  end
#
#end


describe CallcenterController, ".update_client" do
  before(:each) do

    @mock_address = mock_model(Address)
    @mock_address.stub!(:direction_id=)
    @mock_address.stub!(:state=)
    @mock_address.stub!(:county=)
    @mock_address.stub!(:city=)
    @mock_address.stub!(:postcode=)
    @mock_address.stub!(:address=)
    @mock_address.stub!(:phone=)
    @mock_address.stub!(:mob_phone=)
    @mock_address.stub!(:fax=)
    @mock_address.stub!(:email=)
    @mock_address.should_receive(:save).twice.and_return(true)

    @mock_client =mock_model(CcClient, :id => 12)
    @mock_client.stub!(:name=)
    @mock_client.stub!(:client_id=)
    @mock_client.stub!(:agreement_number=)
    @mock_client.stub!(:agreement_date=)
    @mock_client.stub!(:vat_code=)
    @mock_client.stub!(:vat_percent=)
    @mock_client.stub!(:user_id=)
    @mock_client.should_receive(:save).and_return(true)
    @mock_client.should_receive(:address).and_return(@mock_address)
    @mock_client.should_receive(:delivery_address).and_return(@mock_address)

    CcClient.should_receive(:find).with(:first, :conditions =>"id = 12").and_return(@mock_client)
    CcClientFieldData.should_receive(:update_client_field_data)
  end

  it "should set correct params" do
    login_as_admin
    post "update_client", :id => 12,:first_name => "test" , :last_name=>"testl", :clientid=>"20", :agreement_number=>"34", :vat_number=>"3334", :vat_procent=>"23", :agent_id=>"3", :task => 23, :field5 =>"erw"
    flash[:notice].should eql("Client was updated")
    assigns(:client).should == @mock_client
  end
end


describe CallcenterController, ".add_client_option" do
  before(:each) do

    @mock_field = mock_model(CcClientField, :id =>3, :inner_field_id=>0, :fieldtype=>"Checkbox", :default_value => "0")
    @mock_field2 = mock_model(CcClientField, :id =>4, :inner_field_id=>3, :fieldtype=> @mock_field.fieldtype, :default_value=>1)
    @mock_fields = [@mock_field2]
  end

  it "should craete" do
    login_as_admin
    CcClientField.should_receive(:new).and_return(@mock_field)

    CcClientField.should_receive(:find).with("4").and_return(@mock_field2)
    @mock_field.should_receive(:inner_field_id=)
    @mock_field.should_receive(:fieldtype=)
    @mock_field.should_receive(:default_value=)
    @mock_field.should_receive(:save)
    CcClientField.should_receive(:find).with(:all, :conditions => "inner_field_id = '0' AND name !='Status_form'").and_return(@mock_fields)
    post "add_client_option", :id => 4,:rm => false
  end

  it "should delete" do
    login_as_admin
    CcClientField.should_receive(:find).with(:first, :conditions => "id = #{3}").and_return(@mock_field)
    @mock_field.should_receive(:destroy)
    CcClientField.should_receive(:find).with(:all, :conditions => "inner_field_id = '0' AND name !='Status_form'").and_return(@mock_fields)
    post "add_client_option", :id => 3,:rm => true
  end

end


describe CallcenterController, ".update_client_field_name" do
  before(:each) do

    @mock_field = mock_model(CcClientField, :id =>4, :inner_field_id=>0, :fieldtype=>"Checkbox", :default_value => "0", :name => "test")

  end

  it "should update" do
    login_as_admin
    CcClientField.should_receive(:find).with(:first, :conditions => "id = #{4}").and_return(@mock_field)
    @mock_field.should_receive(:name=)
    @mock_field.should_receive(:save)

    post "update_client_field_name", :id => 4,:field_name => "buuuu"
  end



end


describe CallcenterController, ".update_client_field" do
  before(:each) do

    @mock_field = mock_model(CcClientField, :id =>3, :inner_field_id=>0, :fieldtype=>"Checkbox", :default_value => "0", :name => "test")
    @mock_field2 = mock_model(CcClientField, :id =>4, :inner_field_id=>0, :fieldtype=>"Radiobutton", :default_value => "5", :name => "test")
    @mock_field3 = mock_model(CcClientField, :id =>5, :inner_field_id=>0, :fieldtype=>"Textarea", :default_value => "0", :name => "test")
  end

  it "should update Radiobutton" do
    login_as_admin
    CcClientField.should_receive(:find).with(:first, :conditions => "id = #{4}").and_return(@mock_field2)
    @mock_field2.should_receive(:default_value=)
    @mock_field2.should_receive(:save)

    post "update_client_field", :id => 4,:fl => "7"
  end

  it "should update Checkbox whit 1" do
    login_as_admin
    CcClientField.should_receive(:find).with(:first, :conditions => "id = #{3}").and_return(@mock_field)
    @mock_field.should_receive(:default_value=)
    @mock_field.should_receive(:save)

    post "update_client_field", :id => 3,:p => "7"
  end

  it "should update Checkbox whit 0" do
    login_as_admin
    CcClientField.should_receive(:find).with(:first, :conditions => "id = #{3}").and_return(@mock_field)
    @mock_field.should_receive(:default_value=)
    @mock_field.should_receive(:save)

    post "update_client_field", :id => 3
  end

  it "should update Others" do
    login_as_admin
    CcClientField.should_receive(:find).with(:first, :conditions => "id = #{5}").and_return(@mock_field3)
    @mock_field3.should_receive(:default_value=)
    @mock_field3.should_receive(:save)

    post "update_client_field", :id => 5,:field_name => "7"
  end

end

describe CallcenterController, ".client_field_params" do
  before(:each) do

    @mock_field = mock_model(CcClientField, :id =>4, :inner_field_id=>0, :fieldtype=>"Checkbox", :default_value => "0", :name => "test")

  end

  it "should update" do
    login_as_admin
    CcClientField.should_receive(:find).with(:first, :conditions => "id = #{4}").and_return(@mock_field)
    @mock_field.should_receive(:fieldtype=)
    @mock_field.should_receive(:save)

    post "client_field_params", :id => 4
  end



end

describe CallcenterController, ".add_ccclient_field" do
  before(:each) do

    @mock_field = mock_model(CcClientField, :id =>3, :inner_field_id=>0, :fieldtype=>"Checkbox", :default_value => "0", :name => "test")
    @mock_field2 = mock_model(CcClientField, :id =>4, :inner_field_id=>3, :fieldtype=>"Checkbox", :default_value => "0", :name => "test")
    @mock_fields= [@mock_field2]
  end

  it "should delete" do
    login_as_admin
    CcClientField.should_receive(:find).with(:all, :conditions=>"inner_field_id = '#{3}' ").and_return(@mock_fields)
    CcClientField.should_receive(:find).with(:first, :conditions => "id = #{3}").and_return(@mock_field)

    #CcClientField.should_receive(:find).with(:all, :conditions=>"inner_field_id = '#{3}' ").and_return(@mock_fields)
    @mock_field2.should_receive(:destroy)
    @mock_field.should_receive(:destroy)
    CcClientField.should_receive(:find).with(:all, :conditions => "inner_field_id = '0' AND name !='Status_form'").and_return(@mock_fields)
    post "add_ccclient_field", :id => 3, :rm=>true
  end

  it "should create" do
    login_as_admin
    CcClientField.should_receive(:new).and_return(@mock_field)


    @mock_field.should_receive(:fieldtype=)
    @mock_field.should_receive(:default_value=)
    @mock_field.should_receive(:name=)
    @mock_field.should_receive(:save)
    CcClientField.should_receive(:find).with(:all, :conditions => "inner_field_id = '0' AND name !='Status_form'").and_return(@mock_fields)
    post "add_ccclient_field", :id => 4,:rm => false
  end

end

describe CallcenterController, ".client_fields" do
  before(:each) do

    @mock_field = mock_model(CcClientField, :id =>3, :inner_field_id=>0, :fieldtype=>"Checkbox", :default_value => "0", :name => "test")
    @mock_field2 = mock_model(CcClientField, :id =>4, :inner_field_id=>3, :fieldtype=>"Checkbox", :default_value => "0", :name => "test")
    @mock_fields= [@mock_field2]
  end

  it "should get " do
    login_as_admin
    CcClientField.should_receive(:find).with(:all, :conditions => "inner_field_id = '0'").and_return(@mock_fields)
    post "client_fields"
    assigns(:page_icon).should == "edit.png"
  end

end

describe  CallcenterController, ".update_user_form" do

  before(:each) do
    @mock_task = mock_model(CcTask, :id => 13)
  end

  it "should update user data" do
    login_as_admin
    CcTask.should_receive(:find).with('13').and_return(@mock_task)

    CcContact.should_receive(:update_contacts)
    CcFormFieldData.should_receive(:update_form_field_data)

    post "update_user_form", :id => "13", :cid => "12"
    response.should redirect_to("http://test.host/callcenter/edit_user_form?client=12&task=13")
  end
end

describe CallcenterController, ".create_client" do

  before(:each) do

  end

  it "should create client with correct data" do
    login_as_admin
    CcClientFieldData.should_receive(:update_client_field_data)
    contact = {:first_name => "Testas", :last_name => "Testauskas", :phone => "+370123"}
    lambda {
      lambda {
        lambda {
          post("create_client", {:name => "test", :client_id => "1", :agreement_number=> "agr", :agreement_date => "2009-10-12",:vat_code => "12", :vat_percent => "18", :agent_id => "-1",
          :direction=> 1, :country => "Lithuania", :c => contact} )
          flash[:notice].should eql(_('Client_was_created'))
        }.should change(CcContact, :count)
      }.should change(Address, :count)
    }.should change(CcClient, :count)
    response.should redirect_to("http://test.host/callcenter/clients")
  end

  it "should not create client with incorect data" do
    login_as_admin
    contact = {:first_name => "Testas", :last_name => "Testauskas", :phone => "+370123"}
    lambda {
      lambda {
        lambda {
          post("create_client", {:name => "", :client_id => "1", :agreement_number=> "agr", :agreement_date => "2009-10-12",:vat_code => "12", :vat_percent => "18", :agent_id => "-1",
          :direction=> 1, :country => "Lithuania", :c => contact} )
          flash[:notice].should eql(_('Client was not created'))
        }.should_not change(CcContact, :count)
      }.should_not change(Address, :count)
    }.should_not change(CcClient, :count)
    response.should redirect_to("http://test.host/callcenter/clients")
  end
end

describe CallcenterController, ".contact_add" do
  it "should change count of contacts" do
    CcTask.should_receive(:find).with(:first, :conditions => "id = 13").and_return(nil)
    CcContact.should_receive(:find).with(:all, :conditions => "cc_client_id = 12").and_return([])
    CcClient.should_receive(:find).with(:first, :conditions => "id = 12").and_return(nil)
    login_as_admin
    lambda{
      get "contact_add", :client_id => "12", :task => "13"
    }.should change(CcContact, :count)
    response.should_not be_redirect
  end
end

describe CallcenterController , ".contact_destroy" do
  before(:each) do
    @mock_contact = mock_model(CcContact, :cc_client_id=>12)
  end

  it "should destroy contact" do
    login_as_admin
    CcContact.stub!(:find)
    CcContact.should_receive(:find).with(:first, :conditions => "id = 12").and_return(@mock_contact)
    CcTask.should_receive(:find).with(:first, :conditions => "id = 13").and_return(nil)
    CcContact.should_receive(:find).with(:all, :conditions => "cc_client_id = 12").and_return([])
    CcClient.should_receive(:find).with(:first, :conditions => "id = 12").and_return(nil)
    @mock_contact.should_receive(:destroy)
    get "contact_destroy" , :id => "12", :task => "13"
  end
end

describe CallcenterController, ".contact_make_main" do

  before(:each) do
    @mock_contact = mock_model(CcContact, :cc_client_id=>12, :id => 15)
    @mock_client = mock_model(CcClient, :id => 12)
    @mock_client.should_receive(:main_contact_id=).with(@mock_contact.id)
    @mock_client.should_receive(:save).and_return(true)
  end

  it "should set main contact" do
    login_as_admin
    CcContact.stub!(:find)
    CcClient.stub!(:find)
    CcTask.should_receive(:find).with(:first, :conditions => "id = 13").and_return(nil)
    CcContact.should_receive(:find).with(:all, :conditions => "cc_client_id = 12").and_return([])

    CcClient.should_receive(:find).with(:first, :conditions => "id = 12").and_return(@mock_client)
    CcContact.should_receive(:find).with(:first, :conditions => "id = 15").and_return(@mock_contact)

    get "contact_make_main", :id => 15 , :task => 13
  end
end

describe CallcenterController, ".group_remove_client" do
  before(:each) do
    @mock_gc = mock_model(CcGroupClient)
  end

  it "should demove client from group" do
    login_as_admin
    @mock_gc.should_receive(:destroy).and_return(true)
    CcGroupClient.should_receive(:find).with(:first, :conditions => "cc_client_id = 14 AND cc_group_id = 15").and_return(@mock_gc)
    CcClient.should_receive(:find).with(:first, :conditions => "id = 14").and_return([])
    get "group_remove_client", :client_id => 14 , :group_id => 15
  end
end

describe CallcenterController, ".group_add_client" do
  before(:each) do
    @mock_gc = mock_model(CcGroupClient)
  end

  it "should add client to group" do
    login_as_admin
    @mock_gc.should_receive(:cc_client_id=).with("14")
    @mock_gc.should_receive(:cc_group_id=).with("15")
    @mock_gc.should_receive(:save).and_return(true)
    CcGroupClient.should_receive(:new).and_return(@mock_gc)
    CcClient.should_receive(:find).with(:first, :conditions => "id = 14").and_return([])
    get "group_add_client", :client_id => 14 , :group_id => 15
  end
end

describe CallcenterController, ".client_assign_by_group" do

  before(:each) do
    CcPlan.should_receive(:find).and_return(@mock_plan)
    CcGroup.should_receive(:find).with(:all).and_return([])
  end

  it "should run without errors" do
    login_as_admin
    @mock_plan = mock_model(CcPlan, :id => 123)
    get "client_assign_by_group", :id => 123
  end

end

describe CallcenterController, ".client_update_by_groups" do

  before(:each) do
    @mock_plan = mock_model(CcPlan)
    @mock_plan.should_receive(:include_group).with(2)
    @mock_plan.should_receive(:exclude_group).with(3)
    CcPlan.should_receive(:find).with(:first, :conditions => "id = 123").and_return(@mock_plan)
  end

  it "should update clients correctly" do
    login_as_admin
    post "client_update_by_groups", :plan => "123",:group_radio_1 => "ignore", :group_radio_2 => "include", :group_radio_3 => "exclude"
    response.should be_redirect
  end

end
