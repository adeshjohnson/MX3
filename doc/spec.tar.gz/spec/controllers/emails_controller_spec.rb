require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'emails_controller'


describe EmailsController, ".emeils_callcenter" do

  before(:each) do
    @emails_controller = EmailsController.new
    @mock_email = mock_model(Email, :id =>4, :name=>3, :subject=>"sss", :date_create => "2000-01-01 01:01:01", :body => "test", :templete=>"html", :owner_id =>"2", :callcenter=>1)
    @mock_emails= [@mock_email]
    session[:user_id] = 2
    RoleRight.stub!(:get_authorization => 1)
  end

  it "find all callcenter emails" do
    login_as_admin
    Email.should_receive(:find).with(:all, :conditions =>"callcenter='1'").and_return(@mock_emails)
    get "emeils_callcenter"
  end

  it "find user callcenter emails" do
    login_as_user(2)
    Email.should_receive(:find).with(:all, :conditions =>"(owner_id='#{2}' or owner_id='0') and callcenter='1'").and_return(@mock_emails)
    get "emeils_callcenter"
    MorLog.my_debug(response.body)
  end
end

describe EmailsController, ".send_emails_from_cc" do

  before(:each) do
    @emails_controller = EmailsController.new
    @mock_email = mock_model(Email, :id =>4, :name=>3, :subject=>"sss", :date_create => "2000-01-01 01:01:01", :body => "test", :templete=>"html", :owner_id =>"2", :callcenter=>1)
    @mock_user = mock_model(User, :id =>3, :usertype=>"user", :owner_id =>"0", :call_center_agent=>1)
    @mock_client = mock_model(CcClient, :id =>3, :user_id=>"3", :main_contact_id =>"0")
    @mock_emails= [@mock_email]
    @mock_users= [@mock_user]
    @mock_clients= [@mock_client]
    RoleRight.should_receive(:get_authorization).and_return(1)
  end

  it "find all callcenter emails" do
    login_as_user(3)
    User.should_receive(:find).with(@mock_user.id).and_return(@mock_users)
    Email.should_receive(:find).with("4").and_return(@mock_email)
    User.should_receive(:find).with(:all, :conditions=>"call_center_agent=1").and_return(@mock_users)
    CcClient.should_receive(:whit_main_contact).with("3").and_return(@mock_clients)
    CcClient.should_receive(:whit_email).with("#{@mock_client.id}").and_return(@mock_client)
    get "send_emails_from_cc", :id=>4, :agent=>3, :to_be_sent=> {"#{@mock_client.id}","yes"}
  end


end
