require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'payments_controller'

describe PaymentsController, ".cyberplat_pay" do
  before(:each) do
    @payments_controller = PaymentsController.new
  end

  it "should show error if checker.ini was not found." do
    login_as_admin
    User.should_receive(:find).with(:first, :conditions => "id = 0").and_return(true)
    File.should_receive(:exist?).and_return(false)
    lambda {
      post :cyberplat_pay
      response.flash[:notice].should eql("Cyberplat is not configured")
    }.should change(Action, :count)
  end
end

describe PaymentsController, ".ouroboros" do
  before(:each) do
    RoleRight.stub!(:get_authorization).and_return(1)
    Confline.stub!(:get_value)
    Confline.should_receive(:get_value).with("Ouroboros_Enabled", 0).and_return("1")
    Confline.should_receive(:get_value).with("Ouroboros_Default_Currency", 0).and_return("HRK")
    Confline.should_receive(:get_value).with("Ouroboros_Default_Amount", 0).and_return(10)
    Confline.should_receive(:get_value).with("Ouroboros_Min_Amount", 0).and_return(5)
  end

  it "should open without error" do
    User.should_receive(:find).with(:first, {:conditions=>"id = 123"}).and_return(get_mock_user)
    login_as_user
    get :ouroboros
    assigns[:enabled].should eql(1)
    assigns[:currency].should eql('HRK')
  end
end

describe PaymentsController, ".ouroboros_pay" do

  before(:each) do
    RoleRight.stub!(:get_authorization).and_return(1)
  end

  it "when Ouroboros is disabled" do
    Confline.should_receive(:get_value).with("Ouroboros_Enabled", 0).and_return("0")
    User.should_receive(:find).with(:first, {:conditions=>"id = 123"}).and_return(get_mock_user)
    login_as_user
    lambda {
      get :ouroboros_pay
    }.should_not change(Payment, :count)
  end

  it "when Ouroboros is enabled" do
    Confline.should_receive(:get_value).with("Ouroboros_Enabled", 0).and_return("1")
    Confline.should_receive(:get_value).with("Ouroboros_Merchant_Code", 0).and_return("1234asdf")
    Confline.should_receive(:get_value).with("Ouroboros_Language", 0).and_return("en")
    #Confline.should_receive(:get_value).with("Ouroboros_Default_Amount", 0).and_return("10")
    Confline.should_receive(:get_value).with("Ouroboros_Secret_key", 0).and_return("Very_Secret_Key")
    Confline.should_receive(:get_value).with("Ouroboros_Min_Amount", 0).and_return("5")
    Confline.should_receive(:get_value).with("Ouroboros_Max_Amount", 0).and_return("100")
    Confline.should_receive(:get_value).with("Ouroboros_Default_Currency", 0).and_return("HRK")
    Confline.should_receive(:get_value).with("Ouroboros_Retry_Count", 0).and_return("3")
    Confline.should_receive(:get_value).with("Ouroboros_Completion", 0).and_return("0")
    Confline.should_receive(:get_value).with("Ouroboros_Completion_Over", 0).and_return("120")

    User.should_receive(:find).with(:first, {:conditions=>"id = 123"}).and_return(get_mock_user({}, {:direction => get_mock_direction}))
    login_as_user
    lambda {
      get :ouroboros_pay, :amount => "13"
    }.should change(Payment, :count)
    payment = assigns[:payment]
    payment.amount.should eql(15.34)
    payment.gross.should eql(13.0)
    payment.vat_percent.should eql(18.0)
    payment.currency.should eql('HRK')
    payment.paymenttype.should eql('ouroboros')
  end
end

describe PaymentsController, ".ouroboros_accept" do
  before(:each) do
    RoleRight.stub!(:get_authorization).and_return(1)
  end

  it "should set error if payment was not found" do
    login_as_user
    get :ouroboros_accept, :order_id => "134"
    assigns[:error].should eql(1)
  end

  it "should set error if ouroboros is disabled" do
    login_as_user
    Payment.should_receive(:find).with(:first, :conditions => "id = 134").and_return(get_mock_payment_ouroboros_unnanounced(:user=> get_mock_user))
    Confline.should_receive(:get_value).with("Ouroboros_Enabled", 0).and_return("0")
    get :ouroboros_accept, :order_id => "134"
    assigns[:error].should eql(2)
  end

  it "should set error if payment has invalid pending reason" do
    login_as_user
    Payment.should_receive(:find).with(:first, :conditions => "id = 134").and_return(get_mock_payment_ouroboros_unnanounced(:user=> get_mock_user, :pending_reason => "test_resaon"))
    Confline.should_receive(:get_value).with("Ouroboros_Enabled", 0).and_return("1")
    get :ouroboros_accept, :order_id => "134"
    assigns[:error].should eql(3)
  end

  it "should set error if hash is not correct" do
    login_as_user
    Payment.should_receive(:find).with(:first, :conditions => "id = 134").and_return(get_mock_payment_ouroboros_unnanounced(:user=> get_mock_user))
    Confline.stub!(:get_value)
    Confline.should_receive(:get_value).with("Ouroboros_Enabled", 0).and_return("1")
    Confline.should_receive(:get_value).with("Ouroboros_Secret_key", 0).and_return("Very_Secret_Key")
    get :ouroboros_accept, :order_id => "134", :tid => "67178", :amount=> "1181", :card=> "Visa", :signature =>"0360fc2e8a84d68922f35238fed0a0a6"
    assigns[:error].should eql(4)
  end

  it "should set error if hash is not correct" do
    login_as_user
    Payment.should_receive(:find).with(:first, :conditions => "id = 134").and_return(get_mock_payment_ouroboros_unnanounced(:user=> get_mock_user))
    Confline.stub!(:get_value)
    Confline.should_receive(:get_value).with("Ouroboros_Enabled", 0).and_return("1")
    Confline.should_receive(:get_value).with("Ouroboros_Secret_key", 0).and_return("Very_Secret_Key")
    get :ouroboros_accept, :order_id => "134", :tid => "67178", :amount=> "1181", :card=> "Visa", :signature =>"b63bfa43f242230a7c4db30cd4243665"
    assigns[:error].should eql(5)
  end

  it "should set error if hash is not correct" do
    login_as_user
    user = get_mock_user(:email => "test@email.com")
    user.should_receive(:balance=)
    user.should_receive(:save).and_return(true)
    payment = get_mock_payment_ouroboros_unnanounced(:user=> user)
    payment.should_receive(:completed=)
    payment.should_receive(:transaction_id=)
    payment.should_receive(:shipped_at=)
    payment.should_receive(:payer_email=)
    payment.should_receive(:hash=)
    payment.should_receive(:pending_reason=)
    payment.should_receive(:save).and_return(true)
    Payment.should_receive(:find).with(:first, :conditions => "id = 134").and_return(payment)
    Confline.stub!(:get_value)
    Confline.should_receive(:get_value).with("Ouroboros_Enabled", 0).and_return("1")
    Confline.should_receive(:get_value).with("Ouroboros_Secret_key", 0).and_return("Very_Secret_Key")
    Confline.should_receive(:get_value).with('Ouroboros_Default_Currency', 0).and_return("HRK")
    session[:default_currency]= "HRK"
    Currency.should_receive(:find).twice.with(:first, :conditions => ["name = ?", "HRK"]).and_return(mock_model(Currency, :exchange_rate => 1.2))
    get :ouroboros_accept, :order_id => "134", :tid => "67178", :amount=> "1180", :card=> "Visa", :signature =>"0360fc2e8a84d68922f35238fed0a0a6"
    assigns[:error].should eql(0)
  end
end

#http://localhost:3000/payments/ouroboros_accept?tid=67178&order_id=187&amount=1180&card=Visa&signature=b7672529599e0dcaf8e9be0a3463cfe7


describe PaymentsController, ".list" do
  before(:each) do
    @paymt = get_mock_payment()
  end
  it "should search" do
    login_as_admin
    data4 = {}
    data4["year"] = "2009"
    data4["month"] = "1"
    data4["day"] = "1"
    data4["minute"] = "00"
    data4["hour"] = "00"

    data3 = {}
    data3["year"] = "2009"
    data3["month"] = "2"
    data3["day"] = "24"
    data3["minute"] = "59"
    data3["hour"] = "23"

    sql = "SELECT payments.*, users.username, users.first_name, users.last_name, cards.number, cardgroups.vat_percent as c_percent, users.vat_percent as u_percent FROM payments \n              left join users on (payments.user_id = users.id and payments.card = '0') \n              left join cards on (payments.user_id = cards.id and payments.card != '0')\n              left join cardgroups on (cards.cardgroup_id = cardgroups.id)\n           where payments.owner_id = '0'  AND username LIKE 'aa%'  AND users.first_name LIKE 'aa%'  AND users.last_name LIKE 'aa%'  AND date_added BETWEEN '2009-01-01 00:00:00' AND '2009-02-24 23:59:59'  AND paymenttype = 'invoice'  AND currency = 'EUR'  AND amount >= '3'  AND amount <= '5' "
    Payment.should_receive(:find_by_sql).with(sql).and_return([@paymt])
    @paymt.should_receive(:u_percent).and_return("43")
    controller.stub!(:get_price_exchange).and_return(9.to_f)
    post :list , :s_pcurr=> "EUR" ,:s_amount_min=> "3", :s_amount_max=> "5",:s_username=> "aa", :s_first_name=> "aa",:s_last_name=> "aa", :s_ptype=> "invoice", :date_till=>data3, :date_from=>data4
  end

end

describe PaymentsController, ".payments_csv" do
  before(:each) do
    @paymt = get_mock_payment()
  end
  it "should create corect cvs" do
    login_as_admin
    data4 = {}
    data4["year"] = "2009"
    data4["month"] = "1"
    data4["day"] = "1"
    data4["minute"] = "00"
    data4["hour"] = "00"

    data3 = {}
    data3["year"] = "2009"
    data3["month"] = "2"
    data3["day"] = "24"
    data3["minute"] = "59"
    data3["hour"] = "23"

    sql = "SELECT payments.*, users.username, users.first_name, users.last_name, cards.number, cardgroups.vat_percent as c_percent, users.vat_percent as u_percent FROM payments \n              left join users on (payments.user_id = users.id and payments.card = '0') \n              left join cards on (payments.user_id = cards.id and payments.card != '0')\n              left join cardgroups on (cards.cardgroup_id = cardgroups.id)\n           where payments.owner_id = '0'  AND username LIKE 'aa%'  AND users.first_name LIKE 'aa%'  AND users.last_name LIKE 'aa%'  AND date_added BETWEEN '2007-01-01 00:00:00' AND '2010-12-31 00:00:59'  AND paymenttype = 'invoice'  AND currency = 'EUR'  AND amount >= '3'  AND amount <= '5' "
    Payment.should_receive(:find_by_sql).with(sql).and_return([@paymt])
    Confline.should_receive(:get_value).with("CSV_Separator",0).and_return(";")
    Confline.should_receive(:get_value).with("CSV_Decimal",0).and_return(",")
    @paymt.should_receive(:u_percent).exactly(2).times.and_return("43")
    @paymt.should_receive(:number).and_return("43")
    controller.stub!(:get_price_exchange).and_return(9.to_f)
    post :payments_csv , :s_curr=> "EUR" ,:s_min=> "3", :s_max=> "5",:s_username=> "aa", :s_first_name=> "aa",:s_last_name=> "aa", :s_ptype=> "invoice", :date_till=>data3, :date_from=>data4
  end

end

describe PaymentsController, ".manual_payment_finish" do
  before(:each) do
    @paym = get_mock_payment()
    @user = get_mock_user()
    @invoice = get_mock_invoice()
    @invoicedetail = get_mock_invoicedetail()
  end
  it "should create corect invoice" do
    login_as_admin
    User.should_receive(:find).with("5").and_return(@user)
    @user.should_receive(:balance=)
    @user.should_receive(:save)
    Payment.should_receive(:new).and_return(@paym)
    @paym.should_receive(:paymenttype=)
    @paym.should_receive(:vat_percent=)
    @paym.should_receive(:amount=)
    @paym.should_receive(:currency=)
    @paym.should_receive(:date_added=)
    @paym.should_receive(:shipped_at=)
    @paym.should_receive(:completed=)
    @paym.should_receive(:user_id=)
    @paym.should_receive(:owner_id=)
    @paym.should_receive(:save)

    @user.should_receive(:postpaid).and_return(0)
    Invoice.should_receive(:new).and_return(@invoice)
    @invoice.should_receive(:user_id=)
    @invoice.should_receive(:period_start=)
    @invoice.should_receive(:period_end=)
    @invoice.should_receive(:issue_date=)
    @invoice.should_receive(:paid=)
    @invoice.should_receive(:number=).exactly(2).times
    @invoice.should_receive(:invoice_type=)
    @invoice.should_receive(:price=)
    @invoice.should_receive(:price_with_vat=)
    @invoice.should_receive(:save).exactly(2).times

    #Time.now.strftime("%Y")
    #Time.now.strftime("%m")

    #@invoice.number = generate_invoice_number(Confline.get_value("Prepaid_Invoice_Number_Start"), Confline.get_value("Prepaid_Invoice_Number_Length").to_i, Confline.get_value("Prepaid_Invoice_Number_Type").to_i, invoice.id, year, month)
    #@invoice.save

    Invoicedetail.should_receive(:new).and_return(@invoicedetail)
    @invoicedetail.should_receive(:invoice_id=)
    @invoicedetail.should_receive(:name=)
    @invoicedetail.should_receive(:price=)
    @invoicedetail.should_receive(:quantity=)
    @invoicedetail.should_receive(:invdet_type=)
    @invoicedetail.should_receive(:save)
    post :manual_payment_finish , :user=>"5", :amount=>5, :real_amount=>5, :currency=>"LTU"
  end

end
=begin
describe PaymentsController, ".delete_payment" do

  before(:each) do
    login_as_admin
  end
  
  it "should not allow delete not manual payments" do
    @payment = get_mock_payment(:paymenttype => "paypal")
    Payment.should_receive(:find).with(:first, :conditions => ["id = ?", 53]).and_return(@payment)
    get :delete_payment, :id => 53
    response.should redirect_to("as")
    flash[:notice].should eql(_('Only_manual_payments_can_be_deleted'))
  end
  
  it "should remove balance from user when payment is for user" do
    @payment = get_mock_payment(:paymenttype => "manual", :user_id =>13, :currency => "USD", :amount => 30)
    @user = get_mock_user(:id => 13, :balance => 100, :vat_percent=> 20)
    @user.should_return(:balance=).with(1)
    Payment.should_receive(:find).with(:first, :conditions => ["id = ?", 53]).and_return(@payment)
    User.should_receive(:find).with(:first, :conditions => ["id = ?", 13]).and_return(@user)
    Currency.should_receive(:count_exchange_rate).with("LTL", "USD").and_return(0.394)
    get :delete_payment, :id => 53
    response.should redirect_to("as")
    flash[:notice].should eql(_('Payment_deleted'))
  end
  
end
=end
