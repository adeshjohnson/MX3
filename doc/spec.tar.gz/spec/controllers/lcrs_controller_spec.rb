require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'lcrs_controller'

describe LcrsController, "details_by_destinations" do
  before(:each) do
    @providers_controller = LcrsController.new
  end

  it "should find  " do
    login_as_admin
    Lcr.stub!(:find)
    Lcr.should_receive(:find).with(:all).and_return(get_mock_lcr(:lcr_partials_destinations=> []))
    Lcr.should_receive(:find).with("1").and_return(get_mock_lcr(:lcr_partials_destinations=> []))

    get "details_by_destinations", :id => 1, :dir => false
  end


end



describe LcrsController, ".providers_percent" do
  before(:each) do
    @lcr = get_mock_lcr({:id=>8})
    @prov1 = get_mock_provider(:id=>7)
    @prov2 = get_mock_provider(:id=>8)
    @lcr_prov1 = get_mock_lcrprovider({:lcr_id=>8, :provider_id=>7})
    @lcr_prov1 = get_mock_lcrprovider({:lcr_id=>7, :provider_id=>8})
  end

  it "should find providers  " do
    login_as_admin

    Lcr.should_receive(:find).with("8").and_return(@lcr)
    @lcr.should_receive(:providers).with("asc").and_return([@prov1])
    get "providers_percent", :id => 8
  end

  it "should change percent " do
    login_as_admin

    Lcr.should_receive(:find).with("8").and_return(@lcr)
    @lcr.should_receive(:providers).with("asc").and_return([@prov1])
    Lcrprovider.should_receive(:find).with(:first , :conditions => "provider_id = '#{7}' AND lcr_id= '#{@lcr.id}'").and_return(@lcr_prov1)
    @lcr_prov1.should_receive(:percent=).with(100.to_f)
    @lcr_prov1.should_receive(:save)
    get "providers_percent", :id => 8, :pr=>2 , :prov_7=>100
  end


  it "should not change percent 'is not 100%'" do
    login_as_admin

    Lcr.should_receive(:find).with("8").and_return(@lcr)
    @lcr.should_receive(:providers).with("asc").and_return([@prov1])
    get "providers_percent", :id => 8, :pr=>2 , :prov_7=>90
  end

  it "should not change percent " do
    login_as_admin

    Lcr.should_receive(:find).with("8").and_return(@lcr)
    @lcr.should_receive(:providers).with("asc").and_return([@prov1])
    Lcrprovider.should_receive(:find).with(:first , :conditions => "provider_id = '#{7}' AND lcr_id= '#{@lcr.id}'").and_return(nil)
    @lcr_prov1.should_not_receive(:percent=).with(100.to_f)
    get "providers_percent", :id => 8, :pr=>2 , :prov_7=>100
  end
end


describe LcrsController, ".try_to_add_provider" do
  before(:each) do
    @lcr = get_mock_lcr({:id=>8})
    @prov1 = get_mock_provider(:id=>7)
    @prov2 = get_mock_provider(:id=>8)
    @lcr_prov1 = get_mock_lcrprovider({:lcr_id=>8, :provider_id=>7})
    @lcr_prov1 = get_mock_lcrprovider({:lcr_id=>7, :provider_id=>8})
  end

  it "should find providers  " do
    login_as_admin

    Lcr.should_receive(:find).with("8").and_return(@lcr)
    Provider.should_receive(:find).with("7").and_return(@prov1)
    @lcr.should_receive(:add_provider).with(@prov1)
    get "try_to_add_provider", :id => 8, :select_prov=>7
  end
end
