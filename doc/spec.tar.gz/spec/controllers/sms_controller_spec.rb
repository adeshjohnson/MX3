require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'sms_controller'

describe SmsController, ".prefix_finder_find" do
  before(:each) do

    @direction = get_mock_direction({:id => 4, :code=>"AAA", :name=>"buuuu"})
    @rate = get_mock_smsrate({:prefix => 488})
    @tariff = get_mock_smsrate({:id => 4})
    @destination = get_mock_destination({:prefix => 488, :direction_code=>"AAA"})
    @user = mock_model(User, :id =>0, :vat_percent=>10, :sms_tariff_id=>4, :tax_2 => 3, :tax_3 => 1, :tax_4 => 4, :clientid=>2, :vat_number=>4, :agreement_number=>7, :agreement_date=>"2001-01-01 01:01:01", :balance=>1000, :first_name=>"test", :last_name=>"asas" , :credit=>9, :owner_id=>0)
    #Destination.stub!(:each)
    # UsersController.stub!(:redirect_to).exactly(2).times.and_return("false")
  end

  it "should find calls all" do
    login_as_admin

    sql= "SELECT destinations.*, directions.name as dirname FROM destinations\n           Join sms_rates on (sms_rates.prefix = destinations.prefix)\n           LEFT Join directions on (directions.code = destinations.direction_code)\n           WHERE destinations.prefix = SUBSTRING('country_id=-1&provider_id=-1', 1, LENGTH(destinations.prefix)) \n           Order by LENGTH(destinations.prefix) DESC\n           LIMIT 1"
    Destination.should_receive(:find_by_sql).with(sql).and_return([@destination])
    @destination.should_receive(:dirname).and_return(4)
    @destination.should_receive(:name).and_return(4)
    User.should_receive(:find).with(0).and_return(@user)
    @user.should_receive(:sms_tariff_id).and_return(4)
    SmsTariff.should_receive(:find).with(4).and_return(@tariff)
    post "prefix_finder_find", :provider_id => -1 , :country_id => -1
  end


end
