require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'application'

describe CardsController, ".list" do
  before(:each) do
    Confline.stub!(:get_value)
    RoleRight.stub!(:get_authorization => 1)
    @cg = get_mock_cardgroup
    Cardgroup.should_receive(:find).with("1").and_return(@cg)
    Card.should_receive(:count).with(:conditions=>"cardgroup_id = #{@cg.id}").and_return(66)
    Card.should_receive(:find_by_sql).and_return([get_mock_card])
    login_as_accountant(4)
  end

  it "should open without errors for accountant when session[:acc_callingcard_pin] = 2 and session[:acc_callingcard_manage] = 2" do
    session[:acc_callingcard_pin] = 2
    session[:acc_callingcard_manage] = 2
    get :list, :cg => 1
    assigns[:allow_manage].should eql(true)
    assigns[:allow_read].should eql(true)
    assigns[:show_pin].should eql(true)
  end

  it "should open without errors for accountant when session[:acc_callingcard_pin] = 1 and session[:acc_callingcard_manage] = 1" do
    session[:acc_callingcard_pin] = 1
    session[:acc_callingcard_manage] = 1
    get :list, :cg => 1
    assigns[:allow_manage].should eql(false)
    assigns[:allow_read].should eql(true)
    assigns[:show_pin].should eql(true)
  end

  it "should open without errors for accountant when session[:acc_callingcard_pin] = 0 and session[:acc_callingcard_manage] = 0" do
    session[:acc_callingcard_pin] = 0
    session[:acc_callingcard_manage] = 0
    get :list, :cg => 1
    assigns[:allow_manage].should eql(false)
    assigns[:allow_read].should eql(false)
    assigns[:show_pin].should eql(false)
  end
end

describe CardsController, ".show" do

  before(:each) do
    RoleRight.stub!(:get_authorization => 1)
    Confline.stub!(:get_value)
    @cg1 = get_mock_cardgroup({:id=>2, :owner_id=>"8"})
    @cg2 = get_mock_cardgroup({:owner_id=>"0"})
    @card1 = get_mock_card({:id=>2, :owner_id=>"8", :cardgroup =>@cg1.id})
    @card2 = get_mock_card({:id=>1, :owner_id=>"0", :cardgroup =>@cg2.id})
  end

  it "should open without errors for accountant when session[:acc_callingcard_pin] = 2" do
    login_as_admin
    Card.should_receive(:find).with("1").and_return(get_mock_card(:cardgroup => get_mock_cardgroup))
    get :show, :id => 1
    assigns[:show_pin].should eql(true)
  end

  it "should open without errors for accountant when session[:acc_callingcard_pin] = 1" do
    login_as_admin
    Card.should_receive(:find).with("1").and_return(get_mock_card(:cardgroup => get_mock_cardgroup))
    get :show, :id => 1
    assigns[:show_pin].should eql(true)
  end

  it "should open without errors for reseller" do
    login_as_reseller(8)
    Card.should_receive(:find).with("2").and_return(@card1)
    @card1.should_receive(:cardgroup).and_return(@cg1)
    get  :show, :id => 2
    assigns[:card].should eql(@card1)
  end

  it "should open without errors for accountant whenession[:acc_callingcard_pin] = 2 " do
    login_as_accountant(4)
    session[:acc_callingcard_pin] = 2
    Card.should_receive(:find).with("2").and_return(@card1)
    @card1.should_receive(:cardgroup).and_return(@cg1)
    get  :show, :id => 2
    assigns[:card].should eql(@card1)
    assigns[:show_pin].should eql(true)
  end

  it "should open without errors for accountant when ession[:acc_callingcard_pin] = 1" do
    login_as_accountant(4)
    session[:acc_callingcard_pin] = 1
    Card.should_receive(:find).with("2").and_return(@card1)
    @card1.should_receive(:cardgroup).and_return(@cg1)
    get  :show, :id => 2
    assigns[:card].should eql(@card1)
    assigns[:show_pin].should eql(true)
  end

  it "should open without errors for accountant when ession[:acc_callingcard_pin] = 0" do
    login_as_accountant(4)
    session[:acc_callingcard_pin] = 0
    Card.should_receive(:find).with("2").and_return(@card1)
    @card1.should_receive(:cardgroup).and_return(@cg1)
    get  :show, :id => 2
    assigns[:card].should eql(@card1)
    assigns[:show_pin].should eql(false)
  end
end

describe CardsController, ".edit" do

  before (:each) do
    Card.should_receive(:find_by_id).with("13", {:include=>[:cardgroup]}).and_return(get_mock_card(:id => 13))
  end

  it "should accept return actiona and return controller params" do
    login_as_admin
    get :edit, :id => 13, :return_to_controller => "test", :return_to_action => "test_action"
    assigns[:return_controller].should eql("test")
    assigns[:return_action].should eql("test_action")
  end

  it "should redirect if accountant is not allowed to edit card" do
    login_as_reseller(8)
    session[:acc_callingcard_manage] = 0
    get :edit, :id => 13
    flash[:notice].should eql(_('Dont_be_so_smart'))
    response.should redirect_to("http://test.host/callc/main")
  end

  it "should redirect if reseller is not allowed to edit card" do
    login_as_reseller(12)
    session[:reseller_allow_callingcard_manage] = 0
    get :edit, :id => 13
    flash[:notice].should eql(_('Dont_be_so_smart'))
    response.should redirect_to("http://test.host/callc/main")
  end
end

describe CardsController, ".update" do

  before (:each) do
    @controller = CardsController.new
  end

  it "should create action when PIN is changed" do
    login_as_admin
    @card = get_mock_card(:id => 12, :pin => "1")
    @card.should_receive(:clone).and_return(get_mock_card(:pin => 121))
    @card.should_receive(:update_attributes).and_return(true)
    Card.should_receive(:find_by_id).with("12", {:include=>[:cardgroup]}).and_return(@card)
    Action.should_receive(:add_action_hash).with(0, {:target_id=>12, :data2=>"1", :action=>"card_pin_changed", :target_type=>"card", :data=>121})
    post :update, :id => 12, :card => {:pin => 121}
    flash[:notice].should eql(_('Card_was_successfully_updated'))
    response.should redirect_to("http://test.host/cards/show/12")
  end

  it "should redirect to return_action and return controller" do
    login_as_admin
    @card = get_mock_card(:id => 12)
    @card.should_receive(:update_attributes).and_return(true)
    Card.should_receive(:find_by_id).with("12", {:include=>[:cardgroup]}).and_return(@card)
    post :update, :id => 12, :return_to_controller => "test", :return_to_action => "test_action"
    flash[:notice].should eql(_('Card_was_successfully_updated'))
    response.should redirect_to("http://test.host/test/test_action")
  end

  it "should render action" do
    login_as_admin
    @card = get_mock_card(:id => 12)
    @card.should_receive(:update_attributes).and_return(false)
    Card.should_receive(:find_by_id).with("12", {:include=>[:cardgroup]}).and_return(@card)
    post :update, :id => 12
    response.should be_success;
    response.should render_template("cards/edit")
  end

  it "should denny sold and balance params" do
    login_as_admin
    @card = get_mock_card(:id => 12)
    @card.should_receive(:update_attributes).with({}).and_return(false)
    Card.should_receive(:find_by_id).with("12", {:include=>[:cardgroup]}).and_return(@card)
    post :update, :id => 12, :card => {:balance => "12.3", :sold => "0"}
  end

end





