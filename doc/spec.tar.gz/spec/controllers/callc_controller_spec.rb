require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'callc_controller'


#describe CallcController, ".emails_callbakc_cronjob" do
#
#  before(:each) do
#    @emails_controller = CallcController.new
#    #RoleRight.should_receive(:get_authorization).and_return(1)
#  end
#
#  it "connet to server and get emails parametres" do
#    login_as_admin
#
#    Callerid.should_receive(:set_callback_from_emails).with("555555", "5555556")
#    get "emails_callback_cronjob", :subject => "change", :param1=>"555555", :param2=>"5555556", :param3=>"666666"
#  end
#
#
#end



describe CallcController, ".login" do

  before(:each) do
    @callc_controller = CallcController.new
    @nz =  mock_model(Translation, :id =>4, :short_name=>"en")
    Translation.stub!(:find)
    @user = get_mock_user({:id=>0})
    Role.should_receive(:find_by_name).with("guest").and_return(mock_model(Role, :id => 12 ))
    RoleRight.should_receive(:get_authorization).and_return(1)
  end

  it "login check logo parameter when is not set" do
    default_login_data()
    Translation.should_receive(:find).with(:all, {:conditions=>"active = 1", :order=>"position ASC"}).and_return([@nz])
    Localization.should_receive(:lang=).with("en")
    Confline.should_receive(:get_value).with("Show_logo_on_register_page", 0).and_return("")
    Confline.should_receive(:set_value).with("Show_logo_on_register_page", 1, 0)
    User.should_receive(:get_hash).with(0).and_return(@user)
    get :login
  end

  it "login check logo parameter when set 0" do
    default_login_data()
    Translation.should_receive(:find).with(:all, {:conditions=>"active = 1", :order=>"position ASC"}).and_return([@nz])
    Localization.should_receive(:lang=).with("en")
    Confline.should_receive(:get_value).with("Show_logo_on_register_page", 0).and_return(0)
    User.should_receive(:get_hash).with(0).and_return(@user)
    get :login
  end

  it "login check logo parameter when set 1" do
    default_login_data()
    Translation.should_receive(:find).with(:all, {:conditions=>"active = 1", :order=>"position ASC"}).and_return([@nz])
    Localization.should_receive(:lang=).with("en")
    Confline.should_receive(:get_value).with("Show_logo_on_register_page", 0).and_return(1)
    User.should_receive(:get_hash).with(0).and_return(@user)
    get :login
  end

end

describe CallcController, ".signup_end" do

  before(:each) do
    default_login_data
    RoleRight.should_receive(:get_authorization).and_return(1)
    @callc_controller = CallcController.new
    @nz =  mock_model(Translation, :id =>4, :short_name=>"en")
    Translation.stub!(:find)
    @user = get_mock_user({:id=>0})
    @address = get_mock_address()
    @dev_group = get_mock_devicegroup()
    @device = get_mock_device()
    Role.should_receive(:find_by_name).with("guest").and_return(mock_model(Role, :id => 12 ))
  end

  it "create user" do
    default_login_data()
    Confline.stub!(:get_value)
    Confline.should_receive(:get_value).with("Agreement_Number_Length")

    # Translation.should_receive(:find).with(:all, {:conditions=>"active = 1", :order=>"position ASC"}).and_return([@nz])
    #Localization.should_receive(:lang=).with("en")
    User.should_receive(:find).with(:first, :conditions => "username = '#{"bla"}'").and_return(false)
    User.should_receive(:find).with(:first, :conditions => "uniquehash = '#{5}'").exactly(2).times.and_return(true)
    Confline.should_receive(:get_value).with("Default_VAT_Percent").and_return(23)
    Address.should_receive(:new).and_return(@address)
    @address.should_receive(:direction_id=).with("1")
    @address.should_receive(:state=)
    @address.should_receive(:county=)
    @address.should_receive(:city=)
    @address.should_receive(:postcode=)
    @address.should_receive(:address=)
    @address.should_receive(:phone=)
    @address.should_receive(:mob_phone=)
    @address.should_receive(:fax=)
    @address.should_receive(:email=).with("aa@aa")
    @address.should_receive(:save)

    User.should_receive(:new).and_return(@user)
    @user.should_receive(:username=).with("bla")
    Digest::SHA1.should_receive(:hexdigest).with("11111").and_return("333")
    @user.should_receive(:password=).with("333")
    @user.should_receive(:usertype=).with("user")
    Confline.should_receive(:get_value).with("Default_Balance_for_new_user", 0).and_return(44)
    @user.should_receive(:balance=).with(44.to_f)
    @user.should_receive(:postpaid=).with(0)
    @user.should_receive(:first_name=).with("bla")
    @user.should_receive(:last_name=).with("bla")
    Confline.should_receive(:get_value).with("LCR_for_registered_users").and_return(7)
    @user.should_receive(:lcr_id=).with(7)
    Confline.should_receive(:get_value).with("Tariff_for_registered_users").and_return(7)
    @user.should_receive(:tariff_id=).with(7)
    @user.should_receive(:clientid=)
    Time.should_receive(:now).exactly(20).times.and_return("Sat Feb 21 12:36:54 +0200 2009".to_time)
    @user.should_receive(:agreement_date=).with("Sat Feb 21 12:36:54 +0200 2009".to_time)
    @user.should_receive(:agreement_number=)
    @user.should_receive(:taxation_country=).with("1")
    @user.should_receive(:vat_number=)
    Confline.should_receive(:get_value).with("Total_Tax_Value", 0).and_return(2)
    @user.should_receive(:vat_percent=).with(2.to_f)
    @user.should_receive(:address_id=).with(@address.id)
    Confline.should_receive(:get_value2).with("Tax_1").and_return(0)
    Confline.should_receive(:get_value2).with("Tax_2").and_return(0)
    Confline.should_receive(:get_value2).with("Tax_3").and_return(0)
    Confline.should_receive(:get_value2).with("Tax_4").and_return(0)

    @user.should_receive(:owner_id=).with(2)
    @user.should_receive(:generate_invoice=).with(0)
    @user.should_receive(:save)

    Devicegroup.should_receive(:new).and_return(@dev_group)
    @dev_group.should_receive(:user_id=).with(@user.id)
    @dev_group.should_receive(:address_id=).with(@address.id)
    @dev_group.should_receive(:name=).with("primary")
    @dev_group.should_receive(:added=).with("Sat Feb 21 12:36:54 +0200 2009".to_time)
    @dev_group.should_receive(:primary=).with(1)
    @dev_group.should_receive(:save)

    #applications.rb functions

    free_ext = "bla"
    pasw =  "bla"
    pin = "bla"
    controller.stub!(:free_extension).and_return("bla")
    controller.stub!(:random_password).with(8).and_return("bla")
    controller.stub!(:new_device_pin).and_return("bla")
    @user.should_receive(:create_default_device).with({:device_type=>"Sip", :dev_group=>@dev_group.id, :free_ext=>free_ext, :secret=>pasw, :pin=>pin}).and_return(@device)
    controller.stub!(:configure_extensions).with(@device.id).and_return(true)
    Confline.should_receive(:get_value).with("Send_Email_To_User_After_Registration").and_return(0)
    Confline.should_receive(:get_value).with("Send_Email_To_Admin_After_Registration").and_return(0)
    get :signup_end, :id=>5, :username=>"bla", :password=>"11111", :password2=>"11111", :first_name=>"bla", :last_name=>"bla", :country_id=>"1", :email=>"aa@aa", :device_type=>"Sip"
    MorLog.my_debug("----------------------------------------------")
    MorLog.my_debug(response.body)
  end


end

describe CallcController, ".daily_actions" do

  before(:each) do
    default_login_data
    Role.should_receive(:find_by_name).with("guest").and_return(mock_model(Role, :id => 12 ))
    @callc_controller = CallcController.new
    @nz =  mock_model(Translation, :id =>4, :short_name=>"en")
    Translation.stub!(:find)
  end

  it "create user" do
    controller.stub!(:update_currencies)
    controller.stub!(:block_users)
    controller.stub!(:block_users_conditional)
    controller.stub!(:check_users_balance)
    controller.stub!(:send_balance_warning)

    get :daily_actions
  end


end
