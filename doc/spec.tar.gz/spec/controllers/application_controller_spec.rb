require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'application'

describe ApplicationController, ".simple_balance should return correct info" do
  def do_post(day1 = "35", day2 = "35")
    date_from = {}
    date_from["year"] = "2008"
    date_from["month"] = "02"
    date_from["day"] = day1

    date_till = {}
    date_till["year"] = "2008"
    date_till["month"] = "09"
    date_till["day"] = day2
    post("change_date", :date_from => date_from, :date_till =>date_till)
  end

  before(:each) do
    @api_controller = ApiController.new
  end

  it "should set correct date" do
    do_post
    session_from_date.should eql("2008-02-29")
    session_till_date.should eql("2008-09-30")
    do_post("-35", "-35")
    session_from_date.should eql("2008-02-01")
    session_till_date.should eql("2008-09-01")
  end
end

describe ApplicationController, "important_exception" do

  before(:each) do
    @ac = ApplicationController.new
    @exception = mock_model(ActionController::RoutingError)
    @exception1 = mock_model(ActiveRecord::StatementInvalid)
  end

  it "should mark RoutingError as unimportant" do
    @ac.important_exception(@exception).should eql(false)
    @ac.important_exception(@exception2).should eql(true)
  end

end

describe ApplicationController, ".correct_owner_id" do

  before(:each) do
    @controller = ApplicationController.new
  end

  it "should return correct owner id" do
    login_as_admin
    @controller.session = session
    @controller.correct_owner_id.should eql(0)
    login_as_accountant(4)
    @controller.session = session
    @controller.correct_owner_id.should eql(0)
    login_as_reseller(8)
    @controller.session = session
    @controller.correct_owner_id.should eql(8)
    login_as_user(12)
    @controller.session = session
    @controller.correct_owner_id.should eql(0)
  end

end

describe ApplicationController, ".load_accountant_permissions" do

  before (:each) do
    @controller = ApplicationController.new
    @controller.session = session
    @rights = [{:name => "test_Acc_1", :value => 2}, {:name => "test_acc_3", :value => 0}, {:name => "no_value"}]
  end

  it "should not load anything for user " do
    user = get_mock_user({:id => 10, :usertype => "user"})
    AccRight.should_not_receive(:find).and_return(@rights)
    @controller.load_accountant_permissions(user)
    session[:acc_test_acc_1].should eql(nil)
    session[:acc_test_acc_3].should eql(nil)
    session[:acc_no_value].should eql(nil)
  end

  it "should load permissions for accountant" do
    user = get_mock_user({:id => 10, :usertype => "accountant"})
    AccRight.should_receive(:find).and_return(@rights)
    @controller.load_accountant_permissions(user)
    session = @controller.session
    session[:acc_test_acc_1].should eql(2)
    session[:acc_test_acc_3].should eql(0)
    session[:acc_no_value].should eql(0)
  end

end

describe ApplicationController, ".renew_session" do
  before (:each) do
    @controller = ApplicationController.new
    @controller.session = session
    cookies = mock('cookies')
    cookies.stub!(:[])
    cookies.stub!(:[]=)
    @controller.stub!(:cookies).and_return(cookies)
    @controller.stub!(:cookies=)
    #    @controller.stub!(:cookies)
  end

  it "should renew user session" do
    user = get_mock_user
    MorLog.my_debug(caller.join("\n"))
    Role.should_receive(:find_by_name).with("user").and_return(get_mock_user_role)
    Currency.should_receive(:find).with(1).and_return(get_mock_currency)
    @controller.should_not_receive(:load_accountant_permissions)
    @controller.renew_session(user)
  end

  it "should renew accountant session" do
    user = get_mock_user({:usertype => "accountant"})
    MorLog.my_debug(caller.join("\n"))
    Role.should_receive(:find_by_name).with("accountant").and_return(get_mock_user_role)
    Currency.should_receive(:find).with(1).and_return(get_mock_currency)
    @controller.should_receive(:load_accountant_permissions)
    @controller.renew_session(user)
  end
end



