require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'users_controller'

describe UsersController, ".create" do
  before(:each) do

    @mock_conf_1 =  mock_model(Confline , :id =>4, :name=>"Tax_1" , :value=>"Tax_1", :value2 => 1)
    @mock_user = get_mock_user
    @address = get_mock_address()
  end

  it "Create user with multi tax " do
    login_as_admin
    data = {}
    data["username"] = "vads"
    #data["password"] = "vads"
    data["usertype"] = "user"
    data["lcr_id"] = "1"
    data["last_name"] = "vads"
    data["first_name"] = "vads"
    data["clientid"] = "1"
    data["language"] = "sddsd"
    data["agreement_number"] = "sddsd"
    data["vat_number"] = "sddsd"
    data["accounting_number"] = "sddsd"
    data["cyberplat_active"] = "sddsd"
    data["tax_1"] = "10"

    data2 = {}
    data2["address"] = "vads"
    data2["postcode"] = "vads"
    data2["city"] = "user"
    data2["county"] = "1"
    data2["state"] = "vads"
    data2["phone"] = "vads"
    data2["mob_phone"] = "1"
    data2["fax"] = "sddsd"
    data2["email"] = "sddsd"

    data3 = {}
    data3["year"] = "2004"
    data3["month"] = "05"
    data3["day"] = "12"

    #User.should_receive(:new).with(data).and_return(@mock_user)
    @mock_user.should_receive(:password=)
    @mock_user.should_receive(:agreement_date=)
    @mock_user.should_receive(:address_id=)
    @mock_user.should_receive(:credit=).twice
    @mock_user.should_receive(:allow_loss_calls=)
    @mock_user.should_receive(:vat_percent=).twice
    @tax = get_mock_tax()
    @tax.should_receive(:save).and_return(true)
    @mock_user.should_receive(:usertype)
    @mock_user.should_receive(:address_id)
    @mock_user.should_receive(:tax).and_return(@tax)
    @mock_user.should_receive(:tax=)#.with(@tax)
    @mock_user.should_receive(:block_conditional_use=)
    @mock_user.should_receive(:owner_id=)
    @mock_user.should_receive(:invoice_zero_calls=).with(1)
    @mock_user.should_receive(:warning_email_active=)
    @mock_user.should_receive(:save).and_return(true)
    @mock_user.should_receive(:address).exactly(2).times.and_return(@address)
    @mock_user.should_receive(:attributes=)
    REC_Active = 1
    @mock_user.should_receive(:recording_enabled=)
    @mock_user.should_receive(:recording_forced_enabled=)
    @address.should_receive(:update_attributes).with(data2).and_return(true)
    #@mock_user.should_receive(:address).and_return(@address)
    @address.should_receive(:save).and_return(true)
    Confline.should_receive(:get_default_object).with(User, 0).and_return(@mock_user)
    Action.should_receive(:add_action_hash).with(0, {:target_id=>15, :target_type=>"user", :action=>"user_created"})
    #@address.should_receive(:destroy)
    post "create", :user => data, :address => data2, :password => {'password', "blasds"}, :agr_date=>data3, :credit=>99, :show_zero_calls =>"1"
  end


end

describe UsersController, ".new" do
  before(:each) do
    @mock_user = get_mock_user()
    @tar = [get_mock_tariff()]
    @lcr = [get_mock_lcr()]
    AccGroup.should_receive(:find).with(:all)
  end

  it "NEW user " do
    login_as_admin
    Lcr.should_receive(:find).with(:all).and_return(@lcr)
    owner = session[:user_id]

    Tariff.should_receive(:find).with(:all, :conditions => "(purpose = 'user' OR purpose = 'user_wholesale') AND owner_id = '#{owner}' ", :order => "purpose ASC, name ASC").and_return(@tar)
    Direction.should_receive(:find).with(:all, :order => "name ASC").and_return([get_mock_direction()])
    Confline.should_receive(:get_value).with("Default_Country_ID").and_return("7")

    @lcr.should_receive(:empty?).and_return(false)
    @tar.should_receive(:empty?).and_return(false)

    controller.stub!(:next_agreement_number).and_return("8984")

    Confline.stub!(:get_default_object)
    @def_user = get_mock_user
    @def_user.should_receive(:owner_id=)
    @def_user.stub!(:tax=)
    @def_user.stub!(:address=)
    @def_user.stub!(:agreement_number=)

    Confline.should_receive(:get_default_object).with(User, 0).and_return(@def_user)
    Confline.should_receive(:get_default_object).with(Address, 0).and_return(get_mock_address)
    Confline.should_receive(:get_default_object).with(Tax, 0).and_return(get_mock_tax)

    session[:user_total_tax_val] = 0
    session[:user_tax_val] = []
    session[:user_tax_val][1] = 0
    session[:user_tax_val][2] = 0
    session[:user_tax_val][3] = 0
    session[:user_tax_val][4] = 0

    post "new"
  end

end
