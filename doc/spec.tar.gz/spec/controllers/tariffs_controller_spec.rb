require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'tariffs_controller'

describe TariffsController, "make_user_tariff_status_wholesale" do
  before(:each) do
    @params = {:id => 1, :add_amount => "12", :add_percent => "13"}
    @tariffs_controller = TariffsController.new
  end

  def do_post
    post :make_user_tariff_status_wholesale, :add_amount => "12", :add_percent => "13", :t_type=>"provider"
  end

  it "should create tariff correctly for admin" do
    @tariff = Tariff.new()
    @tariff.purpose = 'provider'
    @tariff.name = 'Test Tariff_new '
    @tariff.owner_id = 0
    @tariff.currency = 'USD'
    @tariff.id = 0
    @tariff.save
    @tariff.should_receive(:make_wholesale_tariff).and_return(true)
    Tariff.should_receive(:find).and_return(@tariff)
    login_as_admin
    do_post
    response.flash[:notice].should eql("Tariff created")
  end

  it "should create tariff correctly for reseller" do
    login_as_reseller(123)
    @tariff = get_mock_tariff
    @tariff.should_receive(:make_wholesale_tariff).and_return(true)
    Tariff.should_receive(:find).and_return(@tariff)
    post :make_user_tariff_status_wholesale, :add_amount => "12", :add_percent => "13"
    response.flash[:notice].should eql("Tariff created")
    assigns[:t_type].should eql("user_wholesale")
  end

end


describe TariffsController, "list" do
  before(:each) do
    @tariff1 = get_mock_tariff()
    @tariff2 = get_mock_tariff({:purpose=>"user"})
    @tariff3 = get_mock_tariff({:purpose=>"user_wholesale"})
    @tariffs = [@tariff1, @tariff2, @tariff3]
    @user = get_mock_user()
    @user2 = get_mock_user(:id=>0)
    RoleRight.stub!(:get_authorization).and_return(1)
  end

  it "should find all tariffs accountant when acc_tariff_manage = 2" do
    login_as_accountant(6)
    session[:acc_tariff_manage] = 2
    Tariff.stub!(:find)
    User.should_receive(:find).with(0).and_return(@user2)
    Tariff.should_receive(:find).with(:all, {:conditions=>"purpose = 'provider' AND owner_id = '0'", :order=>"name ASC"}).and_return([@tariff1])
    Tariff.should_receive(:find).with(:all, :conditions => "purpose = 'user' AND owner_id = '#{0}'", :order => "name ASC").and_return([@tariff2])
    Tariff.should_receive(:find).with(:all, :conditions => "purpose = 'user_wholesale' AND owner_id = '#{0}'", :order => "name ASC").and_return([@tariff3])
    get "list"
  end
  it "shuld find all tariffs accountant when acc_tariff_manage = 1" do
    login_as_accountant(6)
    session[:acc_tariff_manage] = 1
    Tariff.stub!(:find)
    User.should_receive(:find).with(0).and_return(@user2)
    Tariff.should_receive(:find).with(:all, {:conditions=>"purpose = 'provider' AND owner_id = '0'", :order=>"name ASC"}).and_return([@tariff1])
    Tariff.should_receive(:find).with(:all, :conditions => "purpose = 'user' AND owner_id = '#{0}'", :order => "name ASC").and_return([@tariff2])
    Tariff.should_receive(:find).with(:all, :conditions => "purpose = 'user_wholesale' AND owner_id = '#{0}'", :order => "name ASC").and_return([@tariff3])
    get "list"
  end

  it "should find all tariffs admin when acc_tariff_manage = 0" do
    User.should_not_receive(:find)
    login_as_accountant(6)
    session[:acc_tariff_manage] = 0
    get "list"
    flash[:notice].should eql(_('Dont_be_so_smart'))
  end

  it "should find all tariffs admin when acc_tariff_manage is not set" do
    User.should_not_receive(:find)
    login_as_accountant(6)
    session[:acc_tariff_manage] = nil
    get "list"
    flash[:notice].should eql(_('Dont_be_so_smart'))
  end

  it "shuld find all tariffs admin" do
    login_as_admin
    Tariff.stub!(:find)
    User.should_receive(:find).with(0).and_return(@user)
    Tariff.should_receive(:find).with(:all, {:conditions => "purpose = 'provider' AND owner_id = '#{@user.id}'", :order => "name ASC"}).and_return([@tariff1])
    Tariff.should_receive(:find).with(:all, {:conditions => "purpose = 'user' AND owner_id = '#{@user.id}'", :order => "name ASC"}).and_return([@tariff2])
    Tariff.should_receive(:find).with(:all, {:conditions => "purpose = 'user_wholesale' AND owner_id = '#{@user.id}'", :order => "name ASC"}).and_return([@tariff3])
    post "list"
  end

  it "shuld find all tariffs reseller" do
    login_as_reseller(8)
    Tariff.stub!(:find)
    User.should_receive(:find).with(8).and_return(@user)
    Tariff.should_receive(:find).with(:all, {:conditions => "purpose = 'provider' AND owner_id = '#{@user.id}'", :order => "name ASC"}).and_return([@tariff1])
    Tariff.should_receive(:find).with(:all, {:conditions => "purpose = 'user' AND owner_id = '#{@user.id}'", :order => "name ASC"}).and_return([@tariff2])
    Tariff.should_receive(:find).with(:all, {:conditions => "purpose = 'user_wholesale' AND owner_id = '#{@user.id}'", :order => "name ASC"}).and_return([@tariff3])
    post "list"
  end
end



describe TariffsController, "create" do
  before(:each) do
    @curr = get_mock_currency()
    @tariff = get_mock_tariff()
    @user = get_mock_user()
    RoleRight.stub!(:get_authorization).and_return(1)
  end

  it "shuld find all tariffs accountant" do
    login_as_accountant(6)
    tariff = {}
    tariff["name"] = "2008"
    tariff["purpose"] = "provider"
    tariff["currency"] = "3"
    Currency.should_receive(:find).with(:all, {:conditions => ["active = '1'"]}).and_return([@curr])
    Tariff.should_receive(:new).with(tariff).and_return(@tariff)
    @tariff.should_receive(:owner_id=)
    @tariff.should_receive(:save)
    post "create" , :tariff=> tariff
  end

  it "shuld find all tariffs admin" do
    login_as_admin()
    tariff = {}
    tariff["name"] = "2008"
    tariff["purpose"] = "provider"
    tariff["currency"] = "3"
    Currency.should_receive(:find).with(:all, {:conditions => ["active = '1'"]}).and_return([@curr])
    Tariff.should_receive(:new).with(tariff).and_return(@tariff)
    @tariff.should_receive(:owner_id=)
    @tariff.should_receive(:save)
    post "create" , :tariff=> tariff
  end
end


describe TariffsController, "change_tariff_for_users" do
  before(:each) do
    @curr = get_mock_currency()
    @tariff = get_mock_tariff()
    @user = get_mock_user()
    RoleRight.stub!(:get_authorization).and_return(1)
  end

  it "shuld find all tariffs accountant" do
    login_as_accountant(6)
    Tariff.should_receive(:find).with(:all, {:conditions => "owner_id = #{0} AND purpose like 'user%'"}).and_return(@tariff)
    post "change_tariff_for_users"
  end

  it "shuld find all tariffs admin" do
    login_as_admin()
    Tariff.should_receive(:find).with(:all, {:conditions => "owner_id = #{0} AND purpose like 'user%'"}).and_return(@tariff)
    post "change_tariff_for_users"
  end

  it "shuld find all tariffs resellr" do
    login_as_reseller(3)
    Tariff.should_receive(:find).with(:all, {:conditions => "owner_id = #{3} AND purpose like 'user%'"}).and_return(@tariff)
    post "change_tariff_for_users"
  end
end

describe TariffsController, ".check_prefix_availability" do

  before(:each) do
    login_as_admin
  end

  it "should run with not proper params" do
    request.stub!(:raw_post).and_return('9=')
    Destination.should_receive(:find).and_return([])
    get :check_prefix_availability, :tariff_id => 12
    assigns[:prefix].should eql("9")
    assigns[:tariff].should eql("12")
  end
  it "should run with not proper params" do
    request.stub!(:raw_post).and_return('asdasdas=')
    Destination.should_receive(:find).and_return([])
    get :check_prefix_availability, :tariff_id => 12
    assigns[:prefix].should eql("asdasdas")
    assigns[:tariff].should eql("12")
  end
end

describe TariffsController, ".rate_new_quick" do

  before(:each) do
    login_as_admin
    @tariff = get_mock_tariff(:id => 7)
  end

  it "should redirect when rate is already set" do
    Tariff.should_receive(:find).with(:first, :conditions => ["id = ?","7"]).and_return(@tariff)
    Rate.should_receive(:find).and_return(get_mock_rate)
    get :rate_new_quick, :prefix => "370", :price => "12.3", :id => 7, :page => 5
    flash[:notice].should eql(_("Rate_already_set") )
    response.should redirect_to("http://test.host/tariffs/rates_list/7?page=5")
  end

  it "should anonce if prefix was not found" do
    Tariff.should_receive(:find).with(:first, :conditions => ["id = ?","7"]).and_return(@tariff)
    Rate.should_receive(:find).and_return(nil)
    Destination.should_receive(:find).with(:first, :conditions => ["prefix = ?", "370"]).and_return(nil)
    get :rate_new_quick, :prefix => "370", :price => "12.3", :id => 7
    flash[:notice].should eql( _('Prefix_was_not_found'))
    response.should redirect_to("http://test.host/tariffs/rates_list/7?page=1")
  end

  it "should notice if rate cannot be created" do
    @tariff.should_receive(:add_new_rate).with(5, "12.3", 1, 0).and_return(false)
    Tariff.should_receive(:find).with(:first, :conditions => ["id = ?","7"]).and_return(@tariff)
    Rate.should_receive(:find).and_return(nil)
    Destination.should_receive(:find).with(:first, :conditions => ["prefix = ?", "370"]).and_return(get_mock_destination(:prefix => 370, :id => 5 ))
    get :rate_new_quick, :prefix => "370", :price => "12.3", :id => 7
    flash[:notice].should eql( _("Rate_was_not_added"))
    response.should redirect_to("http://test.host/tariffs/rates_list/7?page=1")
  end

  it "should notice if rate cannot be created" do
    @tariff.should_receive(:add_new_rate).with(5, "12.3", 1, 0).and_return(true)
    Tariff.should_receive(:find).with(:first, :conditions => ["id = ?","7"]).and_return(@tariff)
    Rate.should_receive(:find).and_return(nil)
    Destination.should_receive(:find).with(:first, :conditions => ["prefix = ?", "370"]).and_return(get_mock_destination(:prefix => 370 , :id => 5))
    get :rate_new_quick, :prefix => "370", :price => "12.3", :id => 7
    flash[:notice].should eql(_("Rate_was_added") )
    response.should redirect_to("http://test.host/tariffs/rates_list/7?page=1")
  end

end

describe TariffsController, ".rate_new_by_direction" do

  before (:each) do
    login_as_admin
    @tariff = get_mock_tariff(:id => 7)
  end

  it "should work withour exceptions" do
    @tariff.should_receive(:free_destinations_by_direction).and_return([1])
    Tariff.should_receive(:find).with(:first, :conditions => ["id = ?","7"]).and_return(@tariff)
    Direction.should_receive(:find).with(:first, :conditions => ['id = ?', "5"]).and_return(get_mock_direction(:id => 5))
    get :rate_new_by_direction, :id => 7, :dir_id => 5, :page => 1, :st => "G"
    assigns[:page].should eql(1)
    assigns[:total_items].should eql(1)
    assigns[:total_pages].should eql(1)
    assigns[:destinations].should eql([1])
    assigns[:page_select_options].should eql({:id => 7, :dir_id => 5, :st => "G"})
  end

end

describe TariffsController, ".rate_new_by_direction_add" do

  before (:each) do
    login_as_admin
    @tariff = get_mock_tariff(:id => 7)
  end

  it "should run withour error" do

    @tariff.should_receive(:free_destinations_by_direction).and_return([get_mock_destination(:id => 14)])
    @tariff.should_receive(:add_new_rate).with(14, "12", 1, 0)
    Tariff.should_receive(:find).with(:first, :conditions => ["id = ?","7"]).and_return(@tariff)
    Direction.should_receive(:find).with(:first, :conditions => ['id = ?', "5"]).and_return(get_mock_direction(:id => 5))
    get :rate_new_by_direction_add, :id => 7, :st => "G", :dir_id => 5, :dest_14 => 12
    flash[:notice].should eql( _('Rates_updated'))
    response.should redirect_to("http://test.host/tariffs/rate_new_by_direction/7?dir_id=5&st=G")
  end

end
