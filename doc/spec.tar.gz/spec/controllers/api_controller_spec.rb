require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'api_controller'

def enable_api
  Confline.stub!(:get_value)
  Confline.should_receive(:get_value).with("Allow_API").and_return("1")
  Confline.stub!(:get_value).with("Allow_GET_API").and_return("1")
end

describe ApiController, ".simple_balance" do

  before(:each) do
    enable_api
    @api_controller = ApiController.new
    @user = get_mock_user({:balance => "10.11"})
  end

  it "should show message when balance check is disabled" do
    Confline.should_receive(:get_value).with("Devices_Check_Ballance").and_return(0)
    get :simple_balance, :id => "f193hy5s2f"
    response.body.should eql( _("Feature_Disabled") )
  end

  it "should show message when balance check is enabled but user is not found" do
    Confline.should_receive(:get_value).with("Devices_Check_Ballance").and_return(1)
    User.should_receive(:find).with(:first, :conditions => "uniquehash = 'f193hy5s2z'").and_return(nil)
    get :simple_balance, :id => "f193hy5s2z"
    response.body.should eql( _("User_Not_Found") )
  end

  it "should format correct numbers when balance check is enabled" do
    Confline.should_receive(:get_value).with("Devices_Check_Ballance").and_return(1)
    User.should_receive(:find).with(:first, :conditions => "uniquehash = 'f193hy5s2f'").and_return(@user)
    get :simple_balance, :id => "f193hy5s2f"
    response.body.should eql("10.11")
  end
end

describe ApiController, ".user_details" do

  before(:each) do
    enable_api
    Confline.stub!(:get_value).with("Nice_Number_Digits").and_return("2")
    Confline.stub!(:get_value).with("API_Secret_Key").and_return("ABCD")
  end

  it "should return error if hash is not present" do
    get :user_details
    response.should have_tag("error", {:text => "Incorrect hash"})
  end

  it "should return error if no login info is presented" do
    get :user_details , :hash => "fb2f85c88567f3c8ce9b799c7c54642d0c7b41f6"
    response.should have_tag("error", {:text => "User was not found"})
  end

  it "should show user status if user info is valid" do
    User.should_receive(:find).with(:first, {:conditions=>"id = 12"}).and_return(get_mock_user)
    Direction.should_receive(:find).with(:first, :conditions => ["id =?", 123]).and_return(get_mock_direction)
    Confline.should_receive(:get_value).with("XML_API_Extension").and_return("0")

    get :user_details, :user_id => "12", :hash => "c002d46a00e92320f13aafc8a4b68376b9a9bdae"
    response.should have_tag("page", {:count => 1})
    response.should have_tag("pagename", {:text => "Personal_details",:count => 1})
    response.should have_tag("username", {:text => "mock_user",:count => 1})
    response.should have_tag("reg_address", {:text => "test street",:count => 1})
  end

  it "should show user status if user info is valid with XML_API_Extension" do
    User.should_receive(:find).with(:first, {:conditions=>"id = 12"}).and_return(get_mock_user)
    Direction.should_receive(:find).with(:first, :conditions => ["id =?", 123]).and_return(get_mock_direction)
    Confline.should_receive(:get_value).with("XML_API_Extension").and_return("1")
    get :user_details, :user_id => "12", :hash => "c002d46a00e92320f13aafc8a4b68376b9a9bdae"
    response.should have_tag("page", {:count => 1})
    response.should have_tag("pagename", {:text => "Personal_details",:count => 1})
    response.should have_tag("username", {:text => "mock_user",:count => 1})
    response.should have_tag("reg_address", {:text => "test street",:count => 1})
  end
end

describe ApiController, ".user_calls" do

  before(:each) do
    enable_api
    Confline.stub!(:get_value).with("API_Secret_Key").and_return("ABCD")
    Confline.stub!(:get_value).with("Nice_Number_Digits").and_return("2")
  end

  it "should return error if no login info is presented" do
    get :user_calls, :hash => "fb2f85c88567f3c8ce9b799c7c54642d0c7b41f6"
    MorLog.my_debug(response.body)
    response.should have_tag("error", {:text => "User was not found"})
  end

  it "should show user calls if user info is valid" do
    @user = get_mock_user
    @user.stub!(:calls => [get_mock_call])
    Currency.should_receive(:find).with(:first , :conditions => "id = 1").and_return(get_mock_currency)
    User.should_receive(:find).with(:first, {:conditions=>"id = 123"}).and_return(@user)
    Confline.should_receive(:get_value).with("XML_API_Extension").and_return("0")
    get :user_calls, :user_id => "123",:period_start => "100", :period_end => "200",:direction => "incoming",:calltype => "no_answer",:device => "123",:hash=> "5b03f1c689ed67259933624d6830a84d9d982582"
    response.should have_tag("page", {:count => 1})
    response.should have_tag("period_start", {:count => 1, :text=> "1970-01-01"})
    response.should have_tag("call", {:count => 1})
    response.should have_tag("price", {:count => 1, :text => "0.03"})
  end

  it "should show user calls if user info is valid with XML_API_Extension" do
    @user = get_mock_user
    @user.stub!(:calls => [get_mock_call])
    Currency.should_receive(:find).with(:first , :conditions => "id = 1").and_return(get_mock_currency)
    User.should_receive(:find).with(:first, {:conditions=>"id = 123"}).and_return(@user)
    Confline.should_receive(:get_value).with("XML_API_Extension").and_return("1")
    get :user_calls, :user_id => "123",:period_start => "100", :period_end => "200",:direction => "incoming",:calltype => "no_answer",:device => "123",:hash=> "5b03f1c689ed67259933624d6830a84d9d982582"

    response.should have_tag("page", {:count => 1})
    response.should have_tag("period_start", {:count => 1, :text=> "1970-01-01"})
    response.should have_tag("call", {:count => 1})
    response.should have_tag("price", {:count => 1, :text => "0.03"})
  end

end

