require File.dirname(__FILE__) +'/../spec_helper.rb'
require 'accounting_controller'

describe AccountingController, ".generate_invoice_pdf" do
  before(:each) do
    Confline.stub!(:get_value, :get_value2)

    @mock_user = get_mock_user
    @mock_address = mock_model(Address, :id =>3, :emeil=>10, :address=>"dddd", :city=>"ddrrd", :postcode=>"rersd", :state=>"dddDWEFRE")
    @mock_direction =  mock_model(Direction , :id =>4, :name=>"bla")
    #@mock_call = mock_model(Call, :id =>4, :user_id=>3, :provider=>"Checkbox", :default_value => "0", :name => "test")
    @mock_invc = mock_model(Invoice, :id =>4, :user_id=>3, :price=>100, :price_with_vat => 110, :number => "test", :issue_date=>"2001-0-01 01:01:01", :period_start=>"2001-01-01 01:01:01", :period_end=>"2002-02-02 02:02:02")
    @mock_invc_d = mock_model(Invoicedetail, :id =>4, :invoice_id=>4, :name=>"Calls", :quantity => 11, :price => 110, :invdet_type=> 0)
    @mock_conf_1 =  mock_model(Confline , :id =>4, :name=>"Tax_1" , :value=>"Tax_1", :value2 => 1)
    @mock_conf_2 =  mock_model(Confline , :id =>5, :name=> "Tax_2",:value=>"Tax_2", :value2 => 1)
    @mock_conf_3 =  mock_model(Confline , :id =>6, :name=> "Tax_3",:value=>"Tax_3", :value2 => 1)
    @mock_conf_4 =  mock_model(Confline , :id =>7, :name=> "Tax_4",:value=>"Tax_4", :value2 => 1)
    @mock_conf_5 =  mock_model(Confline , :id =>8, :name=> "Total_tax_name",:value=>"Total_tax_name", :value2 => 1)
    @mock_conf_6 =  mock_model(Confline , :id =>9, :name=> "Invoice_Address1",:value=>"Invoice_Address1", :value2 => 1)
    @mock_conf_7 =  mock_model(Confline , :id =>1, :name=> "Invoice_Address2",:value=>"Invoice_Address2", :value2 => 1)
    @mock_conf_8 =  mock_model(Confline , :id =>2, :name=> "Invoice_Address3",:value=>"Invoice_Address3", :value2 => 1)
    @mock_conf_9 =  mock_model(Confline , :id =>3, :name=> "Invoice_Address4",:value=>"Invoice_Address4", :value2 => 1)
    @mock_conf_10 =  mock_model(Confline , :id =>10, :name=> "Invoice_Address_Format",:value=>1, :value2 => 1)
    #    @mock_conf_11 =  mock_model(Confline , :id =>11, :name=> "Invoice_Balance_Line",:value=>"Invoice_Balance_Line", :value2 => 1)
    @mock_conf_12 =  mock_model(Confline , :id =>12, :name=> "Nice_Number_Digits",:value=>3, :value2 => 3)
    @mock_conf_13 =  mock_model(Confline , :id =>13, :name=> "Invoice_Bank_Details_Line1",:value=>"Invoice_Bank_Details_Line1", :value2 => 3)
    @mock_conf_14 =  mock_model(Confline , :id =>14, :name=> "Invoice_Bank_Details_Line2",:value=>"Invoice_Bank_Details_Line2", :value2 => 3)
    @mock_conf_15 =  mock_model(Confline , :id =>15, :name=> "Invoice_Bank_Details_Line3",:value=>"Invoice_Bank_Details_Line3", :value2 => 3)
    @mock_conf_16 =  mock_model(Confline , :id =>16, :name=> "Invoice_Bank_Details_Line4",:value=>"Invoice_Bank_Details_Line4", :value2 => 3)
    @mock_conf_17 =  mock_model(Confline , :id =>17, :name=> "Invoice_Bank_Details_Line5",:value=>"Invoice_Bank_Details_Line5", :value2 => 3)
    @mock_conf_18 =  mock_model(Confline , :id =>18, :name=> "Invoice_End_Title",:value=>"Invoice_End_Title", :value2 => 3)

    @mock_invc_ds = [@mock_invc_d]
  end

  it "should get all users tax " do
    login_as_admin
    Invoice.should_receive(:find).with("4").and_return(@mock_invc)
    @mock_invc.should_receive(:invoicedetails).and_return(@mock_invc_ds)
    @mock_invc.should_receive(:invoice_type).exactly(2).times.and_return("postpaid")
    @mock_invc.stub!(:user => @mock_user)
    @mock_user.should_receive(:address).and_return(@mock_address)
    @mock_address.should_receive(:direction).and_return(@mock_direction)
    Confline.should_receive(:get_value).with("Invoice_Address1", 0).and_return(@mock_conf_6.value)
    Confline.should_receive(:get_value).with("Invoice_Address2", 0).and_return(@mock_conf_7.value)
    Confline.should_receive(:get_value).with("Invoice_Address3", 0).and_return(@mock_conf_8.value)
    Confline.should_receive(:get_value).with("Invoice_Address4", 0).and_return(@mock_conf_9.value)
    Confline.should_receive(:get_value).with("Invoice_Address_Format",0).and_return(@mock_conf_10.value)
    #    Confline.should_receive(:get_value).with("Invoice_Balance_Line",0).and_return(@mock_conf_11.value)
    #Confline.should_receive(:get_value).exactly(9).times.with("Nice_Number_Digits").and_return(@mock_conf_12.value)
    Confline.should_receive(:get_value).with("Invoice_Bank_Details_Line1", 0).and_return(@mock_conf_13.value)
    Confline.should_receive(:get_value).with("Invoice_Bank_Details_Line2", 0).and_return(@mock_conf_14.value)
    Confline.should_receive(:get_value).with("Invoice_Bank_Details_Line3", 0).and_return(@mock_conf_15.value)
    Confline.should_receive(:get_value).with("Invoice_Bank_Details_Line4", 0).and_return(@mock_conf_16.value)
    Confline.should_receive(:get_value).with("Invoice_Bank_Details_Line5", 0).and_return(@mock_conf_17.value)
    Confline.should_receive(:get_value).with("Invoice_End_Title",0).and_return(@mock_conf_18.value)
    AccountingController.stub!(:return).and_return("true")
    get "generate_invoice_pdf", :id => 4, :email_or_not => 1
  end


end


describe AccountingController, ".generate_invoice_detailed_pdf" do
  before(:each) do

    Confline.stub!(:get_value, :get_value2)
    @mock_user = get_mock_user
    @mock_address = mock_model(Address, :id =>3, :emeil=>10, :address=>"dddd", :city=>"ddrrd", :postcode=>"rersd", :state=>"dddDWEFRE")
    @mock_direction =  mock_model(Direction , :id =>4, :name=>"bla")
    #@mock_call = mock_model(Call, :id =>4, :user_id=>3, :provider=>"Checkbox", :default_value => "0", :name => "test")
    @mock_invc = mock_model(Invoice, :id =>4, :user_id=>3, :price=>100, :price_with_vat => 110, :number => "test", :issue_date=>"2001-0-01 01:01:01", :period_start=>"2001-01-01 01:01:01", :period_end=>"2002-02-02 02:02:02")
    @mock_invc_d = mock_model(Invoicedetail, :id =>4, :invoice_id=>4, :name=>"Calls", :quantity => 11, :price => 110, :invdet_type=> 0)
    @mock_conf_1 =  mock_model(Confline , :id =>4, :name=>"Tax_1" , :value=>"Tax_1", :value2 => 1)
    @mock_conf_2 =  mock_model(Confline , :id =>5, :name=> "Tax_2",:value=>"Tax_2", :value2 => 1)
    @mock_conf_3 =  mock_model(Confline , :id =>6, :name=> "Tax_3",:value=>"Tax_3", :value2 => 1)
    @mock_conf_4 =  mock_model(Confline , :id =>7, :name=> "Tax_4",:value=>"Tax_4", :value2 => 1)
    @mock_conf_5 =  mock_model(Confline , :id =>8, :name=> "Total_tax_name",:value=>"Total_tax_name", :value2 => 1)
    @mock_conf_6 =  mock_model(Confline , :id =>9, :name=> "Invoice_Address1",:value=>"Invoice_Address1", :value2 => 1)
    @mock_conf_7 =  mock_model(Confline , :id =>1, :name=> "Invoice_Address2",:value=>"Invoice_Address2", :value2 => 1)
    @mock_conf_8 =  mock_model(Confline , :id =>2, :name=> "Invoice_Address3",:value=>"Invoice_Address3", :value2 => 1)
    @mock_conf_9 =  mock_model(Confline , :id =>3, :name=> "Invoice_Address4",:value=>"Invoice_Address4", :value2 => 1)
    @mock_conf_10 =  mock_model(Confline , :id =>10, :name=> "Invoice_Address_Format",:value=>1, :value2 => 1)
    @mock_conf_11 =  mock_model(Confline , :id =>11, :name=> "Invoice_Balance_Line",:value=>"Invoice_Balance_Line", :value2 => 1)
    @mock_conf_12 =  mock_model(Confline , :id =>12, :name=> "Nice_Number_Digits",:value=>3, :value2 => 3)
    @mock_conf_13 =  mock_model(Confline , :id =>13, :name=> "Invoice_Bank_Details_Line1",:value=>"Invoice_Bank_Details_Line1", :value2 => 3)
    @mock_conf_14 =  mock_model(Confline , :id =>14, :name=> "Invoice_Bank_Details_Line2",:value=>"Invoice_Bank_Details_Line2", :value2 => 3)
    @mock_conf_15 =  mock_model(Confline , :id =>15, :name=> "Invoice_Bank_Details_Line3",:value=>"Invoice_Bank_Details_Line3", :value2 => 3)
    @mock_conf_16 =  mock_model(Confline , :id =>16, :name=> "Invoice_Bank_Details_Line4",:value=>"Invoice_Bank_Details_Line4", :value2 => 3)
    @mock_conf_17 =  mock_model(Confline , :id =>17, :name=> "Invoice_Bank_Details_Line5",:value=>"Invoice_Bank_Details_Line5", :value2 => 3)
    @mock_conf_18 =  mock_model(Confline , :id =>18, :name=> "Invoice_End_Title",:value=>"Invoice_End_Title", :value2 => 3)
    @mock_conf_19 =  mock_model(Confline , :id =>19, :name=> "Invoice_Show_Calls_In_Detailed",:value=>"Invoice_Show_Calls_In_Detailed", :value2 => 3)
    @mock_tariff = mock_model(Tariff, :id =>4 , :purpose=>"user")
    @mock_invc_ds = [@mock_invc_d]
  end

  it "get all users tax " do
    login_as_admin


    Invoice.should_receive(:find).with("4").and_return(@mock_invc)
    @mock_invc.should_receive(:invoicedetails).and_return(@mock_invc_ds)
    @mock_invc.should_receive(:invoice_type).exactly(2).times.and_return("postpaid")
    @mock_invc. stub!(:user => @mock_user)
    @mock_user.should_receive(:address).and_return(@mock_address)
    @mock_user.should_receive(:tariff).and_return(@mock_tariff)
    @mock_address.should_receive(:direction).and_return(@mock_direction)
    Confline.should_receive(:get_value).with("Invoice_Address1", 0).and_return(@mock_conf_6.value)
    Confline.should_receive(:get_value).with("Invoice_Address2", 0).and_return(@mock_conf_7.value)
    Confline.should_receive(:get_value).with("Invoice_Address3", 0).and_return(@mock_conf_8.value)
    Confline.should_receive(:get_value).with("Invoice_Address4", 0).and_return(@mock_conf_9.value)
    Confline.should_receive(:get_value).with("Invoice_Address_Format", 0).and_return(@mock_conf_10.value)
    #    Confline.should_receive(:get_value).with("Invoice_Balance_Line",0).and_return(@mock_conf_11.value)
    #Confline.should_receive(:get_value).exactly(7).times.with("Nice_Number_Digits").and_return(@mock_conf_12.value)
    Confline.should_receive(:get_value).with("Invoice_Bank_Details_Line1",0).and_return(@mock_conf_13.value)
    Confline.should_receive(:get_value).with("Invoice_Bank_Details_Line2",0).and_return(@mock_conf_14.value)
    Confline.should_receive(:get_value).with("Invoice_Bank_Details_Line3",0).and_return(@mock_conf_15.value)
    Confline.should_receive(:get_value).with("Invoice_Bank_Details_Line4",0).and_return(@mock_conf_16.value)
    Confline.should_receive(:get_value).with("Invoice_Bank_Details_Line5",0).and_return(@mock_conf_17.value)
    Confline.should_receive(:get_value).with("Invoice_End_Title",0).and_return(@mock_conf_18.value)
    Confline.should_receive(:get_value).with("Invoice_Show_Calls_In_Detailed", 0).and_return(@mock_conf_19.value)

    AccountingController.stub!(:return).and_return("true")
    get "generate_invoice_detailed_pdf", :id => 4, :email_or_not => 1
  end


end



describe AccountingController, ".generate_invoice_by_cid_pdf" do
  before(:each) do

    Confline.stub!(:get_value, :get_value2)
    @mock_user = get_mock_user
    @mock_address = mock_model(Address, :id =>3, :emeil=>10, :address=>"dddd", :city=>"ddrrd", :postcode=>"rersd", :state=>"dddDWEFRE")
    @mock_direction =  mock_model(Direction , :id =>4, :name=>"bla")
    #@mock_call = mock_model(Call, :id =>4, :user_id=>3, :provider=>"Checkbox", :default_value => "0", :name => "test")
    @mock_invc = mock_model(Invoice, :id =>4, :user_id=>3, :price=>100, :price_with_vat => 110, :number => "test", :issue_date=>"2001-0-01 01:01:01", :period_start=>"2001-01-01 01:01:01", :period_end=>"2002-02-02 02:02:02")
    @mock_invc_d = mock_model(Invoicedetail, :id =>4, :invoice_id=>4, :name=>"Calls", :quantity => 11, :price => 110, :invdet_type=> 0)
    @mock_conf_1 =  mock_model(Confline , :id =>4, :name=>"Tax_1" , :value=>"Tax_1", :value2 => 1)
    @mock_conf_2 =  mock_model(Confline , :id =>5, :name=> "Tax_2",:value=>"Tax_2", :value2 => 1)
    @mock_conf_3 =  mock_model(Confline , :id =>6, :name=> "Tax_3",:value=>"Tax_3", :value2 => 1)
    @mock_conf_4 =  mock_model(Confline , :id =>7, :name=> "Tax_4",:value=>"Tax_4", :value2 => 1)
    @mock_conf_5 =  mock_model(Confline , :id =>8, :name=> "Total_tax_name",:value=>"Total_tax_name", :value2 => 1)
    @mock_conf_6 =  mock_model(Confline , :id =>9, :name=> "Invoice_Address1",:value=>"Invoice_Address1", :value2 => 1)
    @mock_conf_7 =  mock_model(Confline , :id =>1, :name=> "Invoice_Address2",:value=>"Invoice_Address2", :value2 => 1)
    @mock_conf_8 =  mock_model(Confline , :id =>2, :name=> "Invoice_Address3",:value=>"Invoice_Address3", :value2 => 1)
    @mock_conf_9 =  mock_model(Confline , :id =>3, :name=> "Invoice_Address4",:value=>"Invoice_Address4", :value2 => 1)
    @mock_conf_10 =  mock_model(Confline , :id =>10, :name=> "Invoice_Address_Format",:value=>1, :value2 => 1)
    @mock_conf_11 =  mock_model(Confline , :id =>11, :name=> "Invoice_Balance_Line",:value=>"Invoice_Balance_Line", :value2 => 1)
    @mock_conf_12 =  mock_model(Confline , :id =>12, :name=> "Nice_Number_Digits",:value=>3, :value2 => 3)
    @mock_conf_13 =  mock_model(Confline , :id =>13, :name=> "Invoice_Bank_Details_Line1",:value=>"Invoice_Bank_Details_Line1", :value2 => 3)
    @mock_conf_14 =  mock_model(Confline , :id =>14, :name=> "Invoice_Bank_Details_Line2",:value=>"Invoice_Bank_Details_Line2", :value2 => 3)
    @mock_conf_15 =  mock_model(Confline , :id =>15, :name=> "Invoice_Bank_Details_Line3",:value=>"Invoice_Bank_Details_Line3", :value2 => 3)
    @mock_conf_16 =  mock_model(Confline , :id =>16, :name=> "Invoice_Bank_Details_Line4",:value=>"Invoice_Bank_Details_Line4", :value2 => 3)
    @mock_conf_17 =  mock_model(Confline , :id =>17, :name=> "Invoice_Bank_Details_Line5",:value=>"Invoice_Bank_Details_Line5", :value2 => 3)
    @mock_conf_18 =  mock_model(Confline , :id =>18, :name=> "Invoice_End_Title",:value=>"Invoice_End_Title", :value2 => 3)
    @mock_conf_19 =  mock_model(Confline , :id =>19, :name=> "Invoice_Show_Calls_In_Detailed",:value=>"Invoice_Show_Calls_In_Detailed", :value2 => 3)
    @mock_tariff = mock_model(Tariff, :id =>4 , :purpose=>"user")
    @mock_invc_ds = [@mock_invc_d]
  end

  it "get all users tax " do
    login_as_admin


    Invoice.should_receive(:find).with("4").and_return(@mock_invc)
    @mock_invc.should_receive(:invoicedetails).and_return(@mock_invc_ds)
    @mock_invc.should_receive(:invoice_type).exactly(3).times.and_return("postpaid")
    @mock_invc. stub!(:user => @mock_user)
    @mock_user.should_receive(:address).and_return(@mock_address)
    #@mock_user.should_receive(:tariff).and_return(@mock_tariff)
    @mock_address.should_receive(:direction).and_return(@mock_direction)
    Confline.should_receive(:get_value).with("Invoice_Address1", 0).and_return(@mock_conf_6.value)
    Confline.should_receive(:get_value).with("Invoice_Address2", 0).and_return(@mock_conf_7.value)
    Confline.should_receive(:get_value).with("Invoice_Address3", 0).and_return(@mock_conf_8.value)
    Confline.should_receive(:get_value).with("Invoice_Address4", 0).and_return(@mock_conf_9.value)
    Confline.should_receive(:get_value).with("Invoice_Address_Format", 0).and_return(@mock_conf_10.value)
    #    Confline.should_receive(:get_value).with("Invoice_Balance_Line",0).and_return(@mock_conf_11.value)
    #    Confline.should_receive(:get_value).exactly(6).times.with("Nice_Number_Digits").and_return(@mock_conf_12.value)
    #    Confline.should_receive(:get_value).with("Invoice_Bank_Details_Line1",0).and_return(@mock_conf_13.value)
    #    Confline.should_receive(:get_value).with("Invoice_Bank_Details_Line2",0).and_return(@mock_conf_14.value)
    #    Confline.should_receive(:get_value).with("Invoice_Bank_Details_Line3",0).and_return(@mock_conf_15.value)
    #    Confline.should_receive(:get_value).with("Invoice_Bank_Details_Line4",0).and_return(@mock_conf_16.value)
    #    Confline.should_receive(:get_value).with("Invoice_Bank_Details_Line5",0).and_return(@mock_conf_17.value)
    Confline.should_receive(:get_value).with("Invoice_End_Title",0).and_return(@mock_conf_18.value)

    AccountingController.stub!(:return).and_return("true")
    get "generate_invoice_by_cid_pdf", :id => 4, :email_or_not => 1
  end


end



describe AccountingController, ".voucher_active" do
  before(:each) do


    @voucher = get_mock_voucher({:id => 488})
    @voucher2 = get_mock_voucher({:id => 488, :active=>"0"})
  end

  it "activate interval vouchers " do
    login_as_admin

    data = {}
    data["v"]="488"

    Voucher.should_receive(:find).with(data).and_return([@voucher])
    @voucher.should_receive(:active=).with(1)
    @voucher.should_receive(:save)
    get "voucher_active", :v => data, :page => 1, :vaction=>"active", :interval=>1
  end

  it "deactivate interval vouchers " do
    login_as_admin

    data = {}
    data["v"]="488"

    Voucher.should_receive(:find).with(data).and_return([@voucher])
    @voucher.should_receive(:active=).with(0)
    @voucher.should_receive(:save)
    get "voucher_active", :v => data, :page => 1, :vaction=>"deactive", :interval=>1
  end

  it "deactivate one vouchers " do
    login_as_admin


    Voucher.should_receive(:find).with("488").and_return(@voucher)
    @voucher.should_receive(:active=).with(0)
    @voucher.should_receive(:save)
    get "voucher_active", :id => 488, :page => 1, :interval=>2
  end

  it "activate one vouchers " do
    login_as_admin


    Voucher.should_receive(:find).with("488").and_return(@voucher2)
    @voucher2.should_receive(:active=).with(1)
    @voucher2.should_receive(:save)
    get "voucher_active", :id => 488, :page => 1, :interval=>2
  end

end

describe AccountingController, ".send_invoices" do
  before(:each) do


    @email = get_mock_email({:id => 4, :name => 'invoices'})
    @invoice = get_mock_invoice()
    @user = get_mock_user()
    @device = get_mock_device()
    Invoice.stub!(:find)
  end

  it "send_invoices assigns test " do
    login_as_admin

    sql = "SELECT invoices.* FROM invoices, users WHERE invoices.user_id = users.id AND users.owner_id = '#{0}' AND period_start >='#{"2007-01-01"}' AND period_end <= '#{"2010-12-31"}'"
    Invoice.should_receive(:find_by_sql).with(sql).and_return([@invoice])
    Invoice.stub!(:find).with("1").and_return(@invoice)
    Email.should_receive(:find).with(:first, :conditions => ["name = 'invoices'"] ).and_return(@email)
    @invoice.should_receive(:user).and_return(@user)
    @invoice.should_receive(:invoice_type).and_return("postpaid")
    @user.should_receive(:email).and_return("vitalijawitta@yahoo.com")
    @user.stub!(:csv_params).and_return([".", ";"])
    @user.should_receive(:send_invoice_types).and_return(0)
    @user.should_receive(:primary_device).and_return(@device)
    @device.should_receive(:device_type).and_return("444")
    @device.should_receive(:name).and_return("444")
    @device.should_receive(:secret).and_return("444")
    EmailsController.should_receive(:send_email_with_attachment).with(@email, "", nil, nil, nil, nil, nil, nil, @user, {:server_ip => Confline.get_value("Asterisk_Server_IP"), :device_type => "444", :device_username =>  "444", :device_password => "444", :login_url => Web_URL + Web_Dir, :login_username => @user.username, :login_password => "", :full_name => @user.first_name + "  " + @user.last_name, :username => @user.username, :last_name => @user.last_name, :first_name => @user.first_name}).and_return([1,1])
    @invoice.should_receive(:sent_email=).and_return(1)
    @invoice.should_receive(:save)
    get "send_invoices", :c2c => 0
  end

end

describe AccountingController, ".generate_invoices_status" do
  before(:each) do
    @user = get_mock_user()
    @subscription = get_mock_subscription()
    @invoice = get_mock_invoice()
    @service = get_mock_service()
  end

  it "generate invoice " do
    login_as_admin

    data = {}
    data["year"] = "2009"
    data["month"] = "01"

    Confline.should_receive(:get_value).with("Invoice_Number_Start",0).and_return("10")
    Confline.should_receive(:get_value).with("Invoice_Number_Length",0).and_return("10")
    Confline.should_receive(:get_value).with("Invoice_Number_Type",0).and_return("10")
    Confline.should_receive(:get_value).with("Invoice_Period_Start_Day",0).and_return("10")
    Time.should_receive(:mktime).with("2009", "01", "10").and_return("2009-01-10".to_time)
    Time.should_receive(:mktime).with("2009", 2, "10", 23, 59, 59).and_return("2009-02-10 23:59:59".to_time)
    User.should_receive(:count).with(:all, :conditions => "owner_id = #{0} AND hidden = 0 AND postpaid = 1 ")
    @period_start = "2009-01-10"
    sql = "SELECT users.*, C.count_id FROM users LEFT JOIN (SELECT COUNT(id) as 'count_id', user_id FROM invoices WHERE period_start = '#{@period_start}' GROUP BY user_id) as C ON (C.user_id = users.id) WHERE users.owner_id = '#{0}' AND users.hidden = 0  AND users.postpaid = 1 AND C.count_id IS NULL AND users.generate_invoice = 1;"
    User.should_receive(:find_by_sql).with(sql).and_return([@user])
    @user.should_receive(:own_outgoing_calls_stats_in_period).with("2009-01-10 00:00:00", "2009-02-09 23:59:59").and_return([33, 44])
    @user.should_receive(:incoming_calls_stats_in_period).with("2009-01-10 00:00:00", "2009-02-09 23:59:59").and_return([33, 44])
    @user.should_receive(:subscriptions_in_period).with("2009-01-10 00:00:00", "2009-02-09 23:59:59").and_return([@subscription])
    Invoice.should_receive(:new).and_return(@invoice)
    @invoice.should_receive(:user_id=)
    @invoice.should_receive(:period_start=)
    @invoice.should_receive(:period_end=)
    @invoice.should_receive(:issue_date=)
    @invoice.should_receive(:paid=)
    @invoice.should_receive(:invoice_type=)
    @subscription.should_receive(:service).and_return(@service)
    @user.should_receive(:balance=)
    @user.should_receive(:save)
    @invoice.should_receive(:price=)
    @invoice.should_receive(:price_with_vat=)
    @invoice.should_receive(:number=).exactly(2).times
    @invoice.should_receive(:number)
    @invoice.should_receive(:save).exactly(2).times
    get "generate_invoices_status", :date => data
  end
end

describe AccountingController, ".generate_invoices_status_for_prepaid_users" do
  before(:each) do
    @user = get_mock_user()
    @subscription = get_mock_subscription()
    @invoice = get_mock_invoice()
    @service = get_mock_service()
  end

  it "generate invoice " do
    login_as_admin

    data = {}
    data["year"] = "2009"
    data["month"] = "01"

    Confline.should_receive(:get_value).with("Prepaid_Invoice_Number_Start",0).and_return("10")
    Confline.should_receive(:get_value).with("Prepaid_Invoice_Number_Length",0).and_return("10")
    Confline.should_receive(:get_value).with("Prepaid_Invoice_Number_Type",0).and_return("10")
    Confline.should_receive(:get_value).with("Prepaid_Invoice_Period_Start_Day",0).and_return("10")
    Time.should_receive(:mktime).with("2009", "01", "10").and_return("2009-01-10".to_time)
    Time.should_receive(:mktime).with("2009", 2, "10", 23, 59, 59).and_return("2009-02-10 23:59:59".to_time)
    User.should_receive(:count).with(:all, :conditions => "owner_id = #{0} AND hidden = 0 AND postpaid = 0 ")
    @period_start = "2009-01-10"
    sql = "SELECT users.*, C.count_id FROM users LEFT JOIN (SELECT COUNT(id) as 'count_id', user_id FROM invoices WHERE period_start = '#{@period_start}' GROUP BY user_id) as C ON (C.user_id = users.id) WHERE users.owner_id = '#{0}' AND users.hidden = 0 AND users.postpaid = 0 AND C.count_id IS NULL AND users.generate_invoice = 1;"
    User.should_receive(:find_by_sql).with(sql).and_return([@user])
    #@user.should_receive(:own_outgoing_calls_stats_in_period).with("2009-01-10 00:00:00", "2009-02-09 23:59:59").and_return([33, 44])
    #@user.should_receive(:incoming_calls_stats_in_period).with("2009-01-10 00:00:00", "2009-02-09 23:59:59").and_return([33, 44])
    @user.should_receive(:subscriptions_in_period).with("2009-01-10 00:00:00", "2009-02-09 23:59:59").and_return([@subscription])
    Invoice.should_receive(:new).and_return(@invoice)
    @invoice.should_receive(:user_id=)
    @invoice.should_receive(:period_start=)
    @invoice.should_receive(:period_end=)
    @invoice.should_receive(:issue_date=)
    @invoice.should_receive(:paid=)
    @invoice.should_receive(:invoice_type=)
    @subscription.should_receive(:service).and_return(@service)
    @user.should_receive(:balance=)
    @user.should_receive(:save)
    @invoice.should_receive(:price=)
    @invoice.should_receive(:price_with_vat=)
    @invoice.should_receive(:number=).exactly(2).times
    @invoice.should_receive(:number)
    @invoice.should_receive(:save).exactly(2).times
    get "generate_invoices_status_for_prepaid_users", :date => data
  end
end


describe AccountingController, ".invoices" do
  before(:each) do
    @invoice = get_mock_invoice()

  end

  it "generate invoice " do
    login_as_admin
    cond = " invoices.invoice_type = '#{"prepaid"}' "
    sql = "SELECT invoices.* FROM invoices, users WHERE invoices.user_id = users.id AND users.owner_id = '#{0}' AND #{cond}"
    Invoice.should_receive(:find_by_sql).with(sql).and_return([@invoice])
    get "invoices", :s_ivnoice_type => "prepaid"
  end
end

