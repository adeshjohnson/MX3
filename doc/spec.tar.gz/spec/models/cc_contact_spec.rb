require File.dirname(__FILE__) +'/../spec_helper.rb' 

describe CcContact, ".update_contact" do
  
  before(:each) do
    @mock_contact = mock_model(CcContact, :id => 12)
  end
  
  it "should update contact information" do
  end
  
end

