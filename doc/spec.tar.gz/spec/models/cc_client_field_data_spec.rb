require File.dirname(__FILE__) +'/../spec_helper.rb' 

describe CcClientFieldData, ".update_client_field_data" do
  
  before(:each) do
    @mock_client = mock_model(CcClient, :id => 12)
  end
  
  it "should update data fields" do  
    lambda{
      CcClientFieldData.update_client_field_data({"field5" => "Test", "field6" => "2"}, @mock_client)
    }.should change(CcClientFieldData, :count).by(2)
    lambda{
      CcClientFieldData.update_client_field_data({"field5" => "Test", "field6" => "2"},  @mock_client)
    }.should_not change(CcClientFieldData, :count)
    
    lambda{
      CcClientFieldData.update_client_field_data({"field5" => "Test"}, @mock_client)
    }.should change(CcClientFieldData, :count).by(-1)
  end
  
end

