require File.dirname(__FILE__) +'/../spec_helper.rb' 
require 'tariff'

describe Tariff, "make_wholesale_tariff" do
  before(:each) do
    @tariff = Tariff.new()
    @tariff.purpose = 'provider'
    @tariff.name = 'Test Tariff_new '
    @tariff.owner_id = 0
    @tariff.currency = 'USD'
    @tariff.id = 0
    @tariff.save
  end
  
  it "should create new tariff with valid values" do
    rate = Rate.new 
    rate.tariff_id = @tariff.id
    rate.destination_id = 1
    rate.save
    rate2 = Rate.new 
    rate2.tariff_id = @tariff.id
    rate2.destination_id = 2
    rate2.save
    @rates = [rate, rate2]
    det = Ratedetail.new  
    det.start_time = "00:00:00"
    det.end_time = "23:59:59"
    det.rate = 10
    det.connection_fee = 0
    det.rate_id = rate.id
    det.increment_s = "1"
    det.min_time = 0
    det2 = Ratedetail.new
    det2.start_time = "00:00:00"
    det2.end_time = "23:59:59"
    det2.rate = 10
    det2.connection_fee = 0
    det2.rate_id = rate2.id
    det2.increment_s = "1"
    det2.min_time = 0
    @rate_details = [det]
    @rate_details2 = [det2]
    Tariff.should_receive(:find).twice.and_return(nil)
    @tariff.should_receive(:rates).and_return(@rates)
    rate.should_receive(:ratedetails).and_return(@rate_details)
    rate2.should_receive(:ratedetails).and_return(@rate_details2)
    lambda {
    lambda {
    lambda {
      tariff_new = @tariff.make_wholesale_tariff("12","12","provider")
      tariff_new.name.should eql("#{@tariff.name} + 12 + 12%")
      tariff_new.owner_id.should eql(@tariff.owner_id)
      tariff_new.currency.should eql(@tariff.currency)
    }.should change(Tariff, :count) 
    }.should change(Rate, :count) 
    }.should change(Ratedetail, :count)
  end
  
  it "should find all rates and ratedetails" do
  end
  
  it "should not create tariff with same name" do
    Tariff.should_receive(:find).and_return(@tariff)
    @tariff.make_wholesale_tariff("12","12","provider").to_s.should eql('false')
  end

end

