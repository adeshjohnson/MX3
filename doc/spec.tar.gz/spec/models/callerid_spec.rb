require File.dirname(__FILE__) +'/../spec_helper.rb' 
describe Callerid, ".use_for_callback(callid, status)" do
   before(:each) do
    @cli  = get_mock_cli({:id=> 1, :email_callback=>0})
    @cli2 = get_mock_cli({:id=> 2, :email_callback=>1})
    @cli3 = get_mock_cli({:id=> 3, :email_callback=>0})
    @clis = [@cli,@cli2,@cli3]   
  end
  
  it "should set status" do
     Callerid.use_for_callback(@cli, 1)
     Callerid.use_for_callback(@cli, 0)
  end
end

describe Callerid, ".set_callback_from_emails(old_callerid, new_callerid)" do
   before(:each) do
    @cli  = get_mock_cli({:id=> 1, :cli=>"senas", :email_callback=>0})
    @cli2 = get_mock_cli({:id=> 2, :cli=>"antras", :email_callback=>1})
    @cli3 = get_mock_cli({:id=> 3, :cli=>"trecias", :email_callback=>0})
    @cli4 = get_mock_cli({:id=> 4, :cli=>"444", :email_callback=>"1"})
    @clis = [@cli,@cli2,@cli3]   
  end
  
  it "should set status" do
    Callerid.stub!(:find => true)
    Callerid.should_receive(:find).with(:first, :conditions => "cli = '#{@cli.cli}' AND email_callback = '1' ").and_return(@cli)
    Callerid.should_receive(:find).with(:first, :conditions => "cli = '#{@cli2.cli}'").and_return(@cli2)
    lambda {
      Callerid.set_callback_from_emails(@cli.cli, @cli2.cli)
    }.should_not change(Callerid, :count)
  end
  
  it "should create new callerid and set email_callback to 1" do
    Callerid.stub!(:find => true)
    Callerid.should_receive(:find).with(:first, :conditions => "cli = '#{@cli4.cli}' AND email_callback = '1' ").and_return(@cli)
    Callerid.should_receive(:find).with(:first, :conditions => "cli = 'gss'").and_return(nil)
    lambda {
      Callerid.set_callback_from_emails(@cli4.cli, "gss")
    }.should change(Callerid, :count)
  end
  
  it "should get error" do
    User.should_receive(:find).with(:first, :conditions => "id = 0").and_return(get_mock_user)
    Callerid.stub!(:find => false)
    lambda {
     Callerid.set_callback_from_emails("nera", "naujas")}.should change(Action, :count)
  end
  
  it "should get error because old callerid.email_callback != 1" do
    User.should_receive(:find).with(:first, :conditions => "id = 0").and_return(get_mock_user)
    Callerid.stub!(:find => false)
    lambda {
     Callerid.set_callback_from_emails("trecias", "naujas")}.should change(Action, :count)
  end
  
end