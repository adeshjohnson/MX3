require File.dirname(__FILE__) +'/../spec_helper.rb' 
require 'user'

def new_user()
  user = User.new
  user.username = "test_reseller"
  user.last_name = "Test"
  user.first_name = "Testas"
  user.password = "abc"
  user.usertype = "reseller"
  user
end

describe User, ".get_hash" do
  before(:each) do
    @user = new_user
    @user.uniquehash = ""
    @user.save
    ApplicationController.should_receive(:random_password).with(10).and_return('0123456789')
  end
  
  it "should return or generate new hash for user" do
    @user.uniquehash = ""
    hash = @user.get_hash
    hash.should eql("0123456789")    
    @user.get_hash.should eql(hash)
  end
  
  it "should return or generate new hash from model" do
    hash = User.get_hash(@user.id)
    hash.should eql("0123456789")
  end

end

describe User, "create_reseller_conflines" do
  
  before(:each) do
    Codec.should_receive(:find).twice.with(:all).and_return([])
  end  
  
  it "should destroy old user conflines and geneteare new ones" do
    @user = new_user
    @user.save.should eql(true)
    lambda {
      @user.create_reseller_conflines
    }.should change(Confline, :count).by(63)
    
    lambda {
      @user.create_reseller_conflines
    }.should change(Confline, :count).by(0)
  end
  
end

