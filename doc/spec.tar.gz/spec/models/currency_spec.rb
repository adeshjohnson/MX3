require File.dirname(__FILE__) +'/../spec_helper.rb' 

describe Currency, ".get_by_name" do
  
  it "should call find" do
    Currency.should_receive(:find).with(:first, :conditions => ["name = ?", "LTL"]).and_return(get_mock_currency)
    Currency.get_by_name("LTL")
  end
  
end

describe Currency, ".count_exchange_rate" do

  before(:each) do
    @ltl = get_mock_currency(:exchange_rate => 1.0, :name => "LTL")
    @usd = get_mock_currency(:exchange_rate => 0.37, :name => "USD")
  end
  
  it "should find and count exchange rate" do
    Currency.stub!(:find)
    Currency.should_receive(:find).twice.with(:first, :conditions => ["name = ?", "LTL"]).and_return(@ltl)
    Currency.should_receive(:find).twice.with(:first, :conditions => ["name = ?", "USD"]).and_return(@usd)
    Currency.count_exchange_rate("LTL", "USD").should eql(0.37)
    Currency.count_exchange_rate("USD", "LTL").to_i.should eql(2)
  end
  
  it "should " do
    Currency.should_not_receive(:find)
    Currency.count_exchange_rate(@ltl, @usd).should eql(0.37)
    Currency.count_exchange_rate(@usd, @ltl).to_i.should eql(2)
  end
  
end


