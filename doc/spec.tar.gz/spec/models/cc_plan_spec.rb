require File.dirname(__FILE__) +'/../spec_helper.rb' 

describe CcPlan, ".include_group" do
  before(:each) do
    @mock_group_client_1 = mock_model(CcGroupClient, :cc_client_id => 14, :cc_group_id => 123)
    @mock_group_client_2 = mock_model(CcGroupClient, :cc_client_id => 15, :cc_group_id => 123)
    @mock_client_list = [@mock_group_client_1,@mock_group_client_1 ]
    CcGroupClient.should_receive(:find).with(:all, :conditions => "cc_group_id = 123").and_return(@mock_client_list)
    @mock_plan_client = mock_model(CcPlanClient)
    @mock_plan_client.should_receive(:cc_plan_id=).twice
    @mock_plan_client.should_receive(:cc_client_id=).twice
    @mock_plan_client.should_receive(:save).twice 
    CcPlanClient.should_receive(:new).twice.and_return(@mock_plan_client)
  end
  
  it "should include group of clients into plan clients" do
    @plan = CcPlan.new
    @plan.name = "test"
    @plan.cc_form_id = 1
    @plan.save.should eql(true)
    @plan.include_group(123)
  end
end

describe CcPlan, ".exclude_group" do
  before(:each) do
    @mock_group_client_1 = mock_model(CcGroupClient, :cc_client_id => 14, :cc_group_id => 123)
    @mock_group_client_2 = mock_model(CcGroupClient, :cc_client_id => 15, :cc_group_id => 123)
    @mock_client_list = [@mock_group_client_1,@mock_group_client_1 ]
    CcGroupClient.should_receive(:find).with(:all, :conditions => "cc_group_id = 123").and_return(@mock_client_list)
    @mock_plan_client = mock_model(CcPlanClient)
    @mock_plan_client.should_receive(:destroy).twice.and_return(true)
    CcPlanClient.should_receive(:find).twice.and_return(@mock_plan_client)
  end
  
  it "should exclude group of clients from plan clients" do
    @plan = CcPlan.new
    @plan.name = "test"
    @plan.cc_form_id = 1
    @plan.save.should eql(true)
    @plan.exclude_group(123)
  end
end

