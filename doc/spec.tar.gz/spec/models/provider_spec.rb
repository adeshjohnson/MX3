require File.dirname(__FILE__) +'/../spec_helper.rb' 
describe Provider, ".check_username_uniqueness" do
  
end

