require File.dirname(__FILE__) +'/../spec_helper.rb' 
describe CcGroup, ".check_username_uniqueness" do
  before(:each) do
    @group = CcGroup.new()
    @group.name = "spec_test_group"
    @group.save.should eql(true)
    @cl = CcGroupClient.new
    
  end
  
  it "should deny if entry with such username exists" do
    
  end
end

