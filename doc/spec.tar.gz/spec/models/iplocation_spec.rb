require File.dirname(__FILE__) +'/../spec_helper.rb' 
# 
describe Iplocation, ".get_location_from_hostip" do
  before(:each) do
    @ip = "64.233.187.99"    
    response_body = File.read(RAILS_ROOT + "/spec/fixtures/ip_locations/host_ip_#{@ip.gsub('.','_')}.html")
    @result = mock_model(Net::HTTPOK, :body=> response_body )  
  end
  
  it "should get correct data" do    
    Net::HTTP.should_receive(:get_response).once.with("api.hostip.info", "/get_html.php?ip=#{@ip}&position=true").and_return(@result)
    @ip_location = Iplocation.new         
    @ip_location = Iplocation.get_location_from_hostip(@ip, @ip_location)
    @ip_location.ip.should eql(@ip)
    @ip_location.longitude.should eql(-122.026)
    @ip_location.latitude.should eql(37.3857)
    @ip_location.city.should eql("Sunnyvale, Ca")
    @ip_location.country.should eql("United States")
  end  
  
  it "should return object unchanged if IP is bad" do
    Net::HTTP.should_receive(:get_response).exactly(0).with("api.hostip.info", "/get_html.php?ip=#{@ip}&position=true")  
    @ip_location = Iplocation.new()
    @tmp_ip = @ip_location
    @ip_location = Iplocation.get_location_from_hostip("fake_ip", @ip_location)
    @ip_location.should be_equal(@tmp_ip)  
  end
  
  it "should not die on exception" do
    Net::HTTP.should_receive(:get_response).once.with("api.hostip.info", "/get_html.php?ip=#{@ip}&position=true").and_raise(ActionView::TemplateError)
    @ip_location = Iplocation.new()
    @ip_location = Iplocation.get_location_from_hostip(@ip, @ip_location)
    @ip_location.longitude.should eql(0.0) 
    @ip_location.ip.should eql(@ip)
  end
end




describe Iplocation, ".get_location_from_whatismyipaddress" do
  before(:each) do
    @ip = "64.233.187.99"    
    @url = URI.parse("http://whatismyipaddress.com/staticpages/index.php/lookup-results")
    @post_data = {"LOOKUPADDRESS" => "#{@ip}","Lookup+IP+Address"=>	"Lookup+IP+Address"}
    @response_body = File.read(RAILS_ROOT + "/spec/fixtures/ip_locations/whatismyipaddress_#{@ip.gsub('.','_')}.html")
    @result = mock_model(Net::HTTPOK, :body=> @response_body )  
    @http = mock_model(Net::HTTP, :request =>@result)
    @http_request = mock_model(Net::HTTP, :start=>@http)
  end
  
  it "should get correct data" do 
    @result.should_receive(:body).and_return(@response_body)
    @http.should_receive(:request).and_return(@result) 
    Net::HTTP.should_receive(:new).and_return(@http_request)
    @ip_location = Iplocation.new()
    @ip_location = Iplocation.get_location_from_whatismyipaddress(@ip, @ip_location)
    @ip_location.ip.should eql(@ip)
    @ip_location.longitude.should eql(-122.0574)
    @ip_location.latitude.should eql(37.4192)
    @ip_location.city.should eql("Mountain View")
    @ip_location.country.should eql("United Fake States")
  end
  
  it "should return object unchanged if IP is bad" do 
    Net::HTTP.should_receive(:new).exactly(0).and_return(@http_request)
    @ip_location = Iplocation.new()
    @tmp_ip = @ip_location
    @ip_location = Iplocation.get_location_from_whatismyipaddress("fake_ip", @ip_location)
    @ip_location.should equal(@tmp_ip)  
  end
  
  it "should not die on exception" do
    Net::HTTP.should_receive(:new).and_raise(ActionView::TemplateError)
    @ip_location = Iplocation.new()
    @ip_location = Iplocation.get_location_from_whatismyipaddress(@ip, @ip_location)
    @ip_location.longitude.should eql(0.0) 
    @ip_location.ip.should eql(@ip)
  end
  
end


describe Iplocation, ".get_location_from_ip_address" do
  
  before(:each) do
    @ip = "64.233.187.99"
    @url = URI.parse("http://www.ip-adress.com/ipaddresstolocation/")
    @response_body = File.read(RAILS_ROOT + "/spec/fixtures/ip_locations/ip_address_#{@ip.gsub('.','_')}.html")
    @result = mock_model(Net::HTTPOK, :body=> @response_body )  
  end
  
  it "should get correct data" do
    Net::HTTP.should_receive(:post_form).once.with(@url, {"QRY" => @ip.to_s}).and_return(@result)
    @ip_location = Iplocation.new()
    @ip_location = Iplocation.get_location_from_ip_address(@ip, @ip_location)
    @ip_location.ip.should eql(@ip)
    @ip_location.longitude.should eql(-122.0574)
    @ip_location.latitude.should eql(37.4192)
    @ip_location.city.should eql("Mountain View")
    @ip_location.country.should eql("United Fake States")
  end
    
  it "should return object unchanged if IP is bad" do 
    Net::HTTP.should_receive(:post_form).exactly(0).with(@url, {"QRY" => @ip.to_s}).and_return(@result)
    @ip_location = Iplocation.new()
    @tmp_ip = @ip_location
    @ip_location = Iplocation.get_location_from_ip_address("fake_ip", @ip_location)
    @ip_location.should equal(@tmp_ip)  
  end
  
  it "should not die on exception" do
    Net::HTTP.should_receive(:post_form).once.with(@url, {"QRY" => @ip.to_s}).and_raise(ActionView::TemplateError)
    @ip_location = Iplocation.new()
    @ip_location = Iplocation.get_location_from_ip_address(@ip, @ip_location)
    @ip_location.longitude.should eql(0.0) 
    @ip_location.ip.should eql(@ip)
  end
end

describe Iplocation, ".get_location_from_google_geo" do
  before(:each) do
    @ip_location = Iplocation.new()          
    @result_bad = mock_model(Net::HTTPOK, :body=> "602,0,0,0" )    
  end

  it "should return unchanged loc if location was unavailable" do   
    tmp_loc = @ip_location      
    dst = ""
    dir = ""
    ip = "123"
    address = dir+" "+dst
      url = URI.parse("http://maps.google.com/maps/geo?q=#{address.gsub(" ", "+")}&output=csv&key=#{ApiKey.get}")
      url2 = URI.parse("http://maps.google.com/maps/geo?q=#{dir.gsub(" ", "+")}&output=csv&key=#{ApiKey.get}")
    Net::HTTP.should_receive(:get_response).exactly(0).with(url)
    Net::HTTP.should_receive(:get_response).exactly(0).with(url2)      
    @ip_location = Iplocation.get_location_from_google_geo("", "", @ip_location, "123")
    @ip_location.should be_equal(tmp_loc)        
  end

  it "should receive correct data form google when dst and dir are present" do
    dst = "Maringa"
    dir = "Brazil"
    ip = "123"
    @response_body = File.read(RAILS_ROOT + "/spec/fixtures/ip_locations/google_geo_#{dir.downcase}_#{dst.downcase}.csv")
    @result = mock_model(Net::HTTPOK, :body=> @response_body )
    address = dir+" "+dst
      url = URI.parse("http://maps.google.com/maps/geo?q=#{address.gsub(" ", "+")}&output=csv&key=#{ApiKey.get}")
    Net::HTTP.should_receive(:get_response).once.with(url).and_return(@result)
    @ip_location = Iplocation.get_location_from_google_geo(dst, dir, @ip_location, ip )
    @ip_location.longitude.should eql(-51.937505)
    @ip_location.latitude.should eql(-23.427304)
    @ip_location.city.should eql(dst)
    @ip_location.country.should eql(dir)
    @ip_location.ip.should eql(ip)
  end

  it "should receive correct data from google when dir is present" do
    dst = "omnitel"
    dir = "Brazil"
    ip = "123"
    @response_body = File.read(RAILS_ROOT + "/spec/fixtures/ip_locations/google_geo_#{dir.downcase}.csv")
    @result = mock_model(Net::HTTPOK, :body=> @response_body )
    address = dir+" "+dst
      url = URI.parse("http://maps.google.com/maps/geo?q=#{address.gsub(" ", "+")}&output=csv&key=#{ApiKey.get}")
      url2 = URI.parse("http://maps.google.com/maps/geo?q=#{dir.gsub(" ", "+")}&output=csv&key=#{ApiKey.get}")
    Net::HTTP.should_receive(:get_response).once.with(url).and_return(@result_bad)
    Net::HTTP.should_receive(:get_response).once.with(url2).and_return(@result)
    @ip_location = Iplocation.get_location_from_google_geo(dst, dir, @ip_location, "123" )

    @ip_location.longitude.should eql(-51.92528)
    @ip_location.latitude.should eql(-14.235004)
    @ip_location.city.should eql("")
    @ip_location.country.should eql("Brazil")
    @ip_location.ip.should eql(ip) 
  end

  it "should return fake data for Georgia" do
    dst = "omnitel"
    dir = "Brazil"
    ip = "123"
    @response_body = File.read(RAILS_ROOT + "/spec/fixtures/ip_locations/google_geo_#{dir.downcase}.csv")
    @result = mock_model(Net::HTTPOK, :body=> @response_body )
    dst = ""
    dir = "Georgia"
      url2 = URI.parse("http://maps.google.com/maps/geo?q=#{dir.gsub(" ", "+")}&output=csv&key=#{ApiKey.get}")
    Net::HTTP.should_receive(:get_response).once.with(url2).and_return(@result)  
    @ip_location = Iplocation.get_location_from_google_geo(dst, dir, @ip_location, "123" )
    @ip_location.longitude.should eql(44.0)
    @ip_location.latitude.should eql(42.0)
    @ip_location.city.should eql("")
    @ip_location.country.should eql("Georgia")
    @ip_location.ip.should eql(ip) 
  end
  it "should not die on exception" do    
    dst = ""
    dir = "Georgia"
    url2 = URI.parse("http://maps.google.com/maps/geo?q=#{dir.gsub(" ", "+")}&output=csv&key=#{ApiKey.get}")
    Net::HTTP.should_receive(:get_response).once.with(url2).and_raise(ActionView::TemplateError)
    @ip_location = Iplocation.new()
    @ip_location = Iplocation.get_location_from_google_geo(dst, dir, @ip_location, "123" )
    @ip_location.longitude.should eql(0.0) 
    @ip_location.ip.should eql("123")
    end
end

describe Iplocation, ".get_location" do
  
  before(:each) do
    @ip = "64.233.187.99"    
    @location = Iplocation.new
    @location.latitude = 37.3857
    @location.longitude = -122.026
    @location.ip = @ip    
    @location.city= "Sunnyvale, Ca"
    @location.country = "United States"
    @location_bad = Iplocation.new
    @location_bad.longitude = 0
    @location_bad.latitude = 0
    
  end
  
  it "should store data in database" do
    Iplocation.should_receive(:get_location_from_hostip).once.and_return(@location)
    Iplocation.should_receive(:get_location_from_whatismyipaddress).exactly(0)
    Iplocation.should_receive(:get_location_from_ip_address).exactly(0)
    Iplocation.should_receive(:get_location_from_google_geo).exactly(0)
    lambda {
      @ip_location = Iplocation.get_location(@ip)
    }.should change(Iplocation, :count)
    lambda {
      @ip_location = Iplocation.get_location(@ip)
    }.should_not change(Iplocation, :count)
  end
  
  it "should return 0,0 if ip is empty" do
    @ip_location = Iplocation.get_location("")
    @ip_location.longitude.should eql(0.0)
    @ip_location.latitude.should eql(0.0)
  end
  
  it "should receive data from 2'nd source" do
    Iplocation.should_receive(:get_location_from_hostip).once.and_return(@location_bad)
    Iplocation.should_receive(:get_location_from_whatismyipaddress).once.and_return(@location)
    Iplocation.should_receive(:get_location_from_ip_address).exactly(0)
    Iplocation.should_receive(:get_location_from_google_geo).exactly(0)
    @ip_location = Iplocation.get_location(@ip)
  end
  
  it "should receive data from 3'rd source" do
    Iplocation.should_receive(:get_location_from_hostip).once.and_return(@location_bad)
    Iplocation.should_receive(:get_location_from_whatismyipaddress).once.and_return(@location_bad)
    Iplocation.should_receive(:get_location_from_ip_address).once.and_return(@location)
    Iplocation.should_receive(:get_location_from_google_geo).exactly(0)
    @ip_location = Iplocation.get_location(@ip)
  end
  
  it "should receive data from google" do
    @fake_dir = mock_model(Direction, :name => "Brazil")
    @fake_dst = mock_model(Destination, :name => "Maringa", :direction=>@fake_dir)
    Iplocation.should_receive(:get_location_from_hostip).exactly(0)
    Iplocation.should_receive(:get_location_from_whatismyipaddress).exactly(0)
    Iplocation.should_receive(:get_location_from_ip_address).exactly(0)
    Iplocation.should_receive(:get_location_from_google_geo).exactly(1).and_return(@location)
    Destination.should_receive(:find).once.and_return(@fake_dst)
    @ip_location = Iplocation.get_location("123", 1)
  end
end

describe Iplocation, ".check_IP" do
  
  it "should pass correct ip" do
    Iplocation.check_ip("192.168.0.1").should be_true
  end
  
  it "should deny wrong ip" do
    Iplocation.check_ip("fake_ip").should be_false
    Iplocation.check_ip("-1.2.3.4").should be_false
    Iplocation.check_ip("1.2.3.4a").should be_false
    Iplocation.check_ip("1212.21.13.4").should be_false
    Iplocation.check_ip("").should be_false
  end
end

describe Iplocation do
  before(:each) do   
    @ip_location = Iplocation.new   
    @ip_location.ip = "123.123.123.123"
    @ip_location.longitude = "0"
    @ip_location.latitude = "0"
  end

  it "should be valid" do
    @ip_location.should be_valid
  end

  it "should accept valid ip" do
    @ip_location.check_ip.should be_true
  end
  
  it "should not accept invalid ip" do    
    @ip_location.ip = "test"
    @ip_location.check_ip.should_not be_true
  end    
end

