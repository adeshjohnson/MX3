require File.dirname(__FILE__) +'/../spec_helper.rb' 

describe API, ".check_params_with_key" do
  before(:each) do
    Confline.should_receive(:get_value).with("API_Secret_Key").and_return("ABCD")
    @hash = {:user_id => "123", :hash=> "20e31b46cbee9b63ca6fcc19c5ed5c8407eedffb" }
    @hash2 = {:user_id => "123",:period_start => "100", :period_end => "200",:direction => "incoming",:calltype => "no_answer",:device => "123",:hash=> "5b03f1c689ed67259933624d6830a84d9d982582"}
  end

  it "should show if hash is correct" do
    test, values = API.check_params_with_key(@hash)
    test.should eql(true)
    values[:user_id].should eql(123)
  end
  
  it "should show if hash is correct" do
    test, values = API.check_params_with_key(@hash.merge({:user_id => "124"}))
    test.should eql(false)
    values[:user_id].should eql(124)
  end
  
  it "should show correct hash with full data" do
    test, values = API.check_params_with_key(@hash2)
    MorLog.my_debug(values)
    test.should eql(true)
    values[:user_id].should eql(123)
    values[:period_start].should eql(100)
    values[:period_end].should eql(200)
    values[:direction].should eql("incoming")
    values[:calltype].should eql("no answer")
    values[:device].should eql("123")
  end
end