require File.dirname(__FILE__) +'/../spec_helper.rb' 
describe Action, ".add_action" do

  it "should add action onto actions table" do
    User.stub!(:find => true)
    lambda {
      Action.add_action(0, 'login').class.to_s.should eql("Action")
    }.should change(Action, :count)
  end
  
  it "should not add onto actions when user id is not present or invalid" do
    lambda {
      Action.add_action(-1, 'login').should eql(false)
      Action.add_action(nil, 'login').should eql(false)
    }.should_not change(Action, :count)
  end
  
  it "should add correct Time" do
    User.stub!(:find => true)
    time = Time.now
    action = Action.add_action(0, 'login')
    action.date.should be > time
    action.action.should eql('login')
    action.user_id.should eql(0)
  end
end

describe Action, ".add_error" do

  it "should add error action onto actions table" do    
  end  
  
  it "should add correct Time" do 
    User.stub!(:find => true)      
    time = Time.now
    action = Action.add_error(0, 'error_on_login')
    action.date.should be > time    
    action.action.should eql("error")
    action.data.should eql('error_on_login')
    action.user_id.should eql(0)
  end  
  
  it "should add action onto actions table" do 
    User.stub!(:find => true)   
    lambda {
      Action.add_error(0, 'login').class.to_s.should eql("Action")
    }.should change(Action, :count)
  end
  
  it "should not add onto actions when user id is not present or invalid" do
    lambda {
      Action.add_error(-1, 'login').should eql(false)
      Action.add_error(nil, 'login').should eql(false)
    }.should_not change(Action, :count)
  end
end


