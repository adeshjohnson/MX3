require File.dirname(__FILE__) +'/../spec_helper.rb' 

describe Locationrule, ".check_cut_add" do
end

