require File.dirname(__FILE__) +'/../spec_helper.rb' 

describe CcFormFieldData, ".update_form_field_data" do
  
  before(:each) do
    @mock_plan = mock_model(CcPlan, :id => 22, :cc_form_id => 88)
    @mock_task = mock_model(CcTask, :id => 12, :cc_plan => @mock_plan)
  end
  
  it "should update data fields" do  
    lambda{
      CcFormFieldData.update_form_field_data({"field5" => "Test", "field6" => "2"}, "12" ,@mock_task, 0)
    }.should change(CcFormFieldData, :count).by(2)
    
    lambda{
      CcFormFieldData.update_form_field_data({"field5" => "Test", "field6" => "2"}, "12" ,@mock_task, 0)
    }.should_not change(CcFormFieldData, :count)
    
    lambda{
      CcFormFieldData.update_form_field_data({"field5" => "Test"}, "12" ,@mock_task, 0)
    }.should change(CcFormFieldData, :count).by(-1)
  end
  
end
