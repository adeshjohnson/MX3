#require File.dirname(__FILE__) +'/../spec_helper.rb' 
#describe CcClient, ".get_clients_with_group" do
# 
#  def create_client
#    @client = CcClient.new
#    @client.first_name = "Jonas"
#    @client.last_name = "Jontaitis"
#    @client.vat_percent = "18"
#    @client.user_id = "-1"
#    @client.save.should eql(true)
#    @client
#  end
#  
#  before(:each) do
#    @client = create_client
#    @group = CcGroup.new
#    @group.name = "Test_Group"
#    @group.save.should eql(true)
#    @cg = CcGroupClient.new
#    @cg.cc_client = @client
#    @cg.cc_group = @group
#    @cg.save.should eql(true)
#  end
#  
#  it "should return correct data" do
#    cli = CcClient.get_clients_with_group(@group.id)[0]
#    cli["first_name"].should eql("Jonas")
#    cli["group_id"].should eql(@group.id.to_s)
#  end
#end
#
#describe CcClient, ".whit_main_contact" do
#  
#  before(:each) do
#     @mock_client = mock_model(CcClient, :id =>3, :user_id=>"3", :main_contact_id =>"3")
#     @mock_contact = mock_model(CcContact, :id =>3, :user_id=>"3", :email =>"bla@bla.com")
#   
#  end
#  
#  it "should return correct data" do
#    cli = CcClient.whit_main_contact(3)[0]
#    cli["id"].should eql("3")
#    cli["main_contact_id"].should eql(@mock_contact.id.to_s)
#    cli["m_mail"].should eql(@mock_contact.email.to_s)
#  end
#end


#describe CcClient, ".whit_email" do
#  
#  before(:each) do
#     @mock_client = mock_model(CcClient, :id =>3, :user_id=>"3", :main_contact_id =>"3")
#     @mock_contact = mock_model(CcContact, :id =>3, :user_id=>"3", :email =>"bla@bla.com")
#   
#  end
#  
#  it "should return correct data" do
#    cli = CcClient.whit_email(3)[0]
#    cli["id"].should eql("3")
#    cli["name"].should eql(@mock_client.name.to_s)
#    cli["mail"].should eql(@mock_contact.email.to_s)
#  end
#end
#
#describe CcClient, ".get_all_fields2" do
#  
#  before(:each) do
#     @mock_client = mock_model(CcClient, :id =>3, :user_id=>"3", :main_contact_id =>"3")
#     @mock_contact = mock_model(CcContact, :id =>3, :user_id=>"3", :email =>"bla@bla.com")
#     @mock_field = mock_model(CcClientField, :id=>3, :name=>"as", :fieldtype=>"Teaxtarea", :default_value=>"3", :inner_field_id =>0 )
#     @mock_field_data = mock_model(CcClientFieldData, :id=>3, :cc_client_field_id=>"3", :value=>"3", :cc_client_id =>"3" )
#  end
#  
#  it "should return correct data" do
#    CcClientField.should_receive(:find_by_sql).and_return([[cdid="3", name="as", fieldtype="Teaxtarea", default_value="3", inner_field_id =0 ]])
#    cli = CcClient.get_all_fields2[0]
#    cli["cdid"].should eql("3")
#    cli["value"].should eql(@mock_field_data.value.to_s)
#    cli["cc_client_id"].should eql(@mock_field_data.cc_client_id.to_s)
#     cli["default_value"].should eql(@mock_field.default_value.to_s)
#  end
#end

