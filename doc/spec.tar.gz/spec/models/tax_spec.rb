require File.dirname(__FILE__) +'/../spec_helper.rb' 
require 'tax'

describe Tax, ".get_tax_count" do

  before(:each) do
    tax ={
    :id=>374, 
    :total_tax_name=>"Viso mokesciu", 
    
    :tax2_enabled=>"0", 
    :tax3_enabled=>"1", 
    :tax4_enabled=>"0", 
    
    :tax1_name=>"Viso mokesciu", 
    :tax2_name=>"GPM", 
    :tax3_name=>"Siaip", 
    :tax4_name=>"", 
    
    :tax1_value=>"12", 
    :tax2_value=>"33", 
    :tax3_value=>"33",
    :tax4_value=>"0"
    }
    @tax = Tax.new(tax)
  end
  
  it "should parse, count and sum  taxes" do
    @tax.get_tax_count.should eql(2)
    @tax.get_tax_sum.should eql(45.0)
    @tax.to_active_array.should eql([["Viso mokesciu", 12.0], ["Siaip", 33.0]])
    @tax.tax3_enabled = 0
    @tax.get_tax_count.should eql(1)
    @tax.get_tax_sum.should eql(12.0)
    @tax.to_active_array.should eql([["Viso mokesciu", 12.0]])
    @tax.tax2_enabled = 1
    @tax.tax3_enabled = 1
    @tax.tax4_enabled = 1
    @tax.get_tax_count.should eql(4)
    @tax.get_tax_sum.should eql(78.0)
    @tax.to_active_array.should eql([["Viso mokesciu", 12.0], ["GPM", 33.0], ["Siaip", 33.0], ["", 0.0]])
  end
  
  it "should mock tax1_enabled" do
    @tax.tax1_enabled
    @tax.tax1_enabled= 123
  end
  
  it "should be corrected before save when total_tax_name is set" do
    @tax.tax1_name = ""
    Confline.should_receive(:get_value).with("Total_tax_name").and_return("Total_tax")
    @tax.before_save
    @tax.tax1_name.should eql("Total_tax")
  end
  
  it "should be corrected before save when total_tax_name is blank" do
    @tax.tax1_name = ""
    Confline.should_receive(:get_value).with("Total_tax_name").and_return("")
    @tax.before_save
    @tax.tax1_name.should eql("Tax")
  end  
  
  it "should receive default values" do
    Confline.stub!(:get_value)
    Confline.stub!(:get_value2)
  end
end


