require File.dirname(__FILE__) +'/../spec_helper.rb' 

describe Call, ".get_calls_by_calldate" do
  
  def create_call(calldate, disposition)
    @call = Call.new
    @call.calldate = calldate
    @call.disposition = disposition
    @call.clid = 100
    @call.src = 100
    @call.dst = 100
    @call.dcontext = 100
    @call.channel = 100
    @call.dstchannel = 100
    @call.lastapp = 100
    @call.lastdata = 100
    @call.billsec = 100
    @call.amaflags = 100
    @call.accountcode = 100
    @call.uniqueid = 100
    @call.userfield = 100
    @call.src_device_id = 100
    @call.dst_device_id = 100
    @call.processed = 100
    @call.did_price = 100
    @call.duration = 100
    @call.save.should eql(true)
    @call
  end
  
  before(:each) do
     @call = create_call("2001-01-01 01:01:34", "ANSWERED" )
     @call2 = create_call("2001-01-01 01:01:34", "NO ANSWERED" )
#    @moc_data1 = mock_model(Time, :Y=>"2001", :m=>"01", :d=>"01", :H=>"01", :M=>"02", :S=>"02")
#    
#    @mock_cal_ansv =  mock_model(Call , :id =>4, :calldate=>@moc_data1 , :disposition=>"ANSWERED", :duration => "100", :c => 1)
#    @mock_cal_noansv =  mock_model(Call , :id =>5, :calldate=>@moc_data1, :disposition=>"NO ANSWERED", :duration => "100", :c=>1)
#    
  end
  
  it "should find ANSWERED calls" do
    call = Call.get_calls_by_calldate("2001-01-01 01:01:01","2001-01-01 10:21:21", "ANSWERED" )[0]
    call["c"].should eql("1")
    call["calldate"].should eql(@call.calldate)
  end
  
  it "should find ALL calls" do
    call = Call.get_calls_by_calldate("2001-01-01 01:01:01","2001-01-01 10:21:21")
    call[0]["c"].should eql("4")
    call[0]["calldate"].should eql(@call.calldate)
  end
end

