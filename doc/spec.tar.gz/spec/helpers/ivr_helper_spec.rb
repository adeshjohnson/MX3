require File.dirname(__FILE__) +'/../spec_helper.rb' 
include IvrHelper
describe IvrHelper, ".make_tooltip" do
  it "should create propper tooltip information" do
    block = get_mock_ivr_block(:ivr_extensions=> [])
    extensions = block.ivr_extensions
    actions = block.ivr_actions
    tip = make_tooltip(block, actions, extensions)
    tip.scan(/#{_("Timeout_Digits")}/).size.should eql(1)
  end 
end

describe IvrHelper, ".proper_params" do
  it "should show error message on empty input" do
    proper_params("").should eql("<b>Error in command. Contact developers.</b>")
  end
  
  it "should give proper params with 'Debug'" do
    @action_de = mock("action")
    @action_de.stub!(:name).and_return("Debug")
    @action_de.stub!(:class).and_return("IvrAction")
    @action_de.stub!(:data1).and_return("Testas")
    @action_de.stub!(:id).and_return("5")      
    proper_params(@action_de).should eql("<input class=\"input\" id=\"action5\" maxlength=\"255\" name=\"action5\" size=\"30\" type=\"text\" value=\"Testas\" /><script type=\"text/javascript\">\n//<![CDATA[\nnew Form.Element.Observer('action5', 0.5, function(element, value) {new Ajax.Request('/ivr/update_data1/5', {asynchronous:true, evalScripts:true, onComplete:function(request){Element.hide('spinner');}, onLoading:function(request){Element.show('spinner');}, parameters:value})})\n//]]>\n</script>")
  end
  
  it "should give proper params with 'Transfer To'" do
    did1 = mock('did1')
    did1.stub!(:did).and_return("999")
    did2 = mock('did2')
    did2.stub!(:did).and_return("123")
    did_array = [did1, did2]
    
    ivr1 = mock('ivr1')
    ivr1.stub!("id").and_return(1)
    ivr1.stub!("name").and_return('First')
    ivr2 = mock('ivr2')
    ivr2.stub!("id").and_return(2)
    ivr2.stub!("name").and_return('Second')
    ivr_array = [ivr1,ivr2  ]
    
    block1 = mock('block1')
    block1.stub!(:id).and_return(1)
    block1.stub!(:name).and_return("First_block")
    block2 = mock('block2')
    block2.stub!(:id).and_return(2)
    block2.stub!(:name).and_return("Second_block")
    block_list = [block1, block2]
    
    ivr = mock('ivr')
    ivr.stub!(:ivr_blocks).and_return(block_list)
    
    ivr_block = mock("ivr_block")
    ivr_block.stub!(:ivr).and_return(ivr) 
    
    @action_tr = mock("action")
    @action_tr.stub!(:name).and_return("Transfer To")
    @action_tr.stub!(:class).and_return("IvrAction")
    @action_tr.stub!(:data1).and_return("DID")
    @action_tr.stub!(:data2).and_return("1")
    @action_tr.stub!(:id).and_return("5")     
    Did.should_receive(:find).and_return(did_array)
    proper_params(@action_tr).should eql("<div id = 'goto_params5'><select id ='action5' name='5'><option value= 'IVR'  >IVR</option>\n<option value= 'DID' selected >DID</option>\n<option value= 'Device'  >Device</option>\n<option value= 'Block'  >Block</option>\n</select><select id ='action_param5' name='5'><option value='999'  >999</option>\n<option value='123'  >123</option>\n</select></div><script type=\"text/javascript\">\n//<![CDATA[\nnew Form.Element.Observer('action_param5', 0.5, function(element, value) {new Ajax.Request('/ivr/update_data2/5', {asynchronous:true, evalScripts:true, onComplete:function(request){Element.hide('spinner');}, onLoading:function(request){Element.show('spinner');}, parameters:value})})\n//]]>\n</script><script type=\"text/javascript\">\n//<![CDATA[\nnew Form.Element.Observer('action5', 0.5, function(element, value) {new Ajax.Updater('goto_params5', '/ivr/update_data1/5', {asynchronous:true, evalScripts:true, onComplete:function(request){Element.hide('spinner');}, onLoading:function(request){Element.show('spinner');}, parameters:value})})\n//]]>\n</script>")
    @action_tr.stub!(:data1).and_return("IVR")
    Ivr.should_receive(:find).and_return(ivr_array)
    proper_params(@action_tr).should eql("<div id = 'goto_params5'><select id ='action5' name='5'><option value= 'IVR' selected >IVR</option>\n<option value= 'DID'  >DID</option>\n<option value= 'Device'  >Device</option>\n<option value= 'Block'  >Block</option>\n</select><select id ='action_param5' name='5'><option value='1' selected >First</option>\n<option value='2'  >Second</option>\n</select></div><script type=\"text/javascript\">\n//<![CDATA[\nnew Form.Element.Observer('action_param5', 0.5, function(element, value) {new Ajax.Request('/ivr/update_data2/5', {asynchronous:true, evalScripts:true, onComplete:function(request){Element.hide('spinner');}, onLoading:function(request){Element.show('spinner');}, parameters:value})})\n//]]>\n</script><script type=\"text/javascript\">\n//<![CDATA[\nnew Form.Element.Observer('action5', 0.5, function(element, value) {new Ajax.Updater('goto_params5', '/ivr/update_data1/5', {asynchronous:true, evalScripts:true, onComplete:function(request){Element.hide('spinner');}, onLoading:function(request){Element.show('spinner');}, parameters:value})})\n//]]>\n</script>")
    @action_tr.stub!(:data1).and_return("Block")
    @action_tr.should_receive(:ivr_block).and_return(ivr_block)
    proper_params(@action_tr).should eql("<div id = 'goto_params5'><select id ='action5' name='5'><option value= 'IVR'  >IVR</option>\n<option value= 'DID'  >DID</option>\n<option value= 'Device'  >Device</option>\n<option value= 'Block' selected >Block</option>\n</select><select id ='action_param5' name='5'><option value='1' selected >First_block</option>\n<option value='2'  >Second_block</option>\n</select></div><script type=\"text/javascript\">\n//<![CDATA[\nnew Form.Element.Observer('action_param5', 0.5, function(element, value) {new Ajax.Request('/ivr/update_data2/5', {asynchronous:true, evalScripts:true, onComplete:function(request){Element.hide('spinner');}, onLoading:function(request){Element.show('spinner');}, parameters:value})})\n//]]>\n</script><script type=\"text/javascript\">\n//<![CDATA[\nnew Form.Element.Observer('action5', 0.5, function(element, value) {new Ajax.Updater('goto_params5', '/ivr/update_data1/5', {asynchronous:true, evalScripts:true, onComplete:function(request){Element.hide('spinner');}, onLoading:function(request){Element.show('spinner');}, parameters:value})})\n//]]>\n</script>")
    @action_tr.stub!(:data1).and_return("Device")
    proper_params(@action_tr).should eql("<div id = 'goto_params5'><select id ='action5' name='5'><option value= 'IVR'  >IVR</option>\n<option value= 'DID'  >DID</option>\n<option value= 'Device' selected >Device</option>\n<option value= 'Block'  >Block</option>\n</select><select id ='action_param5' name='5'></select></div><script type=\"text/javascript\">\n//<![CDATA[\nnew Form.Element.Observer('action_param5', 0.5, function(element, value) {new Ajax.Request('/ivr/update_data2/5', {asynchronous:true, evalScripts:true, onComplete:function(request){Element.hide('spinner');}, onLoading:function(request){Element.show('spinner');}, parameters:value})})\n//]]>\n</script><script type=\"text/javascript\">\n//<![CDATA[\nnew Form.Element.Observer('action5', 0.5, function(element, value) {new Ajax.Updater('goto_params5', '/ivr/update_data1/5', {asynchronous:true, evalScripts:true, onComplete:function(request){Element.hide('spinner');}, onLoading:function(request){Element.show('spinner');}, parameters:value})})\n//]]>\n</script>")
  end
  
  
  it "should give proper params with 'Hangup'" do
    @action_ha = mock("action")
    @action_ha.stub!(:name).and_return("Hangup")
    @action_ha.stub!(:class).and_return("IvrAction")
    @action_ha.stub!(:data1).and_return("Congestion")
    @action_ha.stub!(:id).and_return("5") 
    proper_params(@action_ha).should eql("<select id ='action5' name='5'><option value= 'Busy' >Busy</option>\n<option value= 'Congestion' selected>Congestion</option>\n</select><script type=\"text/javascript\">\n//<![CDATA[\nnew Form.Element.Observer('action5', 0.5, function(element, value) {new Ajax.Request('/ivr/update_data1/5', {asynchronous:true, evalScripts:true, onComplete:function(request){Element.hide('spinner');}, onLoading:function(request){Element.show('spinner');}, parameters:value})})\n//]]>\n</script>")
  end 
  
  it "should give proper params with 'Playback'" do
    @action_pl = mock("action")
    @action_pl.stub!(:name).and_return("Playback")
    @action_pl.stub!(:class).and_return("IvrAction")
    @action_pl.stub!(:data1).and_return("3")
    @action_pl.stub!(:id).and_return("5")   
    proper_params(@action_pl).should eql("<b>"+_("No_SoundFiles_To_Select_From")+"</b>")
    mock_lt = mock("m1")
    mock_lt.stub!(:[]).with("path").and_return("Metallica.wav")
    mock_en = mock("m2")
    mock_en.stub!(:[]).with("path").and_return("Iron_maiden.mp3")
    voice_array =[mock_lt, mock_en]
    IvrSoundFile.should_receive(:file_list).and_return(voice_array)
    proper_params(@action_pl).should eql("<select id ='action5' name='5'><option value= 'Metallica.wav'  >Metallica.wav</option>\n<option value= 'Iron_maiden.mp3'  >Iron_maiden.mp3</option>\n</select><script type=\"text/javascript\">\n//<![CDATA[\nnew Form.Element.Observer('action5', 0.5, function(element, value) {new Ajax.Request('/ivr/update_data1/5', {asynchronous:true, evalScripts:true, onComplete:function(request){Element.hide('spinner');}, onLoading:function(request){Element.show('spinner');}, parameters:value})})\n//]]>\n</script>") 
  end
  
  it "should give propper params with 'Delay'" do    
    @action_de = mock("action")
    @action_de.stub!(:name).and_return("Delay")
    @action_de.stub!(:class).and_return("IvrAction")
    @action_de.stub!(:data1).and_return("3")
    @action_de.stub!(:id).and_return("5")
    proper_params(@action_de).should eql("<input class=\"input\" id=\"action5\" maxlength=\"10\" name=\"action5\" size=\"10\" type=\"text\" value=\"3\" /><script type=\"text/javascript\">\n//<![CDATA[\nnew Form.Element.Observer('action5', 0.5, function(element, value) {new Ajax.Request('/ivr/update_data1/5', {asynchronous:true, evalScripts:true, onComplete:function(request){Element.hide('spinner');}, onLoading:function(request){Element.show('spinner');}, parameters:value})})\n//]]>\n</script>")
  end

  it "should give propper params with 'Change Voice'" do
    @action_cv = mock("action")
    @action_cv.stub!(:name).and_return("Change Voice")
    @action_cv.stub!(:class).and_return("IvrAction")
    @action_cv.stub!(:data1).and_return("en")
    @action_cv.stub!(:id).and_return("5") 
    mock_lt = mock("m1")
    mock_lt.stub!(:voice).and_return("en")
    mock_en = mock("m2")
    mock_en.stub!(:voice).and_return("lt")
    #voice_array =[{voice => "en"},{voice => "lt"}]
    voice_array =[mock_lt, mock_en]
    IvrVoice.should_receive(:find).and_return(voice_array)
    proper_params(@action_cv).should eql("<select id ='action5' name='5'><option value= 'en' selected >en</option>\n<option value= 'lt'  >lt</option>\n</select><script type=\"text/javascript\">\n//<![CDATA[\nnew Form.Element.Observer('action5', 0.5, function(element, value) {new Ajax.Request('/ivr/update_data1/5', {asynchronous:true, evalScripts:true, onComplete:function(request){Element.hide('spinner');}, onLoading:function(request){Element.show('spinner');}, parameters:value})})\n//]]>\n</script>")
  end
  
  it "should return message on empty IvrVoice for 'Change Voice' " do
    @action_cv = mock("action")
    @action_cv.stub!(:name).and_return("Change Voice")
    @action_cv.stub!(:class).and_return("IvrAction")
    @action_cv.stub!(:data1).and_return("en")
    @action_cv.stub!(:id).and_return("5") 
    IvrVoice.should_receive(:find).and_return([])
    proper_params(@action_cv).should eql("<b>" +_("No_Voices_To_Select_From")+"</b>")
  end
  
end

describe IvrHelper, "clear_text" do
  it "should put correct command" do
    clear_text().should eql("document.getElementById('div_space').innerHTML = '';")
  end  
end

describe IvrHelper, "clear_text2" do
  it "should put correct command" do
    clear_text2().should eql("document.getElementById('div_space2').innerHTML = '';")
  end  
end

describe IvrHelper, "check_string_length" do
  it "should return strings without change when short enought" do
    check_string_length("aaa", 3).should eql("aaa")
    check_string_length("aaa", 6).should eql("aaa")
    check_string_length("aaaaa", 3).should_not eql("aaaaa")
  end
  
  it "should change string when it is to long" do
    check_string_length("aaaaa", 4).should eql("a...") 
    check_string_length("aaa", 0).should eql("...")
    check_string_length("aaaa aaaa aaaa aaaa aaaa ", 20).should eql("aaaa aaaa aaaa aa...")
  end 
end
