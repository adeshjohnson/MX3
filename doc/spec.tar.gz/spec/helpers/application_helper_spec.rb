require File.dirname(__FILE__) +'/../spec_helper.rb' 
include ApplicationHelper
describe ApplicationHelper, "nice_src(call)" do
  
  before(:each) do
    @call = mock_model(Call)
    @call.stub!(:clid).and_return("\"Jonas\" (101)")
    @call.stub!(:src).and_return("101")
    
  end
  
  it "should give proper output with session[:show_full_src] = 1" do
    session[:show_full_src] = 1
    nice_src(@call).should eql("101 (Jonas)")
  end
  
  it "should give proper output with session[:show_full_src] = 0" do
    session[:show_full_src] = 0
    nice_src(@call).should eql("101")
  end
end

describe ApplicationHelper, ".nice_number" do
  it "should display correct numbers" do
    Confline.stub!(:get_value).and_return(2)
    nice_number(1).should eql("1.00")
    nice_number(3.1012312).should eql("3.10")
  end
  
  it "should dispay correct numbers" do
    Confline.stub!(:get_value).and_return(6)
    nice_number(1).should eql("1.000000")
    nice_number(3.101231).should eql("3.101231")
  end
  
  it "should cache nice_digits value" do
    Confline.should_receive(:get_value).once.with("Nice_Number_Digits").and_return(2)
    nice_number(1).should eql("1.00")
    nice_number(3.101231).should eql("3.10")
  end
end

describe ApplicationHelper, ".page_select_header" do

  before(:each) do
  end
  
  it "should give nice_device from data" do
    nice_device_from_data("SIP", "101", "101", 0, 0, options = {}).should eql("<img alt=\"Device\" src=\"/images/icons/device.png?1224488259\" title=\"Device\" /> SIP/101")
  end
  
  it "should give nice_device from data if :link=> true  but no :device_id" do
    nice_device_from_data("SIP", "101", "101", 0, 0, options = {:link => true}).should eql("<img alt=\"Device\" src=\"/images/icons/device.png?1224488259\" title=\"Device\" /> SIP/101")
  end
  
  it "should give nice_device_link from data if :link=> true and :device_id " do
    nice_device_from_data("SIP", "101", "101", 0, 0, options = {:link => true, :device_id => 15}).should eql("<a href=\"/devices/device_edit/15\"><img alt=\"Device\" src=\"/images/icons/device.png?1224488259\" title=\"Device\" /> SIP/101</a>")
  end
  
end

describe ApplicationHelper, ".nice_provider_from_data" do
  
  it "should show name" do
    nice_provider_from_data("Provider").should eql("Provider")
  end
  
  it "should show name if no id" do
    nice_provider_from_data("Provider", {:link => true}).should eql("Provider")
  end 
  
  it "should show link" do
      nice_provider_from_data("Provider", {:link => true, :provider_id => 12}).should eql("<a href=\"/providers/edit/12\">Provider</a>")
  end
  
end

describe ApplicationHelper, ".nice_did_from_data" do
  
  it "should show name" do
    nice_did_from_data("Didas").should eql("Didas")
  end
  
  it "should show name if no id" do
    nice_did_from_data("Didas",{:link => true}).should eql("Didas")
  end
  
  it "should show link" do
    nice_did_from_data("Didas", {:link => true, :did_id => 13}).should eql("<a href=\"/dids/edit/13\">Didas</a>")
  end
  
end

describe ApplicationHelper, ".nice_server_from_data" do
  
  it "should show name" do
    nice_server_from_data("Serveris").should eql("Serveris")
  end
  
  it "should show name if no id" do
    nice_server_from_data("Serveris",{:link => true}).should eql("Serveris")
  end
  
  it "should show link" do
    nice_server_from_data("Serveris", {:link => true, :server_id => 14}).should eql("<a href=\"/servers/edit/14\">Serveris</a>")
  end
  
end





