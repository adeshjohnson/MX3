require File.dirname(__FILE__) +'/../../spec_helper.rb'
require 'pdf/wrapper'
include Pdf

describe Pdf::Generate, ".generate_provider_rates_pdf_header" do

  before(:each) do
    @options = {
      #font size
      :fontsize => 6,
      :title_fontsize => 16,
      :title2_fontsize => 10,
      :header_size_add => 1,

      #positions
      :page_pos_1 => 150,
      :page_pos_2 => 70,
      :page_num_pos => 780,
      :header_eleveation => 20,
      :step_size => 15,

      :per_page_1 => 40,
      :per_page_2 => 45,

      :total_items => 100,
      # col possitions
      :col1_x => 40,
      :col2_x => 220,
      :col3_x => 265,
      :col4_x => 310,
      :col5_x => 360,
      :col6_x => 440,
      :col7_x => 490
    }
    @options[:per_page] = @options[:per_page_1]
    @options[:page_pos] = @options[:page_pos_1]
  end

  it "should run without exceptions" do
    require 'pdf/wrapper'
    i = 50
    pdf = PDF::Wrapper.new(:paper => :A4)
    Pdf::Generate.generate_provider_rates_pdf_header(pdf, i, @options)
  end

end


describe Pdf::Generate, ".generate_personal_rates" do

  before(:each) do
    @options = {
    #fontsize
      :title_fontsize => 16,
      :title2_fontsize =>10,
      :fontsize => 5,
      :header_add_size => 2,
      
    #positions Y
      :title_pos => 40,
      :title2_pos => 65,
      :title3_pos => 80,
      :first_page_pos => 155,
      :second_page_pos => 50,
      :page_number_pos => 780,
      :header_elevation => 20,
      :step_size => 15,
    #positions X
      :col1_x => 40,
      :col2_x => 250,      
      :col3_x => 330,
      :col4_x => 410,
    # counts
      :per_page1 => 40,
      :per_page2 => 45,
    }
  end

  it "should run without exceptions" do
    pdf = Pdf::Generate.generate_personal_rates([], get_mock_tariff, 18,get_mock_user, "LTL",@options)
  end

end

describe Pdf::Generate, ".generate_personal_rates_pdf_header" do
  
  before(:each) do
    @options = {
    #fontsize
      :title_fontsize => 16,
      :title2_fontsize =>10,
      :fontsize => 5,
      :header_add_size => 2,
      
    #positions Y
      :title_pos => 40,
      :title2_pos => 65,
      :title3_pos => 80,
      :first_page_pos => 155,
      :second_page_pos => 50,
      :page_number_pos => 780,
      :header_elevation => 20,
      :step_size => 15,
    #positions X
      :col1_x => 40,
      :col2_x => 250,      
      :col3_x => 330,
      :col4_x => 410,
    # counts
      :per_page1 => 40,
      :per_page2 => 45,
    }
    @options[:page_pos] = @options[:first_page_pos]
    @options[:total_pages] = Pdf::Count.pages(0, @options[:per_page1], @options[:per_page2])
    @options[:per_page] = @options[:per_page1]
    @options[:total_items] = 0
  end  
  
  it "should run without exception" do
    i = 50
    pdf = PDF::Wrapper.new(:paper => :A4)
    Pdf::Generate.generate_personal_rates_pdf_header(pdf, i, 18, @options)
  end
  
end
