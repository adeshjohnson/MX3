require File.dirname(__FILE__) +'/../../spec_helper.rb'
include Pdf

describe Pdf, ".pages" do

  before(:each) do
  end

  it "should count pages" do
    Pdf::Count.pages(25, 5, 5).should eql(5)
    Pdf::Count.pages(24, 5, 5).should eql(5)
    Pdf::Count.pages(26, 5, 5).should eql(6)
    Pdf::Count.pages(25, 5, 10).should eql(3)
    Pdf::Count.pages(25, 5, 6).should eql(5)
    Pdf::Count.pages(19, 5, 7).should eql(3)
    Pdf::Count.pages(5, 5).should eql(1)
    Pdf::Count.pages(1, 5).should eql(1)
  end

end
