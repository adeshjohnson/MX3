require File.expand_path(File.dirname(__FILE__) +"/../lib/ruby_extensions")
# This file is copied to ~/spec when you run 'ruby script/generate rspec'
# from the project root directory.
ENV["RAILS_ENV"] = "test"
require File.expand_path(File.dirname(__FILE__) + "/../config/environment")
require 'spec'
require 'spec/rails'

Spec::Runner.configure do |config|
  # If you're not using ActiveRecord you should remove these
  # lines, delete config/database.yml and disable :active_record
  # in your config/boot.rb
  config.use_transactional_fixtures = true
  config.use_instantiated_fixtures  = false
  config.fixture_path = RAILS_ROOT + '/spec/fixtures/'
  # == Fixtures
  #
  # You can declare fixtures for each example_group like this:
  #   describe "...." do
  #     fixtures :table_a, :table_b
  #
  # Alternatively, if you prefer to declare them only once, you can
  # do so right here. Just uncomment the next line and replace the fixture
  # names with your fixtures.
  #
  # config.global_fixtures = :table_a, :table_b
  #
  # If you declare global fixtures, be aware that they will be declared
  # for all of your examples, even those that don't use them.
  #
  # You can also declare which fixtures to use (for example fixtures for test/fixtures):
  #
  # config.fixture_path = RAILS_ROOT + '/spec/fixtures/'
  #
  # == Mock Framework
  #
  # RSpec uses it's own mocking framework by default. If you prefer to
  # use mocha, flexmock or RR, uncomment the appropriate line:
  #
  # config.mock_with :mocha
  # config.mock_with :flexmock
  # config.mock_with :rr
  #
  # == Notes
  #
  # For more information take a look at Spec::Example::Configuration and Spec::Runner
end
class Hash

  ##
  # Filter keys out of a Hash.
  #
  #   { :a => 1, :b => 2, :c => 3 }.except(:a)
  #   => { :b => 2, :c => 3 }

  def except(*keys)
    self.reject { |k,v| keys.include?(k || k.to_sym) }
  end

  ##
  # Override some keys.
  #
  #   { :a => 1, :b => 2, :c => 3 }.with(:a => 4)
  #   => { :a => 4, :b => 2, :c => 3 }

  def with(overrides = {})
    self.merge overrides
  end

  ##
  # Returns a Hash with only the pairs identified by +keys+.
  #
  #   { :a => 1, :b => 2, :c => 3 }.only(:a)
  #   => { :a => 1 }

  def only(*keys)
    self.reject { |k,v| !keys.include?(k || k.to_sym) }
  end

end

=begin rdoc

=end 

def dont_be_so_smart
  flash[:notice].should eql(_('Dont_be_so_smart'))
  response.should redirect_to("http://test.host/callc/main")
end

def default_login_data()
  session[:company] = "Test company"
  session[:owner_id] = 1
  session[:nice_number_digits] = 2
  session[:first_name] = "Fake_name"
  session[:last_name] = "Fake_Last_Name"
  session[:items_per_page] = 50
  session[:lang] = 'en'
  session[:year_from] = '2007'
  session[:month_from] = '01'
  session[:day_from] = '01'
  session[:hour_from] = "00"
  session[:minute_from] = "00"
  session[:year_till] = '2010'
  session[:month_till] = '12'
  session[:day_till] = '31'
  session[:hour_till] = "00"
  session[:minute_till] = "00"
  session[:login] = true
  session[:manager_in_groups] = []
  session[:show_full_src] = 1
  session[:usertype_id] = 1
  session[:vat_percent] = 18
  session[:show_currency] = "LTL"
  session[:default_currency] = "LTL"
  return request
end

def login_as_admin ()
  default_login_data()
  session[:usertype] = "admin"
  session[:user_id] = 0

  return "spec admin"
end

def login_as_user (id = 123)
  default_login_data()
  session[:usertype] = "user"
  session[:user_id] = id
  session[:owner_id] = 0
  RoleRight.stub!(:get_authorization => 1)
  return "spec user"
end

def login_as_accountant (id)
  default_login_data()
  session[:usertype] = "accountant"
  session[:user_id] = id
  RoleRight.stub!(:get_authorization => 1)
  return "spec accountant"
end

def login_as_reseller(id)
  default_login_data()
  session[:usertype] = "reseller"
  session[:user_id] = id
  RoleRight.stub!(:get_authorization => 1)
  return "spec reseller"
end

def session_from_date
  sfd = session[:year_from].to_s + "-" + good_date(session[:month_from].to_s) + "-" + good_date(session[:day_from].to_s)
end

def session_till_date
  sfd = session[:year_till].to_s + "-" + good_date(session[:month_till].to_s) + "-" + good_date(session[:day_till].to_s)
end

def session_from_datetime
  sfd = session[:year_from].to_s + "-" + good_date(session[:month_from].to_s) + "-" + good_date(session[:day_from].to_s) + " " + good_date(session[:hour_from].to_s) + ":" + good_date(session[:minute_from].to_s) + ":00"
end

def session_till_datetime
  sfd = session[:year_till].to_s + "-" + good_date(session[:month_till].to_s) + "-" + good_date(session[:day_till].to_s) + " " + good_date(session[:hour_till].to_s) + ":" + good_date(session[:minute_till].to_s) + ":59"
end

def good_date(dd)
  dd = dd.to_s
  dd = "0" + dd if dd.length<2
  dd
end

def get_mock_user(options = {}, adr_options = {}, dir_options = {}, tax_options = {})
  return mock_model(User, {
    :id => 15,
    :generate_invoice => 1,
    :username => "mock_user",
    :first_name =>"Mock",
    :last_name => "User",
    :clientid => "",
    :language => "",
    :agreement_number => "",
    :vat_percent => "",
    :accounting_number => "",
    :cyberplat_active => 1,
    :generate_invoice => 1,
    :call_limit => 0,
    :balance => 10.01,
    :usertype => "user",
    :credit => -1,
    :postpaid => 1,
    :blocked => 0,
    :hidden => 0,
    :devices => [],
    :primary_device_id => "1",
    :allow_loss_calls => 0,
    :agreement_date => Date.parse("2007-03-01"),
    :vat_number => "",
    :vat_percent => 18,
    :taxation_country => 1,
    :address => get_mock_address(adr_options),
    :address_id => 1,
    :taxation_country => 123,
    :owner_id => 0,
    :block_at => "2009-10-01".to_date,
    :block_at_conditional => 15,
    :block_conditional_use=>1,
    :recording_enabled => 1,
    :recording_forced_enabled => 1,
    :recordings_email => "rec@email.com",
    :recording_hdd_quota => 100,
    :get_hash => "1234567890",
    :invoice_zero_calls => "1",
    :owner_id => 0,
    :acc_group_id => 15,
    :tax => get_mock_tax(tax_options),
    :tax_id => 1,
    :get_tax => get_mock_tax(tax_options),
    :tariff => get_mock_tariff,
    :tariff_id => get_mock_tariff.id,
    :sms_service_active => 1,
    :call_center_agent => 0,
    :manager_in_groups => 0,
    :lcr_id => 12,
    :lcr => get_mock_lcr({:id => 12}),
    :devicegroups => []
  }.merge(options)

  )
end


=begin rdoc
 Returns mock_model of Device
=end

def get_mock_device(options = {}, vm_options ={}, user_options = {})
  return mock_model(Device, {
    :user => get_mock_user(user_options),
    :id => 16,
    :allow=>"all",
    :works_not_logged=>"1",
    :name=>"101",
    :cid_from_dids=>"0",
    :process_sipchaninfo=>"0",
    :regserver=>nil,
    :t38pt_udptl=>"no",
    :istrunk=>"0",
    :fromuser=>nil,
    :nat=>"yes",
    :forward_to=>"0",
    :qualify=>"no",
    :extension=>"1011",
    :regseconds=>Time.at(1199899602),
    :timeout=>"66",
    :promiscredir=>"no",
    :sendrpid=>"no",
    :callgroup=>nil,
    :dtmfmode=>"rfc2833",
    :canreinvite=>"no",
    :deny=>"0.0.0.0/0.0.0.0",
    :port=>"5060",
    :allow_duplicate_calls=>"0",
    :transfer=>"no",
    :username=>"101",
    :accountcode=>"1",
    :ipaddr=>"0.0.0.0",
    :repeat_rtime_every=>"60",
    :tell_time=>"0",
    :tell_balance=>"0",
    :fromdomain=>nil,
    :pickupgroup=>nil,
    :disallow=>"all",
    :device_type=>"SIP",
    :id=>"1",
    :ani=>"0",
    :primary_did_id=>"0",
    :user_id=>"2",
    :voicemail_active=>"0",
    :location_id=>"1",
    :progressinband=>"never",
    :permit=>"0.0.0.0/0.0.0.0",
    :call_limit=>"0",
    :description=>"Test Device #1",
    :devicegroup_id=>nil,
    :fullcontact=>"",
    :context=>"mor",
    :host=>"dynamic",
    :temporary_id=>nil,
    :videosupport=>"no",
    :secret=>"101",
    :tell_rtime_when_left=>"60",
    :pin=>"123",
    :insecure=>nil,
    :trustrpid=>"no",
    :record=>"0",
    :callerid=>"\"1011\" <1011>",
    :recording_to_email => 1,
    :recording_email => "test@email.com",
    :recording_keep => 1,
    :voicemail_box =>get_mock_voicemail_box(vm_options),
    :faststart => "yes",
    :h245tunneling => "no",
    :provider => get_mock_provider,
    :provider_id => 1

  }.merge(options))
end


=begin rdoc
 Return mock_model of Card
=end

def get_mock_card(options = {})
  return mock_model(Card, {
    :number=>"1111111111",
    :cardgroup_id=>"1",
    :daily_charge_paid_till=>nil,
    :first_use=>nil,
    :id=>"1",
    :frozen_balance=>"0",
    :sold=>"1",
    :pin=>"6232",
    :balance=>"10",
    :owner_id => "0",
    :cardgroup => get_mock_cardgroup(:id => 12),
    :callerid => "101",
    :cardgroup_id => 12
  }.merge(options))
end


=begin rdoc

=end

def get_mock_cardgroup(options = {}, tax_options ={})
  return mock_model(Cardgroup, {
    :lcr_id=>"1",
    :lcr => get_mock_lcr,
    :price=>10,
    :name=>"Test",
    :created_at=>"2008-10-21 10:47:18".to_time,
    :tariff_id=>"2",
    :tariff => get_mock_tariff,
    :dialplan_id=>"0",
    :ghost_min_perc=>"100",
    :valid_till=>"2010-10-21 23:59:59".to_time,
    :pin_length=>"4",
    :id=>"1",
    :number_length=>"10",
    :vat_percent=>"0",
    :valid_from=>"2008-10-21 00:00:00".to_time,
    :daily_charge=>"0",
    :setup_fee=>"0",
    :location_id=>"1",
    :description=>"Tets",
    :image=>"example.jpg",
    :owner_id => "0",
    :tax => get_mock_tax(tax_options),
    :tax_id => 1,
    :get_tax => get_mock_tax(tax_options),
    :vat_percent => 19
  }.merge(options))
end

=begin rdoc
 Return mock_model of Address
=end

def get_mock_address(options = {})
  return mock_model(Address, {
    :address=>"test street",
    :city=>"test city",
    :postcode=>"9999",
    :county=>"test county",
    :id=>"1",
    :mob_phone=>"+3706",
    :fax=>"+370fax",
    :phone=>"+370phone",
    :direction_id=>"1",
    :email=>"test@email.com",
    :state=>"test state"
  }.merge(options))
end

=begin rdoc
 Return mock_model of Direction
=end

def get_mock_direction(options = {})
  return mock_model(Direction, {
    :name=>"Lithuania",
    :code=>"LTU",
    :id=>"123"
  }.merge(options))
end

=begin rdoc

=end

def get_mock_currency(options = {})
  return mock_model(Currency, {
    :id=>"3",
    :curr_update=>"1",
    :last_update=>"2008-07-04 15:34:40".to_time,
    :name=>"LTL",
    :curr_edit=>"0",
    :full_name=>"Lit",
    :exchange_rate=>"1.331",
    :active=>"1"
  }.merge(options))
end


=begin rdoc

=end

def get_mock_call(options = {})
  return mock_model(Call, {
    :partner_price=>"0",
    :reseller_billsec=>"0",
    :user_billsec=>"58",
    :src_device_id=>"7",
    :duration=>"62",
    :lastdata=>"H323/99532521014@mera||L(36000000:60000:60000)",
    :uri=>nil,
    :partner_billsec=>"0",
    :user_price=>"0.019333",
    :uniqueid=>"1199483271.2",
    :billsec=>58,
    :dstchannel=>"H323/mera-2",
    :peername=>nil,
    :prefix=>"99532",
    :provider_id=>"2",
    :did_price=>"0.03",
    :lastapp=>"Dial",
    :dcontext=>"mor",
    :localized_dst=>nil,
    :did_inc_price=>"0",
    :server_id=>"1",
    :card_id=>"0",
    :calldate=>"2008-01-04 16:47:51".to_time,
    :reseller_price=>"0",
    :reseller_rate=>"0",
    :accountcode=>"7",
    :src=>"104",
    :clid=>"104",
    :callertype=>"Local",
    :partner_rate=>"0",
    :provider_rate=>"0.01",
    :processed=>"0",
    :disposition=>"ANSWERED",
    :dst=>"99532521014",
    :id=>"19",
    :useragent=>nil,
    :recvip=>nil,
    :user_id=>"2",
    :userfield=>"",
    :t38passthrough=>nil,
    :channel=>"SIP/104-081e5568",
    :sipfrom=>nil,
    :reseller_id=>"0",
    :provider_billsec=>"58",
    :dst_device_id=>"0",
    :did_id=>nil,
    :did_provider_id=>"0",
    :peerip=>nil,
    :partner_id=>"0",
    :user_rate=>"0.02",
    :provider_price=>"0.009667",
    :amaflags=>"3",
    :did_prov_price=>"0",
    :hangupcause=>nil
  }.merge(options))
end

=begin rdoc
 Return mock_model of Callerid
=end

def get_mock_cli(options = {})
  return mock_model(Callerid, {
    :cli=>"100",
    :device_id=>"1",
    :description=>"bla",
    :added_at=>"2008-01-04 16:47:51".to_time,
    :created_at=>"2008-01-03 16:47:51".to_time,
    :banned=>"0",
    :updated_at=>"2008-01-04 16:47:51".to_time,
    :ivr_id=>"0",
    :email_callback=>"0",
    :comment=>"bla bla bla"
  }.merge(options))
end

=begin rdoc
 Return mock_model of Ivr
=end

def get_mock_ivr(options = {})
  return mock_model(Ivr, {
    :name=>"bla",
    :start_block_id=>"1"
  }.merge(options))
end


=begin rdoc

=end

def get_mock_lcr(options = {})
  return mock_model(Lcr, {
    :name=>"Primary",
    :order=>"price",
    :id=>"1"
  }.merge(options))
end


=begin rdoc

=end

def get_mock_tariff(options = {})
  return mock_model(Tariff, {
    :name=>"MERA tariff",
    :owner_id=>"0",
    :id=>"1",
    :currency=>"GEL",
    :purpose=>"provider"
  }.merge(options))
end

=begin rdoc

=end 

def get_mock_rate(options = {})
  return mock_model(Rate, {
    :tariff_id =>"8",
    :destination_id =>"5301",
    :id=>"8",
    :destinationgroup_id=>nil
  }.merge(options))
end

=begin rdoc

=end

def get_mock_location(options = {})
  return mock_model(Location, {
    :name=>"Global",
    :id=>"1"
  }.merge(options))
end


=begin rdoc

=end

def get_mock_destination(options = {})
  return mock_model(Destination, {
    :prefix=>"111",
    :id=>"1",
    :direction_code=>"AFG",
    :subcode=>"FIX",
    :city=>"aaa",
    :state=>"aaa",
    :lata=>"aaa",
    :tier=>"aaa",
    :onc=>"aaa",
    :destinationgroup_id=>"1"
  }.merge(options))
end


def get_mock_provider(options = {})
  return mock_model(Provider, {
    :id=>"1",
    :name=>"111",
    :tech=>"SIP",
    :channel=>"g0",
    :login=>"aaa",
    :password=>"aaa",
    :server_ip=>"127.0.0.1",
    :port=>"5060",
    :priority=>"1",
    :quality=>"1",
    :tariff_id=>"1",
    :cut_a=>"0",
    :cuy_b=>"0",
    :add_a=>"1",
    :add_b=>"1",
    :device_id=>"1",
    :ani=>"0",
    :timeout=>"60",
    :call_limit=>"0",
    :interpret_noanswer_as_failed=>"0",
    :interpret_busy_as_failed=>"0",
    :register=>"0",
    :reg_extension=>"0"
  }.merge(options))
end


def get_mock_conflines(options = {})
  return mock_model(Confline, {
    :id=>"1",
    :name=>"test",
    :value=>"1",
    :value2=>"1",
    :owner_id=>"1"
  }.merge(options))
end

def get_mock_ivr_block(options = {})
  return mock_model(IvrBlock, {
    :name =>"New_Blockss",
    :ivr_id =>"6",
    :timeout_digits =>"333",
    :id =>"79",
    :timeout_response =>"666",
    :ivr_extensions => [get_mock_ivr_extension],
    :ivr_actions => [get_mock_ivr_action]
  }.merge(options))
end

def get_mock_ivr_extension(options = {})
  return mock_model(IvrExtension, {
    :exten =>"t",
    :goto_ivr_block_id =>"79",
    :id =>"8",
    :ivr_block_id =>"79"
  }.merge(options))
end

def get_mock_ivr_action(options = {})
  return mock_model(IvrAction, {
    :data3 =>"",
    :name =>"Debug",
    :data4 =>"",
    :data5 =>"",
    :data6 =>"",
    :order =>nil,
    :id =>"110",
    :data1 =>"New_Blockss_was_reached.",
    :ivr_block_id =>"79",
    :data2 =>""
  }.merge(options))
end

def get_mock_did(options = {})
  return mock_model(Did, {
    :id=>"1",
    :did=>"test",
    :status=>"active",
    :user_id=>"0",
    :device_id=>"1",
    :subscription_id=>"1",
    :reseller_id=>"1",
    :closed_till=>"2008-01-01 01:01:01",
    :dialplan_id=>"2",
    :language=>"en",
    :provider_id=>"5",
    :comment=>"test",
    :call_limit=>"0"
  }.merge(options))
end

def get_mock_payment_ouroboros_unnanounced(options = {})
  return mock_model(Payment, {
    :tax=>"1.8",
    :shipped_at=>nil,
    :completed=>"0",
    :paymenttype=>"ouroboros",
    :hash=>nil,
    :pending_reason=>"Unnotified payment",
    :transaction_id=>nil,
    :amount=>"11.8",
    :card=>"0",
    :owner_id=>"0",
    :id=>"189",
    :vat_percent=>"18",
    :user_id=>"0",
    :gross=>"10",
    :fee=>"0",
    :last_name=>"Admin",
    :bill_nr=>nil,
    :payer_status=>nil,
    :date_added=>"2009-01-19 11:56:16".to_time,
    :currency=>"HRK",
    :residence_country=>nil,
    :payer_email=>nil,
    :first_name=>"System",
    :email=>nil
  }.merge(options))
end


def get_mock_payment_ouroboros(options = {})
  return mock_model(Payment, {
    :tax=>"1.8",
    :shipped_at=>"2009-01-19 12:49:55".to_time,
    :completed=>"1",
    :paymenttype=>"ouroboros",
    :hash=>"b7c4e6a3b988b78daa396cad4338c865",
    :pending_reason=>"",
    :transaction_id=>"67193",
    :amount=>"11.8",
    :card=>"0",
    :owner_id=>"0",
    :id=>"197",
    :vat_percent=>"18",
    :user_id=>"0",
    :gross=>"10",
    :fee=>"0",
    :last_name=>"Admin",
    :bill_nr=>nil,
    :payer_status=>nil,
    :date_added=>"2009-01-19 12:49:10".to_time,
    :currency=>"HRK",
    :residence_country=>nil,
    :payer_email=>"",
    :first_name=>"System",
    :email=>nil
  }.merge(options))
end

def get_mock_service(options = {})
  return mock_model(Service, {
    :id=>"1",
    :name=>"test",
    :servicetype=>"periodic_fee",
    :destinationgroup_id=>nil,
    :periodtype=>"month",
    :price=>"10.00".to_f,
    :owner_id=>"1",
    :quantity=>"2"
  }.merge(options))
end

def get_mock_subscription(options = {})
  return mock_model(Subscription, {
    :id=>"1",
    :service_id=>"1",
    :user_id=>"1",
    :device_id=>"1",
    :activation_start=>"2001-01-01 01:01:01".to_time,
    :activation_end=>"2036-01-01 01:01:01".to_time,
    :added=>"2001-01-01 01:01:01".to_time,
    :memo=>"blabla"
  }.merge(options))
end

def get_mock_server(options = {})
  return mock_model(Server, {
    :id=>"1",
    :server_ip=>"127.0.0.1",
    :staus_ursl=>"bla",
    :server_type=>"1",
    :active=>"1",
    :comment=>"3333333333",
    :hostname=>"bla",
    :maxcalllimit=>"400",
    :ami_port=>"3434",
    :ami_secret=>"aaa",
    :ami_username=>"aaa",
    :server_id=>"1",
    :port=>"4343",
    :ssh_username=>"ppp",
    :ssh_secret=>"ppp",
    :ssh_port=>"22",
    :gateway_active=>"0"
  }.merge(options))
end


def get_mock_lcrprovider(options = {})
  return mock_model(Lcrprovider, {
    :id=>"1",
    :lcr_id=>"1",
    :provider_id=>"1",
    :active=>"1",
    :priority=>"1",
    :percent=>"100"
  }.merge(options))
end

def get_mock_smsrate(options = {})
  return mock_model(SmsRate, {
    :id=>"1",
    :prefix=>"111",
    :price=>"10",
    :sms_tariff_id=>"1"
  }.merge(options))
end

def get_mock_smstariff(options = {})
  return mock_model(SmsTariff, {
    :id=>"1",
    :name=>"111",
    :tariff_type=>"user",
    :owner_id=>"1",
    :currency=>"LTU"
  }.merge(options))
end


def get_mock_voucher(options = {})
  return mock_model(Voucher, {
    :id=>"1",
    :number=>"111",
    :tag=>"user",
    :credit_with_vat=>"1",
    :vat_percent=>"1",
    :user_id=>"-1",
    :use_date=>"2009-01-01 01:01:01".to_time,
    :active_till=>"2019-01-01 01:01:01".to_time,
    :currency=>"USD",
    :payment_id=>"1",
    :active=>"1"
  }.merge(options))
end

=begin rdoc

=end 

def get_mock_recording(options = {})
  return mock_model(Recording, {
    :comment => "Testa",
    :rc_device_id => "142",
    :orced => "0",
    :src => "470224",
    :deleted => "0",
    :enabled => "1",
    :dst => "899140828",
    :id => "1",
    :user_id => "0",
    :send_time => nil,
    :path => "/sound/test.mp3",
    :call_id => "22297",
    :dst_device_id => "0",
    :datetime => "2008-02-08 12:00:55".to_time,
    :call => get_mock_call(:id => 22297)
  }.merge(options))
end

=begin rdoc

=end 

def get_mock_user_role
  mock_model(Recording, {:name => "user", :id => "9"})
end
=begin rdoc

=end 

def get_mock_roles
  return [
    get_mock_user_role,
    mock_model(Recording, {:name => "admin", :id => "6"}),
    mock_model(Recording, {:name => "reseller", :id => "8"}),
    mock_model(Recording, {:name => "accountant", :id => "17"})
  ]

end


def get_mock_email(options = {})
  return mock_model(Email, {
    :id => "1",
    :name => "test",
    :subject => "test",
    :date_created => "2008-08-08 08:08:08",
    :body => "bla bla bla <%= server_ip %>",
    :template => "1",
    :format => "html",
    :owner_id => "0",
    :callcenter => "0"
  }.merge(options))

end


def get_mock_invoice(options = {})
  return mock_model(Invoice, {
    :id => "1",
    :user_id => "1",
    :period_start => "2008-08-01",
    :period_end => "2008-08-31",
    :issue_date => "2008-08-08",
    :paid => "1",
    :paid_date => "2008-08-08 08:08:08",
    :price => "10",
    :price_with_vat => "20",
    :payment_id => "20",
    :number => "INV007",
    :sent_email => "0",
    :sent_manually=>"0"
  }.merge(options))

end

def get_mock_hangupcausecode(options = {})
  return mock_model(Hangupcausecode, {
    :id => "1",
    :code => "1",
    :description => "bla"
  }.merge(options))
end

def get_mock_terminator(options = {})
  return mock_model(Terminator, {
    :id => "1",
    :name => "New_Terminator"
  }.merge(options))
end


def get_mock_devicegroup(options = {})
  return mock_model(Devicegroup, {
    :id => "1",
    :user_id => "1",
    :address_id => "1",
    :name => "bla",
    :added => "2001-01-01 01:01:01".to_time,
    :primary => 1
  }.merge(options))
end

def get_mock_payment(options={})
  return mock_model(Payment, {
    :tax=>"1.8",
    :shipped_at=>"2009-01-19 12:49:55".to_time,
    :completed=>"1",
    :paymenttype=>"manual",
    :hash=>"b7c4e6a3b988b78daa396cad4338c865",
    :pending_reason=>"",
    :transaction_id=>"67193",
    :amount=>"11.8",
    :card=>"0",
    :owner_id=>"0",
    :id=>"197",
    :vat_percent=>"18",
    :user_id=>"0",
    :gross=>"10",
    :fee=>"0",
    :last_name=>"Admin",
    :bill_nr=>nil,
    :payer_status=>nil,
    :date_added=>"2009-01-19 12:49:10".to_time,
    :currency=>"HRK",
    :residence_country=>nil,
    :payer_email=>"",
    :first_name=>"System",
    :email=>nil
  }.merge(options))
end


def get_mock_dialplan(options={})
  return mock_model(Dialplan, {
    :id=>"1",
    :name=>"test",
    :dptype=>"pbxfunction",
    :data1=>"4",
    :data2=>"*98",
    :data3=>"USD",
    :data4=>"en",
    :data5=>nil,
    :data6=>nil,
    :data7=>nil,
    :data8=>nil
  }.merge(options))
end


def get_mock_tax(options={})
  return mock_model(Tax, {
    :id=>"1",
    :tax1_enabled =>1,
    :tax2_enabled => 0,
    :tax3_enabled => 1,
    :tax4_enabled => 1,
    :tax1_name => "tax_1",
    :tax2_name => "tax_2",
    :tax3_name => "tax_3",
    :tax4_name => "tax_4",
    :total_tax_name => "tax_total",
    :tax1_value => 4.to_f,
    :tax2_value => 4.to_f,
    :tax3_value => 4.to_f,
    :tax4_value => 4.to_f,
    :get_tax_count => 4,
    :get_tax_sum => 12.to_f
  }.merge(options))
end

def get_mock_invoicedetail(options={})
  return mock_model(Invoicedetail, {
    :id=>"1",
    :invoice_id =>1,
    :name => "Calls",
    :quantity => 12,
    :price => 10.to_f,
    :invdet_type => 0
  }.merge(options))
end

=begin rdoc

=end 

def get_mock_voicemail_box(options={})
  return mock_model(Invoicedetail, {
    :sayduration=>"no",
    :mailbox=>"102",
    :saycid=>"yes",
    :uniqueid=>"1",
    :forcename=>"no",
    :delete=>"no",
    :sendvoicemail=>"no",
    :review=>"no",
    :fullname=>"Test User #1",
    :hidefromdir=>"yes",
    :saydurationm=>"1",
    :envelope=>"no",
    :callback=>"",
    :pager=>"",
    :device_id=>"3",
    :forcegreetings=>"no",
    :operator=>"no",
    :tz=>"central",
    :stamp=>"2009-01-16 15:44:34",
    :attach=>"yes",
    :context=>"default",
    :password=>"secret_pass",
    :nextaftercmd=>"yes",
    :dialout=>"",
    :email=>""
  }.merge(options))
end

=begin rdoc

=end 

def get_mock_acc_group(options={})
  return mock_model(AccGroup, {
    :name=>"Bandomasis_triusis",
    :id=>6
  }.merge(options))
end



def get_mock_acc_right(options={})
  return mock_model(AccRight, {
    :name=>"user_create_opt_1",
    :nice_name=>"User_Password",
    :id=>"35"
  }.merge(options))
end


def get_mock_acc_group_right(options={})
  return mock_model(AccGroupRight, {
    :acc_group_id=>"6",
    :id=>"53",
    :value=>"0",
    :acc_right_id=>"35"
  }.merge(options))
end
