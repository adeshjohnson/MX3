require File.dirname(__FILE__) +'/../../spec_helper.rb'

describe "/payments/ouroboros_pay.rhtml" do
  include PaymentsHelper
  
  it "should render when ouroboros is disabled" do
    login_as_admin
    assigns[:enabled] = 0
    render "/payments/ouroboros_pay"
    response.body.scan(/disabled/).size.should eql(1)
  end
   
  it "should render when ouroboros is enabled and payment was not successful" do
    login_as_admin
    assigns[:enabled] = 1
    assigns[:merchant_code] = "mer_code"
    assigns[:payment] = get_mock_payment_ouroboros_unnanounced
    assigns[:ouroboros_return_url] = "return"
    assigns[:ouroboros_accept_url] = "accept"
    assigns[:ouroboros_cancel_url] = "cancel"
    assigns[:lang] = "en"
    assigns[:currency] = "HRK"
    assigns[:user] = get_mock_user
    assigns[:address] = get_mock_address
    assigns[:direction] = "Lithuania"
    assigns[:description] = "Payment"
    assigns[:policy] = ["1", "2", "3"]
    assigns[:secret_key] = "Very_Secret_Key"
    assigns[:amount] = 10.0
    assigns[:amount_with_vat] = 11.9
    assigns[:vat] = 18
    render "/payments/ouroboros_pay"   
    MorLog.my_debug(response.body)
    response.should have_tag("img[title=Ouroboros]")
    response.should have_tag("input[type=submit]")    
  end
end
