require File.dirname(__FILE__) +'/../../spec_helper.rb'

describe "/payments/ouroboros.rhtml" do
  include PaymentsHelper
  
  it "should render when ouroboros is disabled" do
    login_as_admin
    assigns[:enabled] = 0
    render "/payments/ouroboros"
    response.body.scan(/disabled/).size.should eql(1)
  end
  
  it "should render when ouroboros is enabled" do
    login_as_admin
    assigns[:enabled] = 1
    assigns[:default_amount] = 10
    assigns[:min_amount] = 5
    assigns[:currency] = 'HRK'
    render "/payments/ouroboros"
    response.should have_tag("img[title=Ouroboros]")
    response.should have_tag("input[type=submit]")
  end
end
