require File.dirname(__FILE__) +'/../../spec_helper.rb'

describe "/payments/ouroboros_accept.rhtml" do
  include PaymentsHelper
  
  it "should render when ouroboros is disabled" do
    login_as_admin
    assigns[:enabled] = 0
    render "/payments/ouroboros_accept"
    response.body.scan(/disabled/).size.should eql(1)
  end
   
  it "should render when ouroboros is enabled and payment was not successful" do
    login_as_admin
    assigns[:enabled] = 1
    assigns[:error] = 1 
    render "/payments/ouroboros_accept"    
    response.should have_tag("img[title=Ouroboros]")
    response.body.scan(/#{_('Payment_was_not_successful')}/).size.should eql(1)
  end
  
  it "should render when ouroboros is enabled and payment was not successful" do
    login_as_admin
    assigns[:enabled] = 1
    assigns[:error] = 0
    assigns[:payment] = get_mock_payment_ouroboros
    render "/payments/ouroboros_accept"   
    MorLog.my_debug(response.body)
    response.should have_tag("img[title=Ouroboros]")    
    response.body.scan(/#{_('payment_successful')}/).size.should eql(1)
  end
end
