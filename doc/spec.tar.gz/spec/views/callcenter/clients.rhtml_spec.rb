require File.dirname(__FILE__) +'/../../spec_helper.rb'

describe "/callcenter/clients.rhtml" do
  include CallcenterHelper
  
  it "rhtm clients" do
    assigns[:clients] = [mock_model(CcClient, :name => "1", :client_id => "1",:agreement_number => "1", :agreement_date => "2000-02-02",:vat_code=>"1", :vat_percent=>"1", :user_id => "-1", :address_id => 1, :main_contact_id => 12, :id => 12)]
    assigns[:client] = mock_model(CcClient, :name => "1", :client_id => "1",:agreement_number => "1", :agreement_date => "2000-02-02",:vat_code=>"1", :vat_percent=>"1", :address_id => 1, :main_contact_id => 12, :id => 12, :user_id=> -1)
     assigns[:agents] =[ mock_model(User, :id => "1", :first_name=>"4" ,:last_name => "2000-02-02", :username=>";;;")]
      assigns[:agent] = mock_model(User, :id => "1", :first_name=>"4" ,:last_name => "2000-02-02", :username=>";;;")
      
     assigns[:data] = ["2000-02-02"]
     assigns[:all_client_fields] = [mock_model(CcClientField, :name => "Testas",:fieldtype => "Textfield", :inner_field_id => 0, :id => "1", :default_value=>"")]
     assigns[:f] = mock_model(CcClientField, :name => "Testas",:fieldtype => "Textfield", :inner_field_id => 0, :id => "1", :default_value=>"")
    assigns[:search_field] =[3]
    assigns[:total_pages] =2
    assigns[:page] =1
    render "/callcenter/clients"
    
   
    response.should have_tag("th", :text => /Client/)
  
  end 
  
 
end