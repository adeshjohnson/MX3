require File.dirname(__FILE__) +'/../../spec_helper.rb'

describe "/callcenter/action_edit.rhtml" do
  include CallcenterHelper
  
  it "should render form correctly for reminder" do
    #{:opened => true, :plan => @plan, :client => @client, :actions => @actions}%>
    assigns[:action] = mock_model(CcAction, :id => 15, :start_time => "2008-11-12 14:32:56", :cc_task_id => 12, :comment=> "test_plan_reminder", :action_type => "reminder")
    render "/callcenter/action_edit"
    response.should have_tag("textarea", :text => /test_plan_reminder/)
    response.should have_tag("th", :text => /Reminder/)
    response.should have_tag("select#date_from_year")
  end 
  
  it "should render form correctly for comment" do
    #{:opened => true, :plan => @plan, :client => @client, :actions => @actions}%>
    assigns[:action] = mock_model(CcAction, :id => 15, :cc_task_id => 12, :comment=> "test_plan_comment", :action_type => "comment")
    render "/callcenter/action_edit"
    response.should have_tag("textarea", :text => /test_plan_comment/)
    response.should have_tag("th", :text => /Comment/)
  end
  
  it "should render form correctly for note" do
    #{:opened => true, :plan => @plan, :client => @client, :actions => @actions}%>
    assigns[:action] = mock_model(CcAction, :id => 15, :cc_task_id => 12, :comment=> "test_plan_note", :action_type => "note")
    render "/callcenter/action_edit"
    response.should have_tag("textarea", :text => /test_plan_note/)
    response.should have_tag("th", :text => /Note/)
  end
  
end