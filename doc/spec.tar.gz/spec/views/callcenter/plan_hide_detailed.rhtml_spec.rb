require File.dirname(__FILE__) +'/../../spec_helper.rb'

describe "/callcenter/plan_hide_detailed.rhtml" do
  include CallcenterHelper
  
  it "should render form correctly" do
    #{:opened => true, :plan => @plan, :client => @client, :actions => @actions}%>
    assigns[:plan] = mock_model(CcPlan, :id => 15, :time => "2008-11-12 14:32:56", :cc_task_id => 12, :name => "plan_name")
    assigns[:client] = mock_model(CcClient, :id => 25)
    render "/callcenter/plan_hide_detailed"
    response.should have_tag("tr.callc_task")
    response.should have_tag("img[alt=Bullet_arrow_down]")
  end
  
end