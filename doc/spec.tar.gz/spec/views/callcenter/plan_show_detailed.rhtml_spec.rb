require File.dirname(__FILE__) +'/../../spec_helper.rb'

describe "/callcenter/plan_show_detailed.rhtml" do
  include CallcenterHelper
  
  it "should render form correctly" do
    #{:opened => true, :plan => @plan, :client => @client, :actions => @actions}%>
    assigns[:plan] = mock_model(CcPlan, :id => 15, :time => "2008-11-12 14:32:56", :cc_task_id => 12, :name => "plan_name")
    assigns[:client] = mock_model(CcClient, :id => 25)
    act1 = mock_model(CcAction, :id => 1, :created_at => "2008-11-14 17:52:33", :comment => "Test_note", :action_type => "note")
    act2 = mock_model(CcAction, :id => 2, :created_at => "2008-11-14 18:52:33", :comment => "", :action_type => "call")
    act3= mock_model(CcAction, :id => 3, :created_at => "2008-11-14 19:52:33", :comment => "Test_reminder", :action_type => "reminder", :start_time => "2008-12-14 00:52:33")
    assigns[:actions] = [act1, act2, act3]
    render "/callcenter/plan_show_detailed"
    response.should have_tag("tr.callc_task")
    response.should have_tag("img[alt=Bullet_arrow_up]")
    response.should have_tag("td", :text => /Note: Test_note/)
    response.should have_tag("td", :text => /Call/)
    response.should have_tag("td", :text => /Reminder: Test_reminder/)
  end
  
end