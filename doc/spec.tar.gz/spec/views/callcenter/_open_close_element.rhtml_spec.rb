require File.dirname(__FILE__) +'/../../spec_helper.rb'

describe "/callcenter/_open_close_element.rhtml" do
  include CallcenterHelper
  before(:each) do
    @plan = mock_model(CcPlan, :id => 15, :time => "2008-11-12 14:32:56", :cc_task_id => 12, :name => "plan_name")
    @client = mock_model(CcClient, :id => 25)
    act1 = mock_model(CcAction, :id => 1, :created_at => "2008-11-14 17:52:33", :comment => "Test_note", :action_type => "note")
    act2 = mock_model(CcAction, :id => 2, :created_at => "2008-11-14 18:52:33", :comment => "", :action_type => "call")
    act3= mock_model(CcAction, :id => 3,  :created_at => "2008-11-14 19:52:33", :comment => "Test_reminder", :action_type => "reminder", :start_time => "2008-12-14 00:52:33")
    @actions = [act1, act2, act3]
  end
  
  it "should render open table correctly" do
    render(:partial => "callcenter/open_close_element", :locals => {:opened => true, :plan => @plan, :client => @client, :actions => @actions})
    response.should have_tag("tr.callc_task")
    response.should have_tag("img[alt=Bullet_arrow_up]")
    response.should have_tag("td", :text => /Note:.* Test_note/)
    response.should have_tag("td", :text => /Call:/)
    response.should have_tag("td", :text => /Reminder:.* Test_reminder/)
    response.should have_tag("a", :text=> "plan_name")
  end
  
  it "should render closing table correctly" do
    render(:partial => "callcenter/open_close_element", :locals => {:opened => false, :plan => @plan, :client => @client})
    response.should have_tag("tr.callc_task")
    response.should have_tag("img[alt=Bullet_arrow_down]")
    response.should have_tag("a", :text=> "plan_name")
  end
end