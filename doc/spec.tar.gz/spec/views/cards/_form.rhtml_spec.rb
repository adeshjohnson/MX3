require File.dirname(__FILE__) +'/../../spec_helper.rb'
include CallcenterHelper

describe "/cardgroups/_form.rhtml" do
  before(:each) do
  end
  
  it "should " do
  end

end