require File.dirname(__FILE__) +'/../../spec_helper.rb'
include CardsHelper

describe "/cards/show.rhtml" do
  before(:each) do
    @card = get_mock_card(:calls => [], :cardgroup => 1)
    @cg = get_mock_cardgroup
    assigns[:card] = @card
    assigns[:cg] = @cg
  end
  
  it "should render show when pin is visible" do
    assigns[:show_pin] = true
    render "/cards/show"
    response.should have_tag("p",{:text => /#{@card.pin}/})
  end

  it "should render show when pin is visible" do
    assigns[:show_pin] = false
    render "/cards/show"
    response.should_not have_tag("p",{:text => /#{@card.pin}/})
  end

end
