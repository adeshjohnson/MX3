require File.dirname(__FILE__) +'/../../spec_helper.rb'
include CardsHelper

describe "/cards/list.rhtml" do
  before(:each) do
    @cards = [get_mock_card(:calls => [])]
    @cg = get_mock_cardgroup
    assigns[:cards_all] =66
    assigns[:cards] = @cards
    assigns[:cg] = @cg
    assigns[:total_pages] = 1
  end
  
  it "should render list when management is enabled" do
    assigns[:allow_manage] = true
    render "/cards/list"  
    response.should have_tag("img[title=Add]")
    response.should have_tag("img[title=Delete]")
  end
  
  it "should render list when management is disabled" do
    assigns[:allow_manage] = false
    render "/cards/list" 
    response.should_not have_tag("img[title=Add]")
    response.should_not have_tag("img[title=Delete]")
  end
end
