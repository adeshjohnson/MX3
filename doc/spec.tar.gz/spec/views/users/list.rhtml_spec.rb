require File.dirname(__FILE__) +'/../../spec_helper.rb'

describe "/users/list.rhtml" do
  include UsersHelper
  
  before(:each) do
    assigns[:users] = []
    assigns[:total_pages] = 0
    assigns[:page] = 1
    assigns[:roles] = []
  end
  
  it "should show show password change field when allowed for accountant" do
    login_as_admin     
    session[:usertype] = "accountant"
    Confline.should_receive(:get_value).with('Accountant_allow_User_create').and_return("1")
    
    render "users/list"
    response.should have_tag("a[href=/users/new]")
    MorLog.my_debug(response.body)
  end
  
  it "should show show password change field when not allowed for accountant" do
    login_as_admin     
    session[:usertype] = "accountant"
    Confline.should_receive(:get_value).with('Accountant_allow_User_create').and_return("0")
    
    render "users/list"
    response.should_not have_tag("a[href=/users/new]")
    MorLog.my_debug(response.body)
  end
end