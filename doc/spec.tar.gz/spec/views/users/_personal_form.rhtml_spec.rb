require File.dirname(__FILE__) +'/../../spec_helper.rb'

describe "/users/_personal_form.rhtml" do
  include UsersHelper
  
  before(:each) do
    @user = get_mock_user
    Confline.stub!(:get_value)
    Confline.should_receive(:get_value).with("Reg_allow_user_enter_vat").and_return(1)
    Confline.should_receive(:get_value).with("Devices_Check_Ballance").and_return(1)
  end
  
  
  it "should render form" do
    login_as_admin     
    assigns[:user] = @user
    assigns[:countries] = []
    render :partial => "users/personal_form"
  end
  
  it "should render form when recordings are enabled" do
    login_as_admin     
    REC_Active = 1
    @user.stub!(:recording_enabled => 1)
    @user.should_receive(:recordings_email).and_return("test@email.com")
    assigns[:user] = @user
    assigns[:countries] = []
    render :partial => "users/personal_form"
    response.body.scan(/#{_('Email_for_deleted_Recordings')}/).size.should eql(1)    
  end
  
  it "should render form when recordings are enabled" do
    login_as_admin     
    REC_Active = 1
    @user.stub!(:recording_enabled => 0)
    @user.should_not_receive(:recordings_email).and_return("test@email.com")
    assigns[:user] = @user
    assigns[:countries] = []
    render :partial => "users/personal_form"
    response.body.scan(/#{_('Email_for_deleted_Recordings')}/).size.should eql(0)
  end
end
