require File.dirname(__FILE__) +'/../../spec_helper.rb'

describe "/users/personal_details.rhtml" do
  include DidsHelper
  
  before(:each) do
  end
  
  it "should show link to check user balance" do
    login_as_user(123)
    @user = get_mock_user(:get_hash => "124")
    Confline.stub!(:get_value)

    Confline.should_receive(:get_value).with("Reg_allow_user_enter_vat").and_return("0")
    Confline.should_receive(:get_value).with("Devices_Check_Ballance").and_return("1")
    assigns[:user] = @user    
    assigns[:address] = get_mock_address
    assigns[:countries] =  []
    assigns[:invoice] = 1
    render "/users/personal_details"
    #neitin grazus budas bet bentjau veikia
    MorLog.my_debug(response.body)
    response.body.to_s.scan(/http:\/\/localhost:3000\/api\/simple_balance\/124/).size.should eql(1)
    
  end
  
end