require File.dirname(__FILE__) +'/../../spec_helper.rb'

describe "/users/_form.rhtml" do
  include UsersHelper
  
  before(:each) do
    @user = get_mock_user
    
  end
  
  it "should render form without errors" do 
    assigns[:user] = @user
    assigns[:tariffs] = []
    assigns[:lcrs] = []
    assigns[:i1] = 1
    assigns[:i2] = 2
    assigns[:i3] = 4
    assigns[:i4] = 8
    assigns[:i5] = 16
    assigns[:i6] = 32
    assigns[:countries] = []
    render :partial => "users/form"
    response.should have_tag("td",{:text => /Generate.*Invoice/})
  end
  
  it "should show show password change field when allowed for accountant" do
    login_as_admin     
    session[:usertype] = "accountant"
    
    assigns[:user] = @user
    assigns[:tariffs] = []
    assigns[:lcrs] = []
    assigns[:i1] = 1
    assigns[:i2] = 2
    assigns[:i3] = 4
    assigns[:i4] = 8
    assigns[:i5] = 16
    assigns[:i6] = 32
    assigns[:countries] = []
    Confline.should_receive(:get_value).with('Accountant_allow_User_Password').and_return("1")
    
    render :partial => "users/form" 
    MorLog.my_debug(response.body)
    response.should have_tag("input[type=password]")
  end
  
  it "should show show password change field when not allowed for accountant" do
    login_as_admin     
    session[:usertype] = "accountant"
    
    assigns[:user] = @user
    assigns[:tariffs] = []
    assigns[:lcrs] = []
    assigns[:i1] = 1
    assigns[:i2] = 2
    assigns[:i3] = 4
    assigns[:i4] = 8
    assigns[:i5] = 16
    assigns[:i6] = 32
    assigns[:countries] = []
    Confline.should_receive(:get_value).with('Accountant_allow_User_Password').and_return("0")
    
    render :partial => "users/form"
    response.should_not have_tag("input[type=password]")
  end
  
  it "should show recordings options when recordings are enabled" do
  end
end
