require File.dirname(__FILE__) +'/../../spec_helper.rb'
describe "/stats/_providers_calls.rhtml" do
  include StatsHelper
  
  before(:each) do
    login_as_admin
    @provider = get_mock_provider(:id => 1)
    @user = get_mock_user(:id => 2)
    @call_type = "answered"        
    @total_duration = 0
    default_login_data()
    assigns[:provider] = @provider
    assigns[:total_price] = 0
    assigns[:total_billsec] = 0 
    assigns[:prov_rate] = []
    assigns[:total_prov_price] = 0
    assigns[:total_inc_price] = 0
    assigns[:total_price2] = 0             
    assigns[:calls] = [get_mock_call(:getDebugInfo=> "")]
    assigns[:Show_Currency_Selector]=1
    assigns[:user]= @user
    assigns[:devices] = @user.devices
    assigns[:total_pages] = 2
    assigns[:exchange_rate] = 1

    @options = {
      :call_type => "ANSWERED",
      :direction => "incoming" 
    }
    assigns[:options] = @options
  end
  it "should render" do
    render "stats/_providers_calls"
  end
 
end
