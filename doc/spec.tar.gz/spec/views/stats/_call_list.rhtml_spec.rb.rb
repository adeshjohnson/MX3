require File.dirname(__FILE__) +'/../../spec_helper.rb'
describe "/stats/_list_calls.rhtml" do
  include StatsHelper
end