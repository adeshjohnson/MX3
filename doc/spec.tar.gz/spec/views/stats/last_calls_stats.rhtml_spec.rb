require File.dirname(__FILE__) +'/../../spec_helper.rb'
describe "/stats/last_calls_stats.rhtml" do
  include StatsHelper
  
  before(:each) do
    @provider = Provider.find(1)
    @user = User.find(2)
    @call_type = "answered"        
    @total_duration = 0
    default_login_data()
    @curr_rate = {} 
    @curr_rate2 = {} 
    @curr_rate[1] = 6
    @curr_rate2[1] = 4
    assigns[:curr_rate] = {1 => 2, 2 => 3}
    assigns[:curr_rate2] = {1 => 1, 2 => 2}
    assigns[:provider] = @provider
    assigns[:total_price] = 0
    assigns[:total_billsec] = 0 
    assigns[:prov_rate] = []
    assigns[:curr_prov_rate]= []
    assigns[:curr_prov_rate2]= []
    assigns[:curr_inc_rate] =[]
    assigns[:total_prov_price] = 0
    assigns[:total_inc_price] = 0
    assigns[:total_price2] = 0             
    assigns[:calls] = Call.find_by_sql("SELECT calls.* FROM calls JOIN devices ON (devices.id = dst_device_id) WHERE (calls.card_id = 0 AND devices.user_id = #{@user.id} #{@inc_call_type} AND callertype = 'Outside' AND ((calldate BETWEEN '#{session_from_datetime.to_s}' AND '#{session_till_datetime.to_s}' AND processed = 1) OR (processed = 0))) ORDER BY calldate DESC")  
    assigns[:Show_Currency_Selector]=1
    assigns[:user]= @user
    assigns[:devices] = @user.devices
    assigns[:total_pages] = 2
    assigns[:total_pages] = 2
    assigns[:call_type] = "answered"    
  end
end