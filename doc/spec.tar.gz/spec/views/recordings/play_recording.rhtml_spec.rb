require File.dirname(__FILE__) +'/../../spec_helper.rb'

describe "/recordings/play_recording.rhtml" do
  include RecordingsHelper
  
  before(:each) do
  end
  
  it "should announce if  recording was not found" do
    render "/recordings/play_recording.rhtml"
    response.body.strip.should eql(_("Recording_was_not_found"))    
  end
  
  it "should play recording" do
    @rec = get_mock_recording
    assigns[:rec] = @rec
    assigns[:server_path] = "test.host:3000/"
    render "/recordings/play_recording.rhtml"
    response.should have_tag("div.nb")
  end
  
end
