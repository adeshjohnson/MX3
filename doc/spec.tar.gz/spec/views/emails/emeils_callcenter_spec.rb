require File.dirname(__FILE__) +'/../../spec_helper.rb'

describe "/emails/emails_callcenter.rhtml" do
  
  
  it "should render form correctly" do
   
    assigns[:emails] = mock_model(Email, :id => 15, :callcenter => "1", :name => "12", :type => "html",:template=>"1")
    
   

  end
  
end