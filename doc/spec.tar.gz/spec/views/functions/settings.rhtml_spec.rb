require File.dirname(__FILE__) +'/../../spec_helper.rb'

describe "/functions/settings.rhtml" do
  include FunctionsHelper
  
  it "should render without errors with empty data sets" do
    login_as_admin
    assigns[:tariffs] = []
    assigns[:lcrs] = []
    assigns[:countries] = []
    assigns[:servers] = []
    assigns[:all_ivrs] = []
    render "/functions/settings"
    #`echo "#{response.body.to_s.gsub("\"", "'")}" > /home/bugo/Desktop/text.txt`
    response.should have_tag("td[colspan=2]", :text=> /Accountant/)
    response.should have_tag("td", :text=> /API/)
    response.should have_tag("div.dhtmlgoodies_aTab", :count => 12)
  end
end
