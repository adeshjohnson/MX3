require File.dirname(__FILE__) +'/../../spec_helper.rb'

describe "/functions/settings.rhtml" do
  include FunctionsHelper
  
  before(:each) do
  end
  
  it "should render when REC_Active = 1" do
    assigns[:servers] = [get_mock_server]
    REC_Active = 1
    CALLC_Active = 1
    CC_Active = 1
    login_as_admin    
    Confline.stub!(:get_value)
    Confline.should_receive(:get_value).with("Recordings_addon_Use_External_Server", 0)
    Confline.should_receive(:get_value).with("Recordings_addon_IP", 0)
    Confline.should_receive(:get_value).with("Recordings_addon_Port", 0)
    Confline.should_receive(:get_value).with("Recordings_addon_Login", 0)
    Confline.should_receive(:get_value).with("Recordings_addon_Password", 0)
    Confline.should_receive(:get_value).with("Recordings_addon_Max_Space", 0)
    
    Confline.should_receive(:get_value).with("Server_to_use_for_call_center", 0)
    
    Confline.should_receive(:get_value).with("CCShop_show_values_without_VAT_for_user", 0)

    render "/functions/settings_addons"
    response.should have_tag("div.dhtmlgoodies_aTab", :count => 3)
  end
  
  it "should render when REC_active = 0" do
    REC_Active = 0
    CALLC_Active = 0
    CC_Active = 0
    login_as_admin    
    Confline.stub!(:get_value)
    Confline.should_not_receive(:get_value).with("Recordings_addon_Use_External_Server", 0)
    Confline.should_not_receive(:get_value).with("Recordings_addon_IP", 0)
    Confline.should_not_receive(:get_value).with("Recordings_addon_Port", 0)
    Confline.should_not_receive(:get_value).with("Recordings_addon_Login", 0)
    Confline.should_not_receive(:get_value).with("Recordings_addon_Password", 0)
    Confline.should_not_receive(:get_value).with("Recordings_addon_Max_Space", 0)
    Confline.should_not_receive(:get_value).with("Server_to_use_for_call_center", 0)
    Confline.should_not_receive(:get_value).with("CCShop_show_values_without_VAT_for_user", 0)
    render "/functions/settings_addons"
    response.should have_tag("div.dhtmlgoodies_aTab", :count => 0)
    response.should have_tag("td", :count => 1, :text=> _('Disabled'))
  end
end
