require File.dirname(__FILE__) +'/../../spec_helper.rb'

describe "/permissions/group_edit.rhtml" do

  before (:each) do
  end
  
  it "should " do
  end
  
end

