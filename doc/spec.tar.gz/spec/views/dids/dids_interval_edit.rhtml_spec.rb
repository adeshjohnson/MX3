require File.dirname(__FILE__) +'/../../spec_helper.rb'

describe "/dids/dids_interval_edit.rhtml" do
  include DidsHelper
  
  before(:each) do
    assigns[:from] = '123'
    assigns[:till] = '321'
#    @dids = mock_model(Did)
#    @providers= []  
#    @free_users = []
#    @dids = []
    assigns[:dids] = []
    assigns[:providers] = []
    assigns[:free_users] = []
  end
  
  it "should render form correctly" do
    render "/dids/dids_interval_edit"
    response.should have_tag("form[action=/dids/update?from=123&amp;till=321][method=post]")
    response.should have_tag("table.maintable")
    response.should have_tag("input[name=commit]")
  end
  
end