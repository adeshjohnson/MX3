require File.dirname(__FILE__) +'/../../spec_helper.rb'

describe "/dids/dids_interval_edit.rhtml" do
  include DidsHelper
  
  before(:each) do
  end
  
  it "should render form correctly" do
    @card = get_mock_card
    @cg = get_mock_cardgroup
    @vat_percent = 12
    assigns[:card] = @card
    assigns[:calls] = [get_mock_call]  
    assigns[:cg] = @cg
    assigns[:vat_percent] = 18
    render "/ccshop/call_list"
    response.should have_tag("table.maintable") do
      with_tag("td[align=right]", "0")
    end
  end
  
end