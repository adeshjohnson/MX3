require File.dirname(__FILE__) +'/../../spec_helper.rb'
include CallcenterHelper

describe "/devices/show_devices.rhtml" do
  before(:each) do
    @user = get_mock_user
    assigns[:user] = @user
    assigns[:devices] = []
    assigns[:return_controller] = "devices"
    assigns[:return_action] = ""
  end

  it "should render devices list when accountant is allowed to add devices"  do
    login_as_admin
    session[:usertype] = "accountant" 
    Confline.stub!(:get_value)
    Confline.should_receive(:get_value).with('Accountant_allow_Device_PIN').and_return("1")
    Confline.should_receive(:get_value).with('Accountant_allow_Device_create').and_return("1")
    render "devices/show_devices"
    response.should have_tag("a[href=/devices/new?return_to_action=&amp;return_to_controller=devices&amp;user_id=15]")
    #MorLog.my_debug(response.body)
  end
  
  it "should render devices list when accountant is NOT allowed to add devices"  do
    login_as_admin
    session[:usertype] = "accountant" 
    Confline.stub!(:get_value)
    Confline.should_receive(:get_value).with('Accountant_allow_Device_PIN').and_return("1")
    Confline.should_receive(:get_value).with('Accountant_allow_Device_create').and_return("0")    
    render "devices/show_devices"
    response.should_not have_tag("a[href=/devices/new?return_to_action=&amp;return_to_controller=devices&amp;user_id=15]")
    #MorLog.my_debug(response.body)
  end
  

end
