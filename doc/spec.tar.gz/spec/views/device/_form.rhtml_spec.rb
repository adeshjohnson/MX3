require File.dirname(__FILE__) +'/../../spec_helper.rb'
include DevicesHelper

describe "/devices/_form.rhtml" do
  before(:each) do
    login_as_admin
    @device = get_mock_device(:secret=>101, :name => "dev_name", :secret=> "dev_secret")
    assigns[:new_device] = false
    assigns[:devicetypes] = []
    assigns[:locations] = []
    assigns[:default] = 0
    assigns[:device] = @device
    assigns[:audio_codecs] = []
    assigns[:video_codecs] = []
    assigns[:device_type] = "SIP"
    assigns[:default] = 0
    assigns[:extension] = "101"
    assigns[:cid_name] = "cid_name"
    assigns[:cid_number] = "555444"
  end
  
  it "should correctly render with session[:acc_device_pin] = 2 option for accountant" do
    login_as_accountant(4)
    @device.should_receive(:pin)
    assigns[:device] = @device
    session[:acc_device_pin] = 2
    render(:partial => "devices/form")
    response.should have_tag("input#device_pin[value=123]")
  end
  
  it "should correctly render with session[:acc_device_pin] = 1 option for accountant" do
    login_as_accountant(4)
    @device.should_receive(:pin)
    assigns[:device] = @device
    session[:acc_device_pin] = 1
    render(:partial => "devices/form")
    response.should_not have_tag("input#device_pin[value=123]")
    response.body.scan(/<td>123<\/td>/).size.should eql(1)
  end 
  
  it "should correctly render with session[:acc_device_pin] = 0 option for accountant" do
    login_as_accountant(4)
    @device.should_not_receive(:pin)
    assigns[:device] = @device
    session[:acc_device_pin] = 0
    render(:partial => "devices/form")
    response.should_not have_tag("input#device_pin[value=123]")
    response.body.scan(/<td>123<\/td>/).size.should eql(0)
  end
  
  it "should work with session[:acc_device_edit_opt_1] = 2" do
    login_as_accountant(4)
    session[:acc_device_edit_opt_1] = 2
    render(:partial => "devices/form")
    response.should have_tag("input#device_extension[value=101]")
  end
    
  it "should work with session[:acc_device_edit_opt_1] = 1" do
    login_as_accountant(4)
    session[:acc_device_edit_opt_1] = 1
    render(:partial => "devices/form")
    response.should_not have_tag("input#device_extension[value=101]")
    response.body.scan(/<td>101<\/td>/).size.should eql(1)
  end
    
  it "should work with session[:acc_device_edit_opt_1] = 0" do
    login_as_accountant(4)
    session[:acc_device_edit_opt_1] = 0
    render(:partial => "devices/form")
    response.should_not have_tag("input#device_extension[value=101]")
    response.body.scan(/<td>101<\/td>/).size.should eql(0)
  end

  it "should work with session[:acc_device_edit_opt_2] = 2" do
    @device.should_receive(:name).and_return(@device.name)
    @device.should_receive(:secret).and_return(@device.secret)
    login_as_accountant(4)
    session[:acc_device_edit_opt_2] = 2
    render(:partial => "devices/form")
    response.should have_tag("input#device_name")
    response.should have_tag("input#device_secret")
    response.body.scan(/<b>#{_('Authentication')}<\/b>/).size.should eql(1)
  end
  
    it "should work with session[:acc_device_edit_opt_2] = 1" do
    @device.should_receive(:name).and_return(@device.name)
    @device.should_receive(:secret).and_return(@device.secret)
    login_as_accountant(4)
    session[:acc_device_edit_opt_2] = 1
    render(:partial => "devices/form")
    response.body.scan(/<td>dev_name<\/td>/).size.should eql(1)
    response.body.scan(/<td>dev_secret<\/td>/).size.should eql(1)
    response.should_not have_tag("input#device_name")
    response.should_not have_tag("input#device_secret")
    response.body.scan(/<b>#{_('Authentication')}<\/b>/).size.should eql(1)
  end
  
  it "should work with session[:acc_device_edit_opt_2] = 2" do
    @device.should_not_receive(:name)
    @device.should_not_receive(:secret)
    login_as_accountant(4)
    session[:acc_device_edit_opt_2] = 0
    render(:partial => "devices/form")
    response.should_not have_tag("input#device_name")
    response.should_not have_tag("input#device_secret")
    response.body.scan(/<td>dev_name<\/td>/).size.should eql(0)
    response.body.scan(/<td>dev_secret<\/td>/).size.should eql(0)
    response.body.scan(/<b>#{_('Authentication')}<\/b>/).size.should eql(0)
  end
  
  it "should work with session[:acc_device_edit_opt_3] = 2" do
    login_as_accountant(4)
    session[:acc_device_edit_opt_3] = 2
    render(:partial => "devices/form")
    response.should have_tag("input#cid_name[value=cid_name]")
  end
  
  it "should work with session[:acc_device_edit_opt_3] = 2" do
    login_as_accountant(4)
    session[:acc_device_edit_opt_3] = 1
    render(:partial => "devices/form")
    response.body.scan(/<td>cid_name<\/td>/).size.should eql(1)
    response.should_not have_tag("input#cid_name[value=cid_name]")
  end
  
  it "should work with session[:acc_device_edit_opt_3] = 2" do
    login_as_accountant(4)
    session[:acc_device_edit_opt_3] = 0
    render(:partial => "devices/form")
    response.body.scan(/<td>cid_name<\/td>/).size.should eql(0)
    response.should_not have_tag("input#cid_name[value=cid_name]")
  end

  it "should work with session[:acc_device_edit_opt_4] = 2" do
    login_as_accountant(4)
    session[:acc_device_edit_opt_4] = 2
    render(:partial => "devices/form")
    response.should have_tag("input#cid_number[value=555444]")
  end
  
  it "should work with session[:acc_device_edit_opt_4] = 1" do
    login_as_accountant(4)
    session[:acc_device_edit_opt_4] = 1
    render(:partial => "devices/form")
    response.body.scan(/<td>555444<\/td>/).size.should eql(1)
    response.should_not have_tag("input#cid_number[value=555444]")
  end
  
  it "should work with session[:acc_device_edit_opt_4] = 0" do
    login_as_accountant(4)
    session[:acc_device_edit_opt_4] = 0
    render(:partial => "devices/form")
    response.body.scan(/<td>555444<\/td>/).size.should eql(0)
    response.should_not have_tag("input#cid_number[value=555444]")
  end
 
  it "should work with session[:acc_voicemail_password] = 2" do
    login_as_accountant(4)
    session[:acc_voicemail_password] = 2
    render(:partial => "devices/form")
    response.should have_tag("input#vm_psw")
  end
 
  it "should work with session[:acc_voicemail_password] = 1" do
    login_as_accountant(4)
    session[:acc_voicemail_password] = 1
    render(:partial => "devices/form")
    response.body.scan(/<td>#{@device.voicemail_box.password}<\/td>/).size.should eql(1)
    response.should_not have_tag("input#vm_psw")
  end

  it "should work with session[:acc_voicemail_password] = 0" do
    login_as_accountant(4)
    session[:acc_voicemail_password] = 0
    render(:partial => "devices/form")
    response.body.scan(/<td>#{@device.voicemail_box.password}<\/td>/).size.should eql(0)
    response.should_not have_tag("input#vm_psw")
  end
     
  it "should show recordings options when recordings are enabled" do
    REC_Active = 1
    render(:partial => "devices/form") 
    response.body.scan(/#{_('Record')}:/).size.should eql(2)
  end
  
  it "should show recordings options when recordings are disabled" do
    REC_Active = 1
    assigns[:user] = get_mock_user(:recording_forced_enabled => 0, :recording_enabled => 0)
    render(:partial => "devices/form") 
    response.body.scan(/#{_('Record')}:/).size.should eql(1)
    response.should_not have_tag("td", :text => _('Record')+":")
  end
end
