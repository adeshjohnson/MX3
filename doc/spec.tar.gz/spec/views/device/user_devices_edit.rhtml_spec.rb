require File.dirname(__FILE__) +'/../../spec_helper.rb'
include DevicesHelper

describe "/devices/user_devices_edit.rhtml" do

  before (:each) do
  end
  
  it "should render" do
    assigns[:device] = get_mock_device
    assigns[:user] = get_mock_user
    assigns[:dids] = []
    assigns[:cid_name] = ""
    assigns[:cid_number] = ""
    render "devices/user_device_edit"
  end
  
    it "should show recordings table" do
    assigns[:device] = get_mock_device
    assigns[:user] = get_mock_user
    assigns[:dids] = []
    assigns[:cid_name] = ""
    assigns[:cid_number] = ""
    render "devices/user_device_edit"
  end
  
end

