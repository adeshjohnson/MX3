require File.dirname(__FILE__) +'/../../spec_helper.rb'

describe "/users/personal_details.rhtml" do
  include DidsHelper
  
  before(:each) do
  end
  
  it "should not show options for reseller" do
    login_as_reseller(123)
    assigns[:ptariff] = get_mock_tariff
    render "/tariffs/make_user_tariff_wholesale"
    response.should_not have_tag("select")
  end
  
  it "should show options for admin" do
    login_as_admin
    assigns[:ptariff] = get_mock_tariff
    render "/tariffs/make_user_tariff_wholesale"
    response.should have_tag("select")
  end

end
