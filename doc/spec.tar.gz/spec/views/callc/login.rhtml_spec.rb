require File.dirname(__FILE__) +'/../../spec_helper.rb'

describe "/callc/login.rhtml" do
   include  CallcHelper
   
   before(:each) do
   request.env['HTTP_USER_AGENT'] = 'Safari blah blah'

   end  
   

  it "corect recvest" do
  render "callc/login"
  response.should have_tag("select", :text => /mini\n                full/)
  end 
  
end

describe "/callc/login.rhtml" do
 include  CallcHelper
   
 before(:each) do
 end  
 it "not corect" do
  render "callc/login"
  response.should_not have_tag("select", :text => /mini\n                full/)
  end 
  
end